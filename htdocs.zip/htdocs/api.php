<?php
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);
date_default_timezone_set('Asia/Shanghai');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');

$host = 'sql303.infinityfree.com';
$user = 'if0_42728000';
$pass = 'LAYZ2026';
$db   = 'if0_42728000_rewards';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'error' => '系统错误：数据库连接失败']);
    exit;
}
$conn->set_charset("utf8mb4");
$conn->query("SET time_zone = '+8:00'");

$action = $_GET['action'] ?? '';
$now = date('Y-m-d H:i:s');
$today = date('Y-m-d');

$DATA_DIR = __DIR__ . '/data/';
$FEATURE_PHOTO_DIR = __DIR__ . '/Runfiles/feature-photo/';
$ITEMS_DIR = __DIR__ . '/Runfiles/items/';
$ACHIEVEMENTS_DIR = __DIR__ . '/Runfiles/achievements/';
$BADGES_DIR = __DIR__ . '/Runfiles/badges/';
$AVATARS_DIR = __DIR__ . '/Runfiles/avatars/';
$FILES_DIR = __DIR__ . '/files/';

function genOrderId($prefix) {
    return $prefix . date('YmdHis') . rand(100, 999);
}

function getClientIP() {
    return $_SERVER['REMOTE_ADDR'] ?? '';
}

function getUA() {
    return substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255);
}

function checkUserStatus($conn, $username) {
    $stmt = $conn->prepare("SELECT status FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $row = $r->fetch_assoc();
    $stmt->close();
    if (!$row) return false;
    return intval($row['status']) === 1;
}

function isAdminUser($conn, $username) {
    $stmt = $conn->prepare("SELECT level FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $row = $r->fetch_assoc();
    $stmt->close();
    return $row && intval($row['level']) >= 4;
}

function isMMU($conn, $username) {
    $stmt = $conn->prepare("SELECT is_mmu FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $row = $r->fetch_assoc();
    $stmt->close();
    return $row && intval($row['is_mmu']) === 1;
}

function hasPermission($conn, $username, $perm) {
    if (isMMU($conn, $username)) return true;
    if (!isAdminUser($conn, $username)) return false;
    $allowed = ['can_manage_users','can_manage_products','can_manage_stocks','can_manage_lottery','can_manage_betting','can_manage_bank','can_manage_codes','can_manage_feedback','can_send_messages','can_manage_notices','can_view_logs','can_adjust_points','can_manage_wheel','can_manage_lottery_bet','can_manage_scratch','can_manage_achievements','can_manage_badges','can_manage_coupons','can_manage_bgm'];
    if (!in_array($perm, $allowed)) return false;
    $stmt = $conn->prepare("SELECT $perm FROM admin_permissions WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $row = $r->fetch_assoc();
    $stmt->close();
    if (!$row) return false;
    return intval($row[$perm]) === 1;
}

function addPointsLog($conn, $username, $change, $type, $desc, $order_id, $now) {
    $stmt = $conn->prepare("SELECT points FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $row = $r->fetch_assoc();
    $stmt->close();
    if (!$row) return;
    $balance = floatval($row['points']);
    $change = floatval($change);
    $stmt = $conn->prepare("INSERT INTO points_log (username, change_amount, balance_after, type, description, order_id, time) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sddssss", $username, $change, $balance, $type, $desc, $order_id, $now);
    $stmt->execute();
    $stmt->close();
}

function sendMessage($conn, $from, $to, $title, $content, $now, $type = 'notice', $request_type = null, $request_data = null) {
    $order_id = genOrderId('MSG');
    $stmt = $conn->prepare("INSERT INTO messages (order_id, from_user, to_user, title, content, type, request_type, request_data, request_status, is_read, time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?)");
    $stmt->bind_param("sssssssss", $order_id, $from, $to, $title, $content, $type, $request_type, $request_data, $now);
    $stmt->execute();
    $stmt->close();
    return $order_id;
}

function addLog($conn, $username, $action, $detail, $now) {
    $ip = getClientIP();
    $stmt = $conn->prepare("INSERT INTO operation_logs (username, action, detail, ip, time) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $username, $action, $detail, $ip, $now);
    $stmt->execute();
    $stmt->close();
}

function getSetting($conn, $key, $default = null) {
    $stmt = $conn->prepare("SELECT value FROM system_settings WHERE `key` = ?");
    $stmt->bind_param("s", $key);
    $stmt->execute();
    $r = $stmt->get_result();
    $row = $r->fetch_assoc();
    $stmt->close();
    return $row ? $row['value'] : $default;
}

function setSetting($conn, $key, $value) {
    $stmt = $conn->prepare("INSERT INTO system_settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value` = ?");
    $stmt->bind_param("sss", $key, $value, $value);
    $stmt->execute();
    $stmt->close();
}

function reportError($conn, $username, $errorMsg, $now) {
    $mmu = $conn->query("SELECT username FROM users WHERE is_mmu = 1 LIMIT 1")->fetch_assoc();
    if (!$mmu) return;
    $to = $mmu['username'];
    $title = '系统错误上报';
    $content = "用户：" . ($username ?: '未登录') . "\n时间：" . $now . "\n错误：" . $errorMsg;
    sendMessage($conn, 'system', $to, $title, $content, $now);
}

function settleInterest($conn, $username, $now, $today) {
    $stmt = $conn->prepare("SELECT savings, last_interest_date FROM bank_accounts WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $acc = $r->fetch_assoc();
    $stmt->close();
    if (!$acc) return;
    $savings = floatval($acc['savings']);
    if ($savings <= 0) {
        $conn->query("UPDATE bank_accounts SET last_interest_date = '$today' WHERE username = '$username'");
        return;
    }
    $last = $acc['last_interest_date'];
    if (!$last) {
        $conn->query("UPDATE bank_accounts SET last_interest_date = '$today' WHERE username = '$username'");
        return;
    }
    $lastDate = date('Y-m-d', strtotime($last));
    $todayDate = date('Y-m-d');
    if ($lastDate >= $todayDate) return;
    $rateVal = getSetting($conn, 'saving_rate_dummy', null);
    $rateStmt = $conn->query("SELECT saving_rate FROM bank_rates WHERE id = 1")->fetch_assoc();
    $rate = $rateStmt ? floatval($rateStmt['saving_rate']) : 0;
    if ($rate <= 0) {
        $conn->query("UPDATE bank_accounts SET last_interest_date = '$today' WHERE username = '$username'");
        return;
    }
    $days = floor((strtotime($todayDate) - strtotime($lastDate)) / 86400);
    if ($days < 1) $days = 1;
    $interest = round($savings * $rate * $days, 2);
    if ($interest > 0) {
        $conn->query("UPDATE bank_accounts SET savings = savings + $interest, last_interest_date = '$today' WHERE username = '$username'");
        $order_id = genOrderId('BK');
        $stmt = $conn->prepare("INSERT INTO bank_records (order_id, username, type, amount, time) VALUES (?, ?, '利息', ?, ?)");
        $stmt->bind_param("ssds", $order_id, $username, $interest, $now);
        $stmt->execute();
        $stmt->close();
    } else {
        $conn->query("UPDATE bank_accounts SET last_interest_date = '$today' WHERE username = '$username'");
    }
}

function execBackup($conn, $DATA_DIR) {
    if (!is_dir($DATA_DIR)) @mkdir($DATA_DIR, 0755, true);
    $filename = 'backup_' . date('Y-m-d_H-i-s') . '.sql';
    $filepath = $DATA_DIR . $filename;
    $fp = fopen($filepath, 'w');
    if (!$fp) return false;
    fwrite($fp, "-- Rewards Backup\n-- Date: " . date('Y-m-d H:i:s') . "\n\n");
    fwrite($fp, "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\n\n");
    $tables = [];
    $r = $conn->query("SHOW TABLES");
    while ($row = $r->fetch_array()) $tables[] = $row[0];
    foreach ($tables as $t) {
        $res = $conn->query("SHOW CREATE TABLE `$t`");
        $row = $res->fetch_assoc();
        fwrite($fp, "DROP TABLE IF EXISTS `$t`;\n");
        fwrite($fp, $row['Create Table'] . ";\n\n");
        $res2 = $conn->query("SELECT * FROM `$t`");
        if ($res2 && $res2->num_rows > 0) {
            $cols = [];
            $fields = $res2->fetch_fields();
            foreach ($fields as $f) $cols[] = "`" . $f->name . "`";
            $colStr = implode(', ', $cols);
            $batch = [];
            while ($dataRow = $res2->fetch_assoc()) {
                $vals = [];
                foreach ($dataRow as $v) {
                    if ($v === null) $vals[] = 'NULL';
                    else $vals[] = "'" . $conn->real_escape_string($v) . "'";
                }
                $batch[] = "(" . implode(', ', $vals) . ")";
                if (count($batch) >= 100) {
                    fwrite($fp, "INSERT INTO `$t` ($colStr) VALUES\n" . implode(",\n", $batch) . ";\n");
                    $batch = [];
                }
            }
            if (count($batch) > 0) {
                fwrite($fp, "INSERT INTO `$t` ($colStr) VALUES\n" . implode(",\n", $batch) . ";\n");
            }
            fwrite($fp, "\n");
        }
    }
    fwrite($fp, "SET FOREIGN_KEY_CHECKS = 1;\n");
    fclose($fp);
    $files = glob($DATA_DIR . 'backup_*.sql');
    usort($files, function($a, $b) { return filemtime($b) - filemtime($a); });
    if (count($files) > 10) {
        for ($i = 10; $i < count($files); $i++) @unlink($files[$i]);
    }
    return $filename;
}

if ($action === 'ping') {
    echo json_encode(['success' => true, 'time' => $now]);
    $conn->close();
    exit;
}

if ($action === 'init_password') {
    $newHash = password_hash('123456', PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = 'wyx'");
    $stmt->bind_param("s", $newHash);
    $stmt->execute();
    $aff = $stmt->affected_rows;
    $stmt->close();
    echo json_encode(['success' => true, 'affected' => $aff, 'note' => 'wyx 密码已重置为 123456，请立即删除此接口']);
    $conn->close();
    exit;
}

// ===== END PART 1 =====


// ===== PART 2/5 =====

if ($action === 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    if (empty($username) || empty($password)) {
        echo json_encode(['success' => false, 'error' => '请输入用户名和密码']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $u = $r->fetch_assoc();
    $stmt->close();
    if (!$u || !password_verify($password, $u['password'])) {
        addLog($conn, $username, 'login_failed', '登录失败', $now);
        echo json_encode(['success' => false, 'error' => '账号或密码错误']);
        $conn->close();
        exit;
    }
    if ($u['status'] == 0) {
        echo json_encode(['success' => false, 'error' => '账号已冻结']);
        $conn->close();
        exit;
    }
    if ($u['status'] == 2) {
        echo json_encode(['success' => false, 'error' => '账号已删除']);
        $conn->close();
        exit;
    }
    $maintenance = getSetting($conn, 'maintenance_mode', '0');
    if ($maintenance == '1' && intval($u['is_mmu']) !== 1 && intval($u['level']) < 4) {
        $mtime = getSetting($conn, 'maintenance_time', '');
        $mop = getSetting($conn, 'maintenance_operator', '');
        echo json_encode(['success' => false, 'error' => '网站正在维护升级，请等待恢复通知', 'maintenance' => true, 'time' => $mtime, 'operator' => $mop]);
        $conn->close();
        exit;
    }
    $needRename = 0;
    if (intval($u['need_rename']) === 1) {
        $needRename = 1;
    } else if (preg_match('/[\x{4e00}-\x{9fa5}]/u', $u['username'])) {
        $needRename = 1;
        $conn->query("UPDATE users SET need_rename = 1 WHERE username = '$username'");
    }
    settleInterest($conn, $username, $now, $today);
    $ip = getClientIP();
    $ua = getUA();
    $stmt = $conn->prepare("UPDATE users SET last_ip = ?, last_ua = ?, last_login = ? WHERE username = ?");
    $stmt->bind_param("ssss", $ip, $ua, $now, $username);
    $stmt->execute();
    $stmt->close();
    $stmt2 = $conn->prepare("SELECT unique_id, username, realname, points, level, is_mmu, status, show_in_rank, need_rename, theme, dark_mode, notify_on, bgm_on, avatar, bio, sign_streak, last_sign_date, home_cards, city FROM users WHERE username = ?");
    $stmt2->bind_param("s", $username);
    $stmt2->execute();
    $r2 = $stmt2->get_result();
    $u2 = $r2->fetch_assoc();
    $stmt2->close();
    $u2['need_rename'] = $needRename;
    addLog($conn, $username, 'login', '登录成功', $now);
    echo json_encode(['success' => true, 'user' => $u2]);
    $conn->close();
    exit;
}

if ($action === 'register') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $realname = trim($_POST['realname'] ?? '');
    if (empty($username) || empty($password) || empty($realname)) {
        echo json_encode(['success' => false, 'error' => '请填写完整信息']);
        $conn->close();
        exit;
    }
    if (!preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username)) {
        echo json_encode(['success' => false, 'error' => '用户名只能包含字母、数字、下划线，3-20位']);
        $conn->close();
        exit;
    }
    if (strlen($password) < 4) {
        echo json_encode(['success' => false, 'error' => '密码至少4位']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $stmt->close();
        echo json_encode(['success' => false, 'error' => '用户名已存在']);
        $conn->close();
        exit;
    }
    $stmt->close();
    $stmt = $conn->prepare("SELECT id FROM users WHERE realname = ?");
    $stmt->bind_param("s", $realname);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $stmt->close();
        echo json_encode(['success' => false, 'error' => '该姓名已被注册']);
        $conn->close();
        exit;
    }
    $stmt->close();
    $unique_id = 'UID' . strtoupper(substr(uniqid(), -6)) . rand(100, 999);
    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $ip = getClientIP();
    $ua = getUA();
    $stmt = $conn->prepare("INSERT INTO users (unique_id, username, password, realname, reg_ip, reg_ua, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $unique_id, $username, $hashed, $realname, $ip, $ua, $now);
    $ok = $stmt->execute();
    $aff = $stmt->affected_rows;
    $stmt->close();
    if ($ok && $aff > 0) {
        $conn->query("INSERT IGNORE INTO bank_accounts (username, savings, loan, last_interest_date) VALUES ('$username', 0, 0, '$today')");
        $conn->query("INSERT IGNORE INTO user_chips (username, chips) VALUES ('$username', 0)");
        addLog($conn, $username, 'register', '注册成功', $now);
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => '注册失败，请重试']);
    }
    $conn->close();
    exit;
}

if ($action === 'rename_user') {
    $old = trim($_POST['old_username'] ?? '');
    $new = trim($_POST['new_username'] ?? '');
    if (!preg_match('/^[a-zA-Z0-9_]{3,20}$/', $new)) {
        echo json_encode(['success' => false, 'error' => '用户名只能包含字母、数字、下划线，3-20位']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $new);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $stmt->close();
        echo json_encode(['success' => false, 'error' => '该用户名已被占用']);
        $conn->close();
        exit;
    }
    $stmt->close();
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE users SET username = ?, need_rename = 0 WHERE username = ?");
        $stmt->bind_param("ss", $new, $old);
        $stmt->execute();
        $aff = $stmt->affected_rows;
        $stmt->close();
        if ($aff <= 0) throw new Exception('修改失败');
        $tables = ['bank_accounts','bank_records','points_log','transfers','user_purchases','stock_holdings','stock_trades','user_items','market_listings','user_bankcards','messages','sign_log','item_use_codes','operation_logs','friends','friend_requests','user_achievements','user_badges','cart_items','user_coupons','user_chips','countdowns','ephemeral_messages','wheel_records','scratch_cards','lottery_tickets','game_players','admin_permissions','badge_codes'];
        foreach ($tables as $t) {
            $res = $conn->query("SHOW COLUMNS FROM `$t`");
            $cols = [];
            while ($c = $res->fetch_assoc()) {
                if (in_array($c['Field'], ['username','from_user','to_user','user1','user2','seller','buyer','owner','used_by'])) $cols[] = $c['Field'];
            }
            foreach ($cols as $col) {
                $conn->query("UPDATE `$t` SET `$col` = '$new' WHERE `$col` = '$old'");
            }
        }
        $conn->commit();
        addLog($conn, $new, 'rename', '改名：' . $old . ' -> ' . $new, $now);
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => '修改失败']);
    }
    $conn->close();
    exit;
}

if ($action === 'get_user') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT unique_id, username, realname, points, level, is_mmu, status, show_in_rank, sign_streak, last_sign_date, need_rename, theme, dark_mode, notify_on, bgm_on, avatar, bio, home_cards, vip_until, city FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $u = $r->fetch_assoc();
    $stmt->close();
    if ($u) {
        echo json_encode($u);
    } else {
        echo json_encode(['success' => false, 'error' => '用户不存在']);
    }
    $conn->close();
    exit;
}

if ($action === 'change_password') {
    $username = $_POST['username'] ?? '';
    $old = $_POST['old_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    if (strlen($new) < 4) {
        echo json_encode(['success' => false, 'error' => '新密码至少4位']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $u = $r->fetch_assoc();
    $stmt->close();
    if ($u && password_verify($old, $u['password'])) {
        $h = password_hash($new, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
        $stmt->bind_param("ss", $h, $username);
        $stmt->execute();
        $stmt->close();
        addLog($conn, $username, 'change_password', '修改密码', $now);
        sendMessage($conn, 'system', $username, '密码已修改', '您的账号密码已修改，如非本人操作请立即联系管理员。', $now);
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => '原密码错误']);
    }
    $conn->close();
    exit;
}

if ($action === 'update_theme') {
    $username = $_POST['username'] ?? '';
    $theme = $_POST['theme'] ?? '#667eea';
    $dark = intval($_POST['dark_mode'] ?? 0);
    $stmt = $conn->prepare("UPDATE users SET theme = ?, dark_mode = ? WHERE username = ?");
    $stmt->bind_param("sis", $theme, $dark, $username);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'update_notify') {
    $username = $_POST['username'] ?? '';
    $notify = intval($_POST['notify_on'] ?? 0);
    $stmt = $conn->prepare("UPDATE users SET notify_on = ? WHERE username = ?");
    $stmt->bind_param("is", $notify, $username);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'update_bgm') {
    $username = $_POST['username'] ?? '';
    $bgm = intval($_POST['bgm_on'] ?? 0);
    $stmt = $conn->prepare("UPDATE users SET bgm_on = ? WHERE username = ?");
    $stmt->bind_param("is", $bgm, $username);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'update_privacy') {
    $username = $_POST['username'] ?? '';
    $show = intval($_POST['show_in_rank'] ?? 1);
    $stmt = $conn->prepare("UPDATE users SET show_in_rank = ? WHERE username = ?");
    $stmt->bind_param("is", $show, $username);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'update_home_cards') {
    $username = $_POST['username'] ?? '';
    $cards = $_POST['cards'] ?? '[]';
    $stmt = $conn->prepare("UPDATE users SET home_cards = ? WHERE username = ?");
    $stmt->bind_param("ss", $cards, $username);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'update_profile') {
    $username = $_POST['username'] ?? '';
    $bio = trim($_POST['bio'] ?? '');
    $avatar = trim($_POST['avatar'] ?? '');
    if (strlen($bio) > 255) $bio = substr($bio, 0, 255);
    $stmt = $conn->prepare("UPDATE users SET bio = ?, avatar = ? WHERE username = ?");
    $stmt->bind_param("sss", $bio, $avatar, $username);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}


if ($action === 'update_city') {
    $username = $_POST['username'] ?? '';
    $city = trim($_POST['city'] ?? '');
    if (strlen($city) > 50) $city = substr($city, 0, 50);
    $stmt = $conn->prepare("UPDATE users SET city = ? WHERE username = ?");
    $stmt->bind_param("ss", $city, $username);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}


if ($action === 'upload_avatar') {
    $username = $_POST['username'] ?? '';
    if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['success' => false, 'error' => '上传失败']);
        $conn->close();
        exit;
    }
    $allowed = ['image/jpeg','image/png','image/gif','image/webp'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $_FILES['avatar']['tmp_name']);
    finfo_close($finfo);
    if (!in_array($mime, $allowed)) {
        echo json_encode(['success' => false, 'error' => '只支持 JPG/PNG/GIF/WebP']);
        $conn->close();
        exit;
    }
    if ($_FILES['avatar']['size'] > 2 * 1024 * 1024) {
        echo json_encode(['success' => false, 'error' => '图片不能超过 2MB']);
        $conn->close();
        exit;
    }
    if (!is_dir($AVATARS_DIR)) @mkdir($AVATARS_DIR, 0755, true);
    $ext = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
    $filename = $username . '_' . time() . '.' . $ext;
    $filepath = $AVATARS_DIR . $filename;
    if (!move_uploaded_file($_FILES['avatar']['tmp_name'], $filepath)) {
        echo json_encode(['success' => false, 'error' => '保存失败']);
        $conn->close();
        exit;
    }
    $avatarUrl = '/Runfiles/avatars/' . $filename;
    $stmt = $conn->prepare("UPDATE users SET avatar = ? WHERE username = ?");
    $stmt->bind_param("ss", $avatarUrl, $username);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true, 'avatar' => $avatarUrl]);
    $conn->close();
    exit;
}

if ($action === 'sign_in') {
    $username = $_POST['username'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT last_sign_date, sign_streak FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $u = $r->fetch_assoc();
    $stmt->close();
    if (!$u) {
        echo json_encode(['success' => false, 'error' => '用户不存在']);
        $conn->close();
        exit;
    }
    if ($u['last_sign_date'] === $today) {
        echo json_encode(['success' => false, 'error' => '今日已签到']);
        $conn->close();
        exit;
    }
    $streak = 1;
    if ($u['last_sign_date']) {
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        if ($u['last_sign_date'] === $yesterday) {
            $streak = intval($u['sign_streak']) + 1;
        }
    }
    $min = intval(getSetting($conn, 'sign_min', 10));
    $max = intval(getSetting($conn, 'sign_max', 30));
    $base = rand($min, $max);
    $multiplier = 1.0 + 0.1 * min($streak - 1, 7);
    if ($streak >= 8) $multiplier = 1.8;
    $points = round($base * $multiplier);
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE users SET points = points + ?, last_sign_date = ?, sign_streak = ? WHERE username = ?");
        $stmt->bind_param("dsis", $points, $today, $streak, $username);
        $stmt->execute();
        $stmt->close();
        $order_id = genOrderId('SIGN');
        $stmt = $conn->prepare("INSERT INTO sign_log (order_id, username, points, streak, sign_date, time) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssdiss", $order_id, $username, $points, $streak, $today, $now);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        addPointsLog($conn, $username, $points, 'sign', '签到（连续' . $streak . '天）', $order_id, $now);
        echo json_encode(['success' => true, 'points' => $points, 'streak' => $streak, 'multiplier' => $multiplier, 'order_id' => $order_id]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => '签到失败']);
    }
    $conn->close();
    exit;
}

if ($action === 'get_sign_calendar') {
    $username = $_POST['username'] ?? '';
    $year = intval($_POST['year'] ?? date('Y'));
    $month = intval($_POST['month'] ?? date('n'));
    $start = sprintf('%04d-%02d-01', $year, $month);
    $end = date('Y-m-t', strtotime($start));
    $stmt = $conn->prepare("SELECT sign_date, points, streak FROM sign_log WHERE username = ? AND sign_date >= ? AND sign_date <= ? ORDER BY sign_date ASC");
    $stmt->bind_param("sss", $username, $start, $end);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) $list[] = $row;
    $stmt->close();
    $stmt2 = $conn->prepare("SELECT sign_streak, last_sign_date FROM users WHERE username = ?");
    $stmt2->bind_param("s", $username);
    $stmt2->execute();
    $r2 = $stmt2->get_result();
    $u = $r2->fetch_assoc();
    $stmt2->close();
    echo json_encode([
        'list' => $list,
        'streak' => intval($u['sign_streak'] ?? 0),
        'last_sign' => $u['last_sign_date'] ?? null,
        'today' => $today
    ]);
    $conn->close();
    exit;
}

if ($action === 'get_unread_messages') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT COUNT(*) as cnt FROM messages WHERE to_user = ? AND is_read = 0");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $row = $r->fetch_assoc();
    $stmt->close();
    echo json_encode(['count' => intval($row['cnt'])]);
    $conn->close();
    exit;
}

if ($action === 'get_messages') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM messages WHERE to_user = ? ORDER BY id DESC LIMIT 100");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
        $list[] = $row;
    }
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'mark_message_read') {
    $username = $_POST['username'] ?? '';
    $id = intval($_POST['id'] ?? 0);
    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE messages SET is_read = 1 WHERE id = ? AND to_user = ?");
        $stmt->bind_param("is", $id, $username);
    } else {
        $stmt = $conn->prepare("UPDATE messages SET is_read = 1 WHERE to_user = ?");
        $stmt->bind_param("s", $username);
    }
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'delete_message') {
    $username = $_POST['username'] ?? '';
    $id = intval($_POST['id'] ?? 0);
    $stmt = $conn->prepare("DELETE FROM messages WHERE id = ? AND to_user = ?");
    $stmt->bind_param("is", $id, $username);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'handle_message_request') {
    $username = $_POST['username'] ?? '';
    $id = intval($_POST['id'] ?? 0);
    $decision = $_POST['decision'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM messages WHERE id = ? AND to_user = ? AND type = 'request'");
    $stmt->bind_param("is", $id, $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $msg = $r->fetch_assoc();
    $stmt->close();
    if (!$msg || intval($msg['request_status']) !== 0) {
        echo json_encode(['success' => false, 'error' => '请求不存在或已处理']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        $newStatus = 0;
        if ($msg['request_type'] === 'change_price' && $decision === 'accept') {
            $data = json_decode($msg['request_data'], true);
            $listingId = intval($data['listing_id'] ?? 0);
            $newPrice = floatval($data['new_price'] ?? 0);
            $buyer = $data['buyer'] ?? '';
            $stmt = $conn->prepare("SELECT * FROM market_listings WHERE id = ? AND status = 1");
            $stmt->bind_param("i", $listingId);
            $stmt->execute();
            $r = $stmt->get_result();
            $listing = $r->fetch_assoc();
            $stmt->close();
            if (!$listing) throw new Exception('商品已不存在');
            $stmt = $conn->prepare("SELECT points FROM users WHERE username = ?");
            $stmt->bind_param("s", $buyer);
            $stmt->execute();
            $r = $stmt->get_result();
            $buyerAcc = $r->fetch_assoc();
            $stmt->close();
            if (!$buyerAcc || floatval($buyerAcc['points']) < $newPrice) throw new Exception('买家积分不足');
            $stmt = $conn->prepare("UPDATE users SET points = points - ? WHERE username = ? AND points >= ?");
            $stmt->bind_param("dsd", $newPrice, $buyer, $newPrice);
            $stmt->execute();
            $aff = $stmt->affected_rows;
            $stmt->close();
            if ($aff <= 0) throw new Exception('扣款失败');
            $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE username = ?");
            $seller = $listing['seller'];
            $stmt->bind_param("ds", $newPrice, $seller);
            $stmt->execute();
            $stmt->close();
            $stmt = $conn->prepare("UPDATE market_listings SET status = 0 WHERE id = ?");
            $stmt->bind_param("i", $listingId);
            $stmt->execute();
            $stmt->close();
            $order_id = genOrderId('MT');
            $itemName = $listing['item_name'];
            $stmt = $conn->prepare("INSERT INTO market_trades (order_id, seller, buyer, item_name, price, time) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssds", $order_id, $seller, $buyer, $itemName, $newPrice, $now);
            $stmt->execute();
            $stmt->close();
            $filePath = $listing['file_path'];
            $isOneTime = intval($listing['is_one_time']);
            if (!empty($filePath)) {
                $stmt = $conn->prepare("INSERT INTO user_items (username, product_id, product_name, quantity, file_path, is_one_time, can_sell) VALUES (?, 0, ?, 1, ?, ?, 1)");
                $stmt->bind_param("sssi", $buyer, $itemName, $filePath, $isOneTime);
                $stmt->execute();
                $stmt->close();
            } else {
                $stmt = $conn->prepare("INSERT INTO user_items (username, product_id, product_name, quantity, can_sell) VALUES (?, 0, ?, 1, 1)");
                $stmt->bind_param("ss", $buyer, $itemName);
                $stmt->execute();
                $stmt->close();
            }
            addPointsLog($conn, $buyer, -$newPrice, 'market_buy', '市场购买 ' . $itemName, $order_id, $now);
            addPointsLog($conn, $seller, $newPrice, 'market_sell', '市场卖出 ' . $itemName, $order_id, $now);
            sendMessage($conn, 'system', $seller, '改价申请已同意', $buyer . ' 已按新价格 ' . $newPrice . ' 购买您的「' . $itemName . '」', $now);
            sendMessage($conn, 'system', $buyer, '购买成功', '您已按改价 ' . $newPrice . ' 购买「' . $itemName . '」', $now);
            $newStatus = 1;
        } else if ($msg['request_type'] === 'change_price' && $decision === 'reject') {
            $data = json_decode($msg['request_data'], true);
            sendMessage($conn, 'system', $data['buyer'] ?? '', '改价申请被拒绝', '卖家拒绝了您的改价申请', $now);
            $newStatus = 2;
        } else if ($msg['request_type'] === 'friend') {
            $data = json_decode($msg['request_data'], true);
            $from = $data['from'] ?? '';
            if ($decision === 'accept') {
                $u1 = min($from, $username);
                $u2 = max($from, $username);
                $stmt = $conn->prepare("INSERT IGNORE INTO friends (user1, user2, created_at) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $u1, $u2, $now);
                $stmt->execute();
                $stmt->close();
                $stmt = $conn->prepare("UPDATE friend_requests SET status = 1, handled_at = ? WHERE from_user = ? AND to_user = ? AND status = 0");
                $stmt->bind_param("sss", $now, $from, $username);
                $stmt->execute();
                $stmt->close();
                sendMessage($conn, 'system', $from, '好友申请通过', $username . ' 已同意您的好友申请', $now);
                $newStatus = 1;
            } else {
                $stmt = $conn->prepare("UPDATE friend_requests SET status = 2, handled_at = ? WHERE from_user = ? AND to_user = ? AND status = 0");
                $stmt->bind_param("sss", $now, $from, $username);
                $stmt->execute();
                $stmt->close();
                $newStatus = 2;
            }
        } else {
            throw new Exception('不支持的请求类型');
        }
        $stmt = $conn->prepare("UPDATE messages SET request_status = ?, is_read = 1 WHERE id = ?");
        $stmt->bind_param("ii", $newStatus, $id);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        echo json_encode(['success' => true, 'decision' => $decision]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'submit_feedback') {
    $username = $_POST['username'] ?? '';
    $content = trim($_POST['content'] ?? '');
    if (empty($content)) {
        echo json_encode(['success' => false, 'error' => '请填写反馈内容']);
        $conn->close();
        exit;
    }
    $order_id = genOrderId('FB');
    $stmt = $conn->prepare("INSERT INTO feedback (order_id, username, content, time) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $order_id, $username, $content, $now);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true, 'order_id' => $order_id]);
    $conn->close();
    exit;
}

if ($action === 'get_feedbacks') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM feedback WHERE username = ? ORDER BY id DESC");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
        $list[] = $row;
    }
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'report_error') {
    $username = $_POST['username'] ?? '';
    $errorMsg = $_POST['error'] ?? '';
    if (empty($errorMsg)) {
        echo json_encode(['success' => false]);
        $conn->close();
        exit;
    }
    reportError($conn, $username, $errorMsg, $now);
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'get_notices') {
    $r = $conn->query("SELECT * FROM notices ORDER BY id DESC LIMIT 30");
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
        $list[] = $row;
    }
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'get_settings') {
    $r = $conn->query("SELECT * FROM system_settings");
    $data = [];
    while ($row = $r->fetch_assoc()) {
        $data[$row['key']] = $row['value'];
    }
    echo json_encode($data);
    $conn->close();
    exit;
}

if ($action === 'get_rank') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT COUNT(*) + 1 as rank FROM users WHERE points > (SELECT points FROM users WHERE username = ?) AND status = 1 AND show_in_rank = 1");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $rank = $r->fetch_assoc();
    $stmt->close();
    $listResult = $conn->query("SELECT username, realname, points FROM users WHERE status = 1 AND show_in_rank = 1 ORDER BY points DESC LIMIT 50");
    $list = [];
    while ($row = $listResult->fetch_assoc()) $list[] = $row;
    echo json_encode(['rank' => $rank ? $rank['rank'] : '未上榜', 'list' => $list]);
    $conn->close();
    exit;
}

// ===== END PART 2 =====


// ===== PART 3/5 =====

if ($action === 'get_bank') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT savings, loan FROM bank_accounts WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $bank = $r->fetch_assoc();
    $stmt->close();
    echo json_encode($bank ?: ['savings' => 0, 'loan' => 0]);
    $conn->close();
    exit;
}

if ($action === 'bank_deposit') {
    $username = $_POST['username'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $amount = floatval($_POST['amount'] ?? 0);
    if ($amount <= 0) {
        echo json_encode(['success' => false, 'error' => '金额必须大于0']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE users SET points = points - ? WHERE username = ? AND points >= ?");
        $stmt->bind_param("dsd", $amount, $username, $amount);
        $stmt->execute();
        $aff = $stmt->affected_rows;
        $stmt->close();
        if ($aff <= 0) throw new Exception('积分不足');
        $stmt = $conn->prepare("UPDATE bank_accounts SET savings = savings + ? WHERE username = ?");
        $stmt->bind_param("ds", $amount, $username);
        $stmt->execute();
        $stmt->close();
        $order_id = genOrderId('BK');
        $stmt = $conn->prepare("INSERT INTO bank_records (order_id, username, type, amount, time) VALUES (?, ?, '存款', ?, ?)");
        $stmt->bind_param("ssds", $order_id, $username, $amount, $now);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        addPointsLog($conn, $username, -$amount, 'bank_deposit', '存款', $order_id, $now);
        echo json_encode(['success' => true, 'order_id' => $order_id]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'bank_withdraw') {
    $username = $_POST['username'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $amount = floatval($_POST['amount'] ?? 0);
    if ($amount <= 0) {
        echo json_encode(['success' => false, 'error' => '金额必须大于0']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE bank_accounts SET savings = savings - ? WHERE username = ? AND savings >= ?");
        $stmt->bind_param("dsd", $amount, $username, $amount);
        $stmt->execute();
        $aff = $stmt->affected_rows;
        $stmt->close();
        if ($aff <= 0) throw new Exception('存款不足');
        $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE username = ?");
        $stmt->bind_param("ds", $amount, $username);
        $stmt->execute();
        $stmt->close();
        $order_id = genOrderId('BK');
        $stmt = $conn->prepare("INSERT INTO bank_records (order_id, username, type, amount, time) VALUES (?, ?, '取款', ?, ?)");
        $stmt->bind_param("ssds", $order_id, $username, $amount, $now);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        addPointsLog($conn, $username, $amount, 'bank_withdraw', '取款', $order_id, $now);
        echo json_encode(['success' => true, 'order_id' => $order_id]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'bank_loan') {
    $username = $_POST['username'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $amount = floatval($_POST['amount'] ?? 0);
    if ($amount <= 0) {
        echo json_encode(['success' => false, 'error' => '金额必须大于0']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT loan FROM bank_accounts WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $check = $r->fetch_assoc();
    $stmt->close();
    if ($check && floatval($check['loan']) > 0) {
        echo json_encode(['success' => false, 'error' => '请先还清贷款']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE bank_accounts SET loan = loan + ? WHERE username = ?");
        $stmt->bind_param("ds", $amount, $username);
        $stmt->execute();
        $stmt->close();
        $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE username = ?");
        $stmt->bind_param("ds", $amount, $username);
        $stmt->execute();
        $stmt->close();
        $order_id = genOrderId('BK');
        $stmt = $conn->prepare("INSERT INTO bank_records (order_id, username, type, amount, time) VALUES (?, ?, '贷款', ?, ?)");
        $stmt->bind_param("ssds", $order_id, $username, $amount, $now);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        addPointsLog($conn, $username, $amount, 'bank_loan', '贷款', $order_id, $now);
        echo json_encode(['success' => true, 'order_id' => $order_id]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'bank_repay') {
    $username = $_POST['username'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $amount = floatval($_POST['amount'] ?? 0);
    if ($amount <= 0) {
        echo json_encode(['success' => false, 'error' => '金额必须大于0']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT loan FROM bank_accounts WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $acc = $r->fetch_assoc();
    $stmt->close();
    if (!$acc || floatval($acc['loan']) <= 0) {
        echo json_encode(['success' => false, 'error' => '您没有欠款']);
        $conn->close();
        exit;
    }
    $loan = floatval($acc['loan']);
    if ($amount > $loan) $amount = $loan;
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE users SET points = points - ? WHERE username = ? AND points >= ?");
        $stmt->bind_param("dsd", $amount, $username, $amount);
        $stmt->execute();
        $aff = $stmt->affected_rows;
        $stmt->close();
        if ($aff <= 0) throw new Exception('积分不足');
        $stmt = $conn->prepare("UPDATE bank_accounts SET loan = loan - ? WHERE username = ?");
        $stmt->bind_param("ds", $amount, $username);
        $stmt->execute();
        $stmt->close();
        $order_id = genOrderId('BK');
        $stmt = $conn->prepare("INSERT INTO bank_records (order_id, username, type, amount, time) VALUES (?, ?, '还款', ?, ?)");
        $stmt->bind_param("ssds", $order_id, $username, $amount, $now);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        addPointsLog($conn, $username, -$amount, 'bank_repay', '还款', $order_id, $now);
        echo json_encode(['success' => true, 'order_id' => $order_id, 'actual' => $amount]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'get_bank_records') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM bank_records WHERE username = ? ORDER BY id DESC LIMIT 30");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
        $list[] = $row;
    }
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'get_bank_rates') {
    $r = $conn->query("SELECT * FROM bank_rates WHERE id = 1");
    $rate = $r->fetch_assoc();
    echo json_encode($rate ?: ['saving_rate' => 0.0001, 'loan_rate' => 0.0002]);
    $conn->close();
    exit;
}

if ($action === 'update_bank_rates') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_bank')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $sm = floatval($_POST['saving_min'] ?? 0.0001);
    $sx = floatval($_POST['saving_max'] ?? 0.0005);
    $lm = floatval($_POST['loan_min'] ?? 0.0002);
    $lx = floatval($_POST['loan_max'] ?? 0.001);
    if ($sm >= $sx || $lm >= $lx) {
        echo json_encode(['success' => false, 'error' => '最小值必须小于最大值']);
        $conn->close();
        exit;
    }
    $sr = round(mt_rand($sm * 1000000, $sx * 1000000) / 1000000, 6);
    $lr = round(mt_rand($lm * 1000000, $lx * 1000000) / 1000000, 6);
    $stmt = $conn->prepare("UPDATE bank_rates SET saving_rate = ?, loan_rate = ?, saving_rate_min = ?, saving_rate_max = ?, loan_rate_min = ?, loan_rate_max = ? WHERE id = 1");
    $stmt->bind_param("dddddd", $sr, $lr, $sm, $sx, $lm, $lx);
    $stmt->execute();
    $stmt->close();
    $stmt = $conn->prepare("INSERT INTO rate_history (saving_rate, loan_rate, date) VALUES (?, ?, CURDATE())");
    $stmt->bind_param("dd", $sr, $lr);
    $stmt->execute();
    $stmt->close();
    addLog($conn, $admin, 'update_rates', "存款 $sr 贷款 $lr", $now);
    echo json_encode(['success' => true, 'saving_rate' => $sr, 'loan_rate' => $lr]);
    $conn->close();
    exit;
}

if ($action === 'get_rate_history') {
    $r = $conn->query("SELECT * FROM rate_history ORDER BY id DESC LIMIT 10");
    $list = [];
    while ($row = $r->fetch_assoc()) $list[] = $row;
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'get_my_bankcards') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM user_bankcards WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) $list[] = $row;
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'add_bankcard') {
    $username = $_POST['username'] ?? '';
    $bank_name = $_POST['bank_name'] ?? '积分银行';
    $card_number = trim($_POST['card_number'] ?? '');
    if (!preg_match('/^\d{16,19}$/', $card_number)) {
        echo json_encode(['success' => false, 'error' => '卡号格式错误，必须16-19位数字']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT COUNT(*) as c FROM user_bankcards WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $count = $r->fetch_assoc();
    $stmt->close();
    if ($count['c'] >= 3) {
        echo json_encode(['success' => false, 'error' => '最多绑定3张银行卡']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT id FROM user_bankcards WHERE card_number = ?");
    $stmt->bind_param("s", $card_number);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $stmt->close();
        echo json_encode(['success' => false, 'error' => '该卡号已被绑定']);
        $conn->close();
        exit;
    }
    $stmt->close();
    $stmt = $conn->prepare("INSERT INTO user_bankcards (username, bank_name, card_number, created_at) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $username, $bank_name, $card_number, $now);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'remove_bankcard') {
    $username = $_POST['username'] ?? '';
    $card_number = $_POST['card_number'] ?? '';
    $stmt = $conn->prepare("DELETE FROM user_bankcards WHERE username = ? AND card_number = ?");
    $stmt->bind_param("ss", $username, $card_number);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'transfer') {
    $from = $_POST['from_user'] ?? '';
    if (!checkUserStatus($conn, $from)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $to_id = trim($_POST['to_unique_id'] ?? '');
    $amount = floatval($_POST['amount'] ?? 0);
    if ($amount <= 0) {
        echo json_encode(['success' => false, 'error' => '金额必须大于0']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT username FROM users WHERE unique_id = ?");
    $stmt->bind_param("s", $to_id);
    $stmt->execute();
    $r = $stmt->get_result();
    $toRow = $r->fetch_assoc();
    $stmt->close();
    if (!$toRow) {
        echo json_encode(['success' => false, 'error' => '接收方不存在']);
        $conn->close();
        exit;
    }
    $to = $toRow['username'];
    if ($from === $to) {
        echo json_encode(['success' => false, 'error' => '不能转给自己']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE users SET points = points - ? WHERE username = ? AND points >= ?");
        $stmt->bind_param("dsd", $amount, $from, $amount);
        $stmt->execute();
        $aff = $stmt->affected_rows;
        $stmt->close();
        if ($aff <= 0) throw new Exception('积分不足');
        $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE username = ?");
        $stmt->bind_param("ds", $amount, $to);
        $stmt->execute();
        $stmt->close();
        $order_id = genOrderId('TR');
        $stmt = $conn->prepare("INSERT INTO transfers (order_id, from_user, to_user, amount, fee, type, time) VALUES (?, ?, ?, ?, 0, 'id', ?)");
        $stmt->bind_param("sssds", $order_id, $from, $to, $amount, $now);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        addPointsLog($conn, $from, -$amount, 'transfer_out', '转出给 ' . $to, $order_id, $now);
        addPointsLog($conn, $to, $amount, 'transfer_in', '收到 ' . $from . ' 转账', $order_id, $now);
        sendMessage($conn, 'system', $to, '收到转账', $from . ' 向您转账 ' . $amount . ' 积分', $now);
        echo json_encode(['success' => true, 'order_id' => $order_id]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'transfer_by_card') {
    $from_card = $_POST['from_card'] ?? '';
    $to_card = $_POST['to_card'] ?? '';
    $amount = floatval($_POST['amount'] ?? 0);
    if ($amount <= 0) {
        echo json_encode(['success' => false, 'error' => '金额必须大于0']);
        $conn->close();
        exit;
    }
    if ($from_card === $to_card) {
        echo json_encode(['success' => false, 'error' => '不能转给自己']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT username FROM user_bankcards WHERE card_number = ?");
    $stmt->bind_param("s", $from_card);
    $stmt->execute();
    $r = $stmt->get_result();
    $fromRow = $r->fetch_assoc();
    $stmt->close();
    if (!$fromRow) {
        echo json_encode(['success' => false, 'error' => '转出卡不存在']);
        $conn->close();
        exit;
    }
    $from = $fromRow['username'];
    if (!checkUserStatus($conn, $from)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT username FROM user_bankcards WHERE card_number = ?");
    $stmt->bind_param("s", $to_card);
    $stmt->execute();
    $r = $stmt->get_result();
    $toRow = $r->fetch_assoc();
    $stmt->close();
    if (!$toRow) {
        echo json_encode(['success' => false, 'error' => '收款卡不存在']);
        $conn->close();
        exit;
    }
    $to = $toRow['username'];
    if ($from === $to) {
        echo json_encode(['success' => false, 'error' => '不能转给自己']);
        $conn->close();
        exit;
    }
    $feeRate = floatval(getSetting($conn, 'withdraw_fee', 1));
    $fee = round($amount * $feeRate / 100, 2);
    $real = round($amount - $fee, 2);
    if ($real <= 0) {
        echo json_encode(['success' => false, 'error' => '金额过小']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE users SET points = points - ? WHERE username = ? AND points >= ?");
        $stmt->bind_param("dsd", $amount, $from, $amount);
        $stmt->execute();
        $aff = $stmt->affected_rows;
        $stmt->close();
        if ($aff <= 0) throw new Exception('积分不足');
        $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE username = ?");
        $stmt->bind_param("ds", $real, $to);
        $stmt->execute();
        $stmt->close();
        $order_id = genOrderId('TR');
        $stmt = $conn->prepare("INSERT INTO transfers (order_id, from_user, to_user, amount, fee, type, time) VALUES (?, ?, ?, ?, ?, 'card', ?)");
        $stmt->bind_param("sssdds", $order_id, $from, $to, $real, $fee, $now);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        addPointsLog($conn, $from, -$amount, 'transfer_out', '银行卡转出给 ' . $to . '（手续费' . $fee . '）', $order_id, $now);
        addPointsLog($conn, $to, $real, 'transfer_in', '收到 ' . $from . ' 转账', $order_id, $now);
        sendMessage($conn, 'system', $to, '收到转账', $from . ' 向您转账 ' . $real . ' 积分（已扣手续费 ' . $fee . '）', $now);
        echo json_encode(['success' => true, 'order_id' => $order_id, 'fee' => $fee, 'real' => $real]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'transfer_to_friend') {
    $from = $_POST['from_user'] ?? '';
    $to = $_POST['to_user'] ?? '';
    $amount = floatval($_POST['amount'] ?? 0);
    if ($amount <= 0 || $from === $to) {
        echo json_encode(['success' => false, 'error' => '参数无效']);
        $conn->close();
        exit;
    }
    $u1 = min($from, $to);
    $u2 = max($from, $to);
    $stmt = $conn->prepare("SELECT id FROM friends WHERE user1 = ? AND user2 = ?");
    $stmt->bind_param("ss", $u1, $u2);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows == 0) {
        $stmt->close();
        echo json_encode(['success' => false, 'error' => '对方不是你的好友']);
        $conn->close();
        exit;
    }
    $stmt->close();
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE users SET points = points - ? WHERE username = ? AND points >= ?");
        $stmt->bind_param("dsd", $amount, $from, $amount);
        $stmt->execute();
        $aff = $stmt->affected_rows;
        $stmt->close();
        if ($aff <= 0) throw new Exception('积分不足');
        $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE username = ?");
        $stmt->bind_param("ds", $amount, $to);
        $stmt->execute();
        $stmt->close();
        $order_id = genOrderId('TR');
        $stmt = $conn->prepare("INSERT INTO transfers (order_id, from_user, to_user, amount, fee, type, time) VALUES (?, ?, ?, ?, 0, 'friend', ?)");
        $stmt->bind_param("sssds", $order_id, $from, $to, $amount, $now);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        addPointsLog($conn, $from, -$amount, 'transfer_out', '转给好友 ' . $to, $order_id, $now);
        addPointsLog($conn, $to, $amount, 'transfer_in', '好友 ' . $from . ' 转账', $order_id, $now);
        sendMessage($conn, 'system', $to, '好友转账', $from . ' 向您转账 ' . $amount . ' 积分', $now);
        echo json_encode(['success' => true, 'order_id' => $order_id]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'get_transfers') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM transfers WHERE from_user = ? OR to_user = ? ORDER BY id DESC LIMIT 30");
    $stmt->bind_param("ss", $username, $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
        $list[] = $row;
    }
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'get_stocks') {
    $result = $conn->query("SELECT * FROM stocks ORDER BY id");
    $list = [];
    while ($row = $result->fetch_assoc()) {
        $row['price'] = round(floatval($row['price']), 2);
        $row['change_rate'] = round(floatval($row['change_rate']), 2);
        $list[] = $row;
    }
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'update_price') {
    $username = $_POST['username'] ?? '';
    if (empty($username)) {
        $username = 'system';
    } else {
        if (!checkUserStatus($conn, $username)) {
            echo json_encode(['success' => false, 'error' => '账号状态异常']);
            $conn->close();
            exit;
        }
    }
    $result = $conn->query("SELECT * FROM stocks ORDER BY id");
    $list = [];
    $globalCrash = (rand(1, 1000) <= 3);
    while ($row = $result->fetch_assoc()) {
        $price = floatval($row['price']);
        if ($globalCrash) {
            $crashRate = rand(20, 50) / 100;
            $change = -$price * $crashRate;
        } else {
            $change = (rand(-30, 30) / 1000) * $price;
            $maxChange = $price * 0.05;
            if ($change > $maxChange) $change = $maxChange;
            if ($change < -$maxChange) $change = -$maxChange;
        }
        $newPrice = max(0.01, $price + $change);
        $changeRate = ($newPrice - $price) / $price * 100;
        $stmt = $conn->prepare("UPDATE stocks SET price = ?, change_rate = ? WHERE id = ?");
        $stmt->bind_param("ddi", $newPrice, $changeRate, $row['id']);
        $stmt->execute();
        $stmt->close();
        $stmt = $conn->prepare("INSERT INTO stock_history (symbol, price, time) VALUES (?, ?, ?)");
        $stmt->bind_param("sds", $row['symbol'], $newPrice, $now);
        $stmt->execute();
        $stmt->close();
        $row['price'] = round($newPrice, 2);
        $row['change_rate'] = round($changeRate, 2);
        $list[] = $row;
    }
    if ($globalCrash) {
        $stmt = $conn->prepare("INSERT INTO notices (order_id, title, content, time) VALUES (?, '市场黑天鹅事件', '股市遭遇黑天鹅事件，多只股票暴跌！', ?)");
        $oid = genOrderId('NT');
        $stmt->bind_param("ss", $oid, $now);
        $stmt->execute();
        $stmt->close();
    }
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'stock_trade') {
    $username = $_POST['username'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $symbol = $_POST['symbol'] ?? '';
    $type = $_POST['type'] ?? '';
    $shares = intval($_POST['shares'] ?? 0);
    if ($shares <= 0) {
        echo json_encode(['success' => false, 'error' => '股数必须大于0']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT * FROM stocks WHERE symbol = ?");
    $stmt->bind_param("s", $symbol);
    $stmt->execute();
    $r = $stmt->get_result();
    $stock = $r->fetch_assoc();
    $stmt->close();
    if (!$stock) {
        echo json_encode(['success' => false, 'error' => '股票不存在']);
        $conn->close();
        exit;
    }
    $price = floatval($stock['price']);
    $total = round($price * $shares, 2);
    $conn->begin_transaction();
    try {
        if ($type === 'buy') {
            $stmt = $conn->prepare("UPDATE users SET points = points - ? WHERE username = ? AND points >= ?");
            $stmt->bind_param("dsd", $total, $username, $total);
            $stmt->execute();
            $aff = $stmt->affected_rows;
            $stmt->close();
            if ($aff <= 0) throw new Exception('积分不足，需要 ' . number_format($total, 2) . ' 积分');
            $stmt = $conn->prepare("SELECT * FROM stock_holdings WHERE username = ? AND symbol = ?");
            $stmt->bind_param("ss", $username, $symbol);
            $stmt->execute();
            $r = $stmt->get_result();
            $hold = $r->fetch_assoc();
            $stmt->close();
            if ($hold) {
                $newShares = intval($hold['shares']) + $shares;
                $newAvg = (floatval($hold['avg_price']) * intval($hold['shares']) + $total) / $newShares;
                $stmt = $conn->prepare("UPDATE stock_holdings SET shares = ?, avg_price = ? WHERE username = ? AND symbol = ?");
                $stmt->bind_param("idss", $newShares, $newAvg, $username, $symbol);
                $stmt->execute();
                $stmt->close();
            } else {
                $stmt = $conn->prepare("INSERT INTO stock_holdings (username, symbol, shares, avg_price) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("ssid", $username, $symbol, $shares, $price);
                $stmt->execute();
                $stmt->close();
            }
        } else if ($type === 'sell') {
            $stmt = $conn->prepare("SELECT * FROM stock_holdings WHERE username = ? AND symbol = ?");
            $stmt->bind_param("ss", $username, $symbol);
            $stmt->execute();
            $r = $stmt->get_result();
            $hold = $r->fetch_assoc();
            $stmt->close();
            if (!$hold || intval($hold['shares']) < $shares) {
                throw new Exception('持仓不足，当前持有 ' . intval($hold ? $hold['shares'] : 0) . ' 股');
            }
            $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE username = ?");
            $stmt->bind_param("ds", $total, $username);
            $stmt->execute();
            $stmt->close();
            $newShares = intval($hold['shares']) - $shares;
            if ($newShares <= 0) {
                $stmt = $conn->prepare("DELETE FROM stock_holdings WHERE username = ? AND symbol = ?");
                $stmt->bind_param("ss", $username, $symbol);
            } else {
                $stmt = $conn->prepare("UPDATE stock_holdings SET shares = ? WHERE username = ? AND symbol = ?");
                $stmt->bind_param("iss", $newShares, $username, $symbol);
            }
            $stmt->execute();
            $stmt->close();
        } else {
            throw new Exception('无效操作类型');
        }
        $order_id = genOrderId('ST');
        $stmt = $conn->prepare("INSERT INTO stock_trades (order_id, username, symbol, type, shares, price, time) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssids", $order_id, $username, $symbol, $type, $shares, $price, $now);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        if ($type === 'buy') {
            addPointsLog($conn, $username, -$total, 'stock_buy', '买入 ' . $symbol . ' ' . $shares . '股', $order_id, $now);
        } else {
            addPointsLog($conn, $username, $total, 'stock_sell', '卖出 ' . $symbol . ' ' . $shares . '股', $order_id, $now);
        }
        echo json_encode(['success' => true, 'order_id' => $order_id]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'get_holdings') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT h.*, s.price as current_price FROM stock_holdings h JOIN stocks s ON h.symbol = s.symbol WHERE h.username = ? AND h.shares > 0");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['shares'] = intval($row['shares']);
        $row['avg_price'] = floatval($row['avg_price']);
        $row['current_price'] = floatval($row['current_price']);
        $list[] = $row;
    }
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'get_stock_trades') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM stock_trades WHERE username = ? ORDER BY id DESC LIMIT 30");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
        $list[] = $row;
    }
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'get_stock_history') {
    $symbol = $_POST['symbol'] ?? '';
    $stmt = $conn->prepare("SELECT price, time FROM stock_history WHERE symbol = ? ORDER BY id DESC LIMIT 50");
    $stmt->bind_param("s", $symbol);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) $list[] = $row;
    $stmt->close();
    echo json_encode(array_reverse($list));
    $conn->close();
    exit;
}

if ($action === 'add_stock') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_stocks')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $symbol = strtoupper(trim($_POST['symbol'] ?? ''));
    $name = trim($_POST['name'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    if (!$symbol || !$name || $price <= 0) {
        echo json_encode(['success' => false, 'error' => '参数无效']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("INSERT IGNORE INTO stocks (symbol, name, price) VALUES (?, ?, ?)");
    $stmt->bind_param("ssd", $symbol, $name, $price);
    $stmt->execute();
    $aff = $stmt->affected_rows;
    $stmt->close();
    if ($aff > 0) {
        addLog($conn, $admin, 'add_stock', '添加股票 ' . $symbol, $now);
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => '股票代码已存在']);
    }
    $conn->close();
    exit;
}

if ($action === 'remove_stock') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_stocks')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $symbol = $_POST['symbol'] ?? '';
    $stmt = $conn->prepare("DELETE FROM stocks WHERE symbol = ?");
    $stmt->bind_param("s", $symbol);
    $stmt->execute();
    $stmt->close();
    addLog($conn, $admin, 'remove_stock', '删除股票 ' . $symbol, $now);
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

// ===== END PART 3 =====


// ===== PART 4/5 =====

if ($action === 'get_products') {
    $stmt = $conn->prepare("SELECT * FROM products WHERE status = 1 ORDER BY id DESC");
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) $list[] = $row;
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'get_market_listings') {
    $stmt = $conn->prepare("SELECT * FROM market_listings WHERE status = 1 ORDER BY id DESC");
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) $list[] = $row;
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'get_my_listings') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM market_listings WHERE seller = ? ORDER BY id DESC");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) $list[] = $row;
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'add_product') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_products')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $icon = trim($_POST['icon'] ?? '');
    $limit = intval($_POST['limit_qty'] ?? 0);
    $perUser = intval($_POST['per_user_limit'] ?? 0);
    $type = $_POST['type'] ?? 'normal';
    $minPoints = intval($_POST['min_points'] ?? 0);
    $maxPoints = intval($_POST['max_points'] ?? 100);
    $filePath = trim($_POST['file_path'] ?? '');
    if (empty($name) || $price < 0) {
        echo json_encode(['success' => false, 'error' => '参数无效']);
        $conn->close();
        exit;
    }
    $productType = ($type === 'file') ? 'file' : 'normal';
    $stmt = $conn->prepare("INSERT INTO products (name, description, price, icon, type, file_path, min_points, max_points, limit_qty, per_user_limit, product_type, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)");
    $stmt->bind_param("ssdsssiiiis", $name, $description, $price, $icon, $type, $filePath, $minPoints, $maxPoints, $limit, $perUser, $productType);
    $stmt->execute();
    $aff = $stmt->affected_rows;
    $stmt->close();
    if ($aff > 0) {
        addLog($conn, $admin, 'add_product', '上架 ' . $name, $now);
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => '上架失败']);
    }
    $conn->close();
    exit;
}

if ($action === 'remove_product') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_products')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $id = intval($_POST['id'] ?? 0);
    $stmt = $conn->prepare("UPDATE products SET status = 0 WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    addLog($conn, $admin, 'remove_product', '下架商品 #' . $id, $now);
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'buy_product') {
    $username = $_POST['username'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $product_id = intval($_POST['product_id'] ?? 0);
    $couponId = intval($_POST['coupon_id'] ?? 0);
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ? AND status = 1");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $r = $stmt->get_result();
    $prod = $r->fetch_assoc();
    $stmt->close();
    if (!$prod) {
        echo json_encode(['success' => false, 'error' => '商品不存在或已下架']);
        $conn->close();
        exit;
    }
    if ($prod['limit_qty'] > 0 && $prod['sold'] >= $prod['limit_qty']) {
        echo json_encode(['success' => false, 'error' => '已售罄']);
        $conn->close();
        exit;
    }
    $perLimit = intval($prod['per_user_limit']);
    if ($perLimit > 0) {
        $stmt = $conn->prepare("SELECT COALESCE(SUM(quantity),0) as t FROM user_purchases WHERE username = ? AND product_id = ?");
        $stmt->bind_param("si", $username, $product_id);
        $stmt->execute();
        $r = $stmt->get_result();
        $bought = $r->fetch_assoc();
        $stmt->close();
        if (intval($bought['t']) >= $perLimit) {
            echo json_encode(['success' => false, 'error' => '您已达到此商品的限购数量']);
            $conn->close();
            exit;
        }
    }
    $price = floatval($prod['price']);
    $discount = 0;
    if ($couponId > 0) {
        $stmt = $conn->prepare("SELECT uc.*, c.type, c.value, c.min_spend, c.expires_at FROM user_coupons uc JOIN coupons c ON uc.coupon_id = c.id WHERE uc.id = ? AND uc.username = ? AND uc.used = 0");
        $stmt->bind_param("is", $couponId, $username);
        $stmt->execute();
        $r = $stmt->get_result();
        $coupon = $r->fetch_assoc();
        $stmt->close();
        if ($coupon && (!$coupon['expires_at'] || strtotime($coupon['expires_at']) > time()) && $price >= floatval($coupon['min_spend'])) {
            if ($coupon['type'] === 'fixed') $discount = floatval($coupon['value']);
            else if ($coupon['type'] === 'percent') $discount = round($price * floatval($coupon['value']) / 100, 2);
            else if ($coupon['type'] === 'threshold') $discount = floatval($coupon['value']);
            if ($discount > $price) $discount = $price;
        }
    }
    $finalPrice = round($price - $discount, 2);
    $stmt = $conn->prepare("SELECT points FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $user = $r->fetch_assoc();
    $stmt->close();
    if (!$user || floatval($user['points']) < $finalPrice) {
        echo json_encode(['success' => false, 'error' => '积分不足']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE users SET points = points - ? WHERE username = ? AND points >= ?");
        $stmt->bind_param("dsd", $finalPrice, $username, $finalPrice);
        $stmt->execute();
        $aff = $stmt->affected_rows;
        $stmt->close();
        if ($aff <= 0) throw new Exception('扣积分失败');
        $stmt = $conn->prepare("UPDATE products SET sold = sold + 1 WHERE id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $stmt->close();
        $order_id = genOrderId('PU');
        $pname = $prod['name'];
        $pid = intval($prod['id']);
        $stmt = $conn->prepare("INSERT INTO user_purchases (order_id, username, product_id, product_name, cost, quantity, time) VALUES (?, ?, ?, ?, ?, 1, ?)");
        $stmt->bind_param("ssisds", $order_id, $username, $pid, $pname, $finalPrice, $now);
        $stmt->execute();
        $stmt->close();
        if ($couponId > 0 && $discount > 0) {
            $stmt = $conn->prepare("UPDATE user_coupons SET used = 1, used_at = ? WHERE id = ?");
            $stmt->bind_param("si", $now, $couponId);
            $stmt->execute();
            $stmt->close();
        }
        if ($prod['type'] === 'random') {
            $min = intval($prod['min_points']) ?: 10;
            $max = intval($prod['max_points']) ?: 100;
            $randomPoints = rand($min, $max);
            $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE username = ?");
            $stmt->bind_param("ds", $randomPoints, $username);
            $stmt->execute();
            $stmt->close();
            addPointsLog($conn, $username, $randomPoints, 'random_reward', '随机积分券奖励', $order_id, $now);
            $msg = '购买成功，获得 ' . $randomPoints . ' 积分';
        } else {
            $filePath = $prod['file_path'] ?? '';
            $isOneTime = ($prod['type'] === 'file') ? 1 : 0;
            if (!empty($filePath)) {
                $stmt = $conn->prepare("INSERT INTO user_items (username, product_id, product_name, quantity, file_path, is_one_time, can_sell) VALUES (?, ?, ?, 1, ?, ?, 1)");
                $stmt->bind_param("sissi", $username, $pid, $pname, $filePath, $isOneTime);
                $stmt->execute();
                $stmt->close();
            } else {
                $stmt = $conn->prepare("SELECT id, quantity FROM user_items WHERE username = ? AND product_id = ? AND file_path IS NULL");
                $stmt->bind_param("si", $username, $pid);
                $stmt->execute();
                $r = $stmt->get_result();
                $exist = $r->fetch_assoc();
                $stmt->close();
                if ($exist) {
                    $stmt = $conn->prepare("UPDATE user_items SET quantity = quantity + 1 WHERE id = ?");
                    $stmt->bind_param("i", $exist['id']);
                    $stmt->execute();
                    $stmt->close();
                } else {
                    $stmt = $conn->prepare("INSERT INTO user_items (username, product_id, product_name, quantity, can_sell) VALUES (?, ?, ?, 1, 1)");
                    $stmt->bind_param("sis", $username, $pid, $pname);
                    $stmt->execute();
                    $stmt->close();
                }
            }
            $msg = '购买成功';
        }
        $stmt = $conn->prepare("DELETE FROM cart_items WHERE username = ? AND product_id = ?");
        $stmt->bind_param("si", $username, $product_id);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        addPointsLog($conn, $username, -$finalPrice, 'purchase', '购买 ' . $pname, $order_id, $now);
        echo json_encode(['success' => true, 'message' => $msg, 'order_id' => $order_id, 'discount' => $discount]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'buy_market_item') {
    $username = $_POST['username'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $listing_id = intval($_POST['listing_id'] ?? 0);
    $stmt = $conn->prepare("SELECT * FROM market_listings WHERE id = ? AND status = 1");
    $stmt->bind_param("i", $listing_id);
    $stmt->execute();
    $r = $stmt->get_result();
    $listing = $r->fetch_assoc();
    $stmt->close();
    if (!$listing) {
        echo json_encode(['success' => false, 'error' => '商品不存在']);
        $conn->close();
        exit;
    }
    if ($listing['seller'] === $username) {
        echo json_encode(['success' => false, 'error' => '不能购买自己的商品']);
        $conn->close();
        exit;
    }
    $price = floatval($listing['price']);
    $stmt = $conn->prepare("SELECT points FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $user = $r->fetch_assoc();
    $stmt->close();
    if (!$user || floatval($user['points']) < $price) {
        echo json_encode(['success' => false, 'error' => '积分不足']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE users SET points = points - ? WHERE username = ? AND points >= ?");
        $stmt->bind_param("dsd", $price, $username, $price);
        $stmt->execute();
        $aff = $stmt->affected_rows;
        $stmt->close();
        if ($aff <= 0) throw new Exception('扣款失败');
        $seller = $listing['seller'];
        $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE username = ?");
        $stmt->bind_param("ds", $price, $seller);
        $stmt->execute();
        $stmt->close();
        $stmt = $conn->prepare("UPDATE market_listings SET status = 0 WHERE id = ?");
        $stmt->bind_param("i", $listing_id);
        $stmt->execute();
        $stmt->close();
        $order_id = genOrderId('MT');
        $itemName = $listing['item_name'];
        $stmt = $conn->prepare("INSERT INTO market_trades (order_id, seller, buyer, item_name, price, time) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssds", $order_id, $seller, $username, $itemName, $price, $now);
        $stmt->execute();
        $stmt->close();
        $filePath = $listing['file_path'];
        $isOneTime = intval($listing['is_one_time']);
        if (!empty($filePath)) {
            $stmt = $conn->prepare("INSERT INTO user_items (username, product_id, product_name, quantity, file_path, is_one_time, can_sell) VALUES (?, 0, ?, 1, ?, ?, 1)");
            $stmt->bind_param("sssi", $username, $itemName, $filePath, $isOneTime);
            $stmt->execute();
            $stmt->close();
        } else {
            $stmt = $conn->prepare("INSERT INTO user_items (username, product_id, product_name, quantity, can_sell) VALUES (?, 0, ?, 1, 1)");
            $stmt->bind_param("ss", $username, $itemName);
            $stmt->execute();
            $stmt->close();
        }
        $conn->commit();
        addPointsLog($conn, $username, -$price, 'market_buy', '市场购买 ' . $itemName, $order_id, $now);
        addPointsLog($conn, $seller, $price, 'market_sell', '市场卖出 ' . $itemName, $order_id, $now);
        sendMessage($conn, 'system', $seller, '商品已售出', '您挂出的「' . $itemName . '」已被 ' . $username . ' 购买', $now);
        echo json_encode(['success' => true, 'order_id' => $order_id]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'request_change_price') {
    $username = $_POST['username'] ?? '';
    $listingId = intval($_POST['listing_id'] ?? 0);
    $newPrice = floatval($_POST['new_price'] ?? 0);
    if ($newPrice <= 0) {
        echo json_encode(['success' => false, 'error' => '价格必须大于0']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT * FROM market_listings WHERE id = ? AND status = 1");
    $stmt->bind_param("i", $listingId);
    $stmt->execute();
    $r = $stmt->get_result();
    $listing = $r->fetch_assoc();
    $stmt->close();
    if (!$listing) {
        echo json_encode(['success' => false, 'error' => '商品不存在']);
        $conn->close();
        exit;
    }
    if ($listing['seller'] === $username) {
        echo json_encode(['success' => false, 'error' => '不能给自己改价']);
        $conn->close();
        exit;
    }
    $data = json_encode(['listing_id' => $listingId, 'new_price' => $newPrice, 'buyer' => $username, 'item_name' => $listing['item_name']]);
    $seller = $listing['seller'];
    $title = '改价申请';
    $content = $username . ' 想以 ' . $newPrice . ' 积分购买您的「' . $listing['item_name'] . '」';
    sendMessage($conn, $username, $seller, $title, $content, $now, 'request', 'change_price', $data);
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'sell_item') {
    $username = $_POST['username'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $id = intval($_POST['id'] ?? 0);
    $price = floatval($_POST['price'] ?? 0);
    $customName = trim($_POST['custom_name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $icon = trim($_POST['icon'] ?? '');
    if ($price <= 0) {
        echo json_encode(['success' => false, 'error' => '价格必须大于0']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT * FROM user_items WHERE id = ? AND username = ?");
    $stmt->bind_param("is", $id, $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $item = $r->fetch_assoc();
    $stmt->close();
    if (!$item) {
        echo json_encode(['success' => false, 'error' => '道具不存在']);
        $conn->close();
        exit;
    }
    if (intval($item['can_sell']) !== 1) {
        echo json_encode(['success' => false, 'error' => '此道具不可出售']);
        $conn->close();
        exit;
    }
    $itemName = !empty($customName) ? $customName : $item['product_name'];
    $filePath = $item['file_path'];
    $isOneTime = intval($item['is_one_time']);
    $conn->begin_transaction();
    try {
        if (intval($item['quantity']) <= 1) {
            $stmt = $conn->prepare("DELETE FROM user_items WHERE id = ?");
            $stmt->bind_param("i", $id);
        } else {
            $stmt = $conn->prepare("UPDATE user_items SET quantity = quantity - 1 WHERE id = ?");
            $stmt->bind_param("i", $id);
        }
        $stmt->execute();
        $stmt->close();
        $order_id = genOrderId('ML');
        $stmt = $conn->prepare("INSERT INTO market_listings (order_id, seller, item_name, description, price, quantity, icon, file_path, is_one_time, status, created_at) VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?, 1, ?)");
        $stmt->bind_param("ssssdssis", $order_id, $username, $itemName, $description, $price, $icon, $filePath, $isOneTime, $now);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        echo json_encode(['success' => true, 'order_id' => $order_id]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'remove_market_listing') {
    $username = $_POST['username'] ?? '';
    $listing_id = intval($_POST['listing_id'] ?? 0);
    $stmt = $conn->prepare("SELECT * FROM market_listings WHERE id = ?");
    $stmt->bind_param("i", $listing_id);
    $stmt->execute();
    $r = $stmt->get_result();
    $listing = $r->fetch_assoc();
    $stmt->close();
    if (!$listing || $listing['seller'] !== $username) {
        echo json_encode(['success' => false, 'error' => '无法下架']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE market_listings SET status = 0 WHERE id = ?");
        $stmt->bind_param("i", $listing_id);
        $stmt->execute();
        $stmt->close();
        $itemName = $listing['item_name'];
        $filePath = $listing['file_path'];
        $isOneTime = intval($listing['is_one_time']);
        if (!empty($filePath)) {
            $stmt = $conn->prepare("INSERT INTO user_items (username, product_id, product_name, quantity, file_path, is_one_time, can_sell) VALUES (?, 0, ?, 1, ?, ?, 1)");
            $stmt->bind_param("sssi", $username, $itemName, $filePath, $isOneTime);
        } else {
            $stmt = $conn->prepare("INSERT INTO user_items (username, product_id, product_name, quantity, can_sell) VALUES (?, 0, ?, 1, 1)");
            $stmt->bind_param("ss", $username, $itemName);
        }
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'get_cart') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT c.*, p.name, p.price, p.file_path, p.type, p.icon FROM cart_items c LEFT JOIN products p ON c.product_id = p.id WHERE c.username = ? ORDER BY c.id DESC");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) $list[] = $row;
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'add_to_cart') {
    $username = $_POST['username'] ?? '';
    $product_id = intval($_POST['product_id'] ?? 0);
    $qty = max(1, intval($_POST['quantity'] ?? 1));
    $stmt = $conn->prepare("SELECT id FROM cart_items WHERE username = ? AND product_id = ?");
    $stmt->bind_param("si", $username, $product_id);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $stmt->close();
        $stmt = $conn->prepare("UPDATE cart_items SET quantity = quantity + ? WHERE username = ? AND product_id = ?");
        $stmt->bind_param("isi", $qty, $username, $product_id);
    } else {
        $stmt->close();
        $stmt = $conn->prepare("INSERT INTO cart_items (username, product_id, quantity, added_at) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("siis", $username, $product_id, $qty, $now);
    }
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'update_cart_item') {
    $username = $_POST['username'] ?? '';
    $id = intval($_POST['id'] ?? 0);
    $qty = max(1, intval($_POST['quantity'] ?? 1));
    $stmt = $conn->prepare("UPDATE cart_items SET quantity = ? WHERE id = ? AND username = ?");
    $stmt->bind_param("iis", $qty, $id, $username);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'remove_from_cart') {
    $username = $_POST['username'] ?? '';
    $id = intval($_POST['id'] ?? 0);
    $stmt = $conn->prepare("DELETE FROM cart_items WHERE id = ? AND username = ?");
    $stmt->bind_param("is", $id, $username);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'get_user_coupons') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT uc.*, c.name, c.type, c.value, c.min_spend, c.expires_at FROM user_coupons uc LEFT JOIN coupons c ON uc.coupon_id = c.id WHERE uc.username = ? AND uc.used = 0 ORDER BY uc.id DESC");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) $list[] = $row;
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'claim_coupon') {
    $username = $_POST['username'] ?? '';
    $code = strtoupper(trim($_POST['code'] ?? ''));
    $stmt = $conn->prepare("SELECT * FROM coupons WHERE code = ?");
    $stmt->bind_param("s", $code);
    $stmt->execute();
    $r = $stmt->get_result();
    $c = $r->fetch_assoc();
    $stmt->close();
    if (!$c) {
        echo json_encode(['success' => false, 'error' => '优惠券不存在']);
        $conn->close();
        exit;
    }
    if ($c['expires_at'] && strtotime($c['expires_at']) < time()) {
        echo json_encode(['success' => false, 'error' => '优惠券已过期']);
        $conn->close();
        exit;
    }
    if ($c['used_count'] >= $c['max_uses']) {
        echo json_encode(['success' => false, 'error' => '优惠券已领完']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE coupons SET used_count = used_count + 1 WHERE id = ?");
        $stmt->bind_param("i", $c['id']);
        $stmt->execute();
        $stmt->close();
        $stmt = $conn->prepare("INSERT INTO user_coupons (username, coupon_id, obtained_at) VALUES (?, ?, ?)");
        $stmt->bind_param("sis", $username, $c['id'], $now);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'admin_create_coupon') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_coupons')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $name = trim($_POST['name'] ?? '');
    $type = $_POST['type'] ?? 'fixed';
    $value = floatval($_POST['value'] ?? 0);
    $minSpend = floatval($_POST['min_spend'] ?? 0);
    $maxUses = intval($_POST['max_uses'] ?? 1);
    $expireDays = intval($_POST['expire_days'] ?? 30);
    if (empty($name) || $value <= 0) {
        echo json_encode(['success' => false, 'error' => '参数无效']);
        $conn->close();
        exit;
    }
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $code = '';
    for ($i = 0; $i < 10; $i++) $code .= $chars[rand(0, 35)];
    $expiresAt = date('Y-m-d H:i:s', strtotime("+$expireDays days"));
    $stmt = $conn->prepare("INSERT INTO coupons (code, name, type, value, min_spend, max_uses, expires_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssddiss", $code, $name, $type, $value, $minSpend, $maxUses, $expiresAt, $now);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true, 'code' => $code]);
    $conn->close();
    exit;
}

if ($action === 'get_user_items') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM user_items WHERE username = ? ORDER BY id DESC");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) $list[] = $row;
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'scan_items') {
    $list = [];
    if (is_dir($ITEMS_DIR)) {
        $dirs = scandir($ITEMS_DIR);
        foreach ($dirs as $dir) {
            if ($dir === '.' || $dir === '..') continue;
            $path = $ITEMS_DIR . $dir;
            if (is_dir($path)) {
                $cfgFile = $path . '/config.json';
                if (file_exists($cfgFile)) {
                    $cfg = json_decode(file_get_contents($cfgFile), true);
                    if ($cfg) {
                        $cfg['key'] = $dir;
                        $cfg['icon_url'] = '/Runfiles/items/' . $dir . '/' . ($cfg['icon'] ?? 'icon.png');
                        $list[] = $cfg;
                    }
                }
            }
        }
    }
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'use_item') {
    $username = $_POST['username'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $id = intval($_POST['id'] ?? 0);
    $stmt = $conn->prepare("SELECT * FROM user_items WHERE id = ? AND username = ?");
    $stmt->bind_param("is", $id, $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $item = $r->fetch_assoc();
    $stmt->close();
    if (!$item) {
        echo json_encode(['success' => false, 'error' => '道具不存在']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        if (intval($item['quantity']) <= 1) {
            $stmt = $conn->prepare("DELETE FROM user_items WHERE id = ?");
            $stmt->bind_param("i", $id);
        } else {
            $stmt = $conn->prepare("UPDATE user_items SET quantity = quantity - 1 WHERE id = ?");
            $stmt->bind_param("i", $id);
        }
        $stmt->execute();
        $stmt->close();
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $code = 'IT';
        for ($i = 0; $i < 8; $i++) $code .= $chars[rand(0, 35)];
        $pid = intval($item['product_id']);
        $pname = $item['product_name'];
        $itemKey = $item['item_key'];
        $fpath = $item['file_path'];
        $otime = intval($item['is_one_time']);
        $stmt = $conn->prepare("INSERT INTO item_use_codes (code, username, item_key, product_id, product_name, status, file_path, is_one_time, created_at) VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?)");
        $stmt->bind_param("sssisiss", $code, $username, $itemKey, $pid, $pname, $fpath, $otime, $now);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        if (!empty($itemKey) && file_exists($ITEMS_DIR . $itemKey . '/effect.php')) {
            $conn->query("UPDATE item_use_codes SET status = 1, used_at = '$now', used_by = 'system' WHERE code = '$code'");
            try {
                include $ITEMS_DIR . $itemKey . '/effect.php';
            } catch (Exception $e) {
            }
        }
        echo json_encode(['success' => true, 'code' => $code, 'product_name' => $pname]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'get_my_codes') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM item_use_codes WHERE username = ? ORDER BY id DESC LIMIT 100");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['created_at'] = date('Y-m-d H:i', strtotime($row['created_at']));
        if ($row['used_at']) $row['used_at'] = date('Y-m-d H:i', strtotime($row['used_at']));
        $list[] = $row;
    }
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'cancel_code') {
    $username = $_POST['username'] ?? '';
    $code = $_POST['code'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM item_use_codes WHERE code = ? AND username = ?");
    $stmt->bind_param("ss", $code, $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $uc = $r->fetch_assoc();
    $stmt->close();
    if (!$uc || intval($uc['status']) !== 0) {
        echo json_encode(['success' => false, 'error' => '无法取消']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        $pid = intval($uc['product_id']);
        $pname = $uc['product_name'];
        $fpath = $uc['file_path'];
        $otime = intval($uc['is_one_time']);
        $stmt = $conn->prepare("SELECT id, quantity FROM user_items WHERE username = ? AND product_id = ?");
        $stmt->bind_param("si", $username, $pid);
        $stmt->execute();
        $r = $stmt->get_result();
        $exist = $r->fetch_assoc();
        $stmt->close();
        if ($exist) {
            $stmt = $conn->prepare("UPDATE user_items SET quantity = quantity + 1 WHERE id = ?");
            $stmt->bind_param("i", $exist['id']);
        } else {
            $stmt = $conn->prepare("INSERT INTO user_items (username, product_id, product_name, quantity, file_path, is_one_time, can_sell) VALUES (?, ?, ?, 1, ?, ?, 1)");
            $stmt->bind_param("sissi", $username, $pid, $pname, $fpath, $otime);
        }
        $stmt->execute();
        $stmt->close();
        $stmt = $conn->prepare("DELETE FROM item_use_codes WHERE code = ?");
        $stmt->bind_param("s", $code);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'admin_get_codes') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_codes')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $filter = $_POST['filter'] ?? 'all';
    $keyword = trim($_POST['keyword'] ?? '');
    $sql = "SELECT * FROM item_use_codes WHERE 1=1";
    if ($filter === 'pending') $sql .= " AND status = 0";
    if ($filter === 'done') $sql .= " AND status = 1";
    if ($keyword !== '') {
        $kw = $conn->real_escape_string($keyword);
        $sql .= " AND (code LIKE '%$kw%' OR username LIKE '%$kw%' OR product_name LIKE '%$kw%')";
    }
    $sql .= " ORDER BY id DESC LIMIT 200";
    $r = $conn->query($sql);
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['created_at'] = date('Y-m-d H:i', strtotime($row['created_at']));
        if ($row['used_at']) $row['used_at'] = date('Y-m-d H:i', strtotime($row['used_at']));
        $list[] = $row;
    }
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'admin_redeem_code') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_codes')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $code = $_POST['code'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM item_use_codes WHERE code = ?");
    $stmt->bind_param("s", $code);
    $stmt->execute();
    $r = $stmt->get_result();
    $uc = $r->fetch_assoc();
    $stmt->close();
    if (!$uc || intval($uc['status']) !== 0) {
        echo json_encode(['success' => false, 'error' => '该码不存在或已核销']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("UPDATE item_use_codes SET status = 1, used_at = ?, used_by = ? WHERE code = ?");
    $stmt->bind_param("sss", $now, $admin, $code);
    $stmt->execute();
    $stmt->close();
    addLog($conn, $admin, 'redeem_item', '核销 ' . $code, $now);
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'download_item') {
    $id = intval($_POST['id'] ?? 0);
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM user_items WHERE id = ? AND username = ?");
    $stmt->bind_param("is", $id, $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $item = $r->fetch_assoc();
    $stmt->close();
    if (!$item) {
        echo json_encode(['success' => false, 'error' => '道具不存在']);
        $conn->close();
        exit;
    }
    if (intval($item['is_one_time']) === 1) {
        if (intval($item['quantity']) <= 1) {
            $stmt = $conn->prepare("DELETE FROM user_items WHERE id = ?");
        } else {
            $stmt = $conn->prepare("UPDATE user_items SET quantity = quantity - 1 WHERE id = ?");
        }
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
    }
    echo json_encode(['success' => true, 'file_path' => $item['file_path']]);
    $conn->close();
    exit;
}

if ($action === 'gift_item') {
    $from = $_POST['from_user'] ?? '';
    $to = $_POST['to_user'] ?? '';
    $item_id = intval($_POST['item_id'] ?? 0);
    if (!$from || !$to || !$item_id) {
        echo json_encode(['success' => false, 'error' => '参数无效']);
        $conn->close();
        exit;
    }
    $u1 = min($from, $to);
    $u2 = max($from, $to);
    $stmt = $conn->prepare("SELECT id FROM friends WHERE user1 = ? AND user2 = ?");
    $stmt->bind_param("ss", $u1, $u2);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows == 0) {
        $stmt->close();
        echo json_encode(['success' => false, 'error' => '对方不是你的好友']);
        $conn->close();
        exit;
    }
    $stmt->close();
    $stmt = $conn->prepare("SELECT * FROM user_items WHERE id = ? AND username = ?");
    $stmt->bind_param("is", $item_id, $from);
    $stmt->execute();
    $r = $stmt->get_result();
    $item = $r->fetch_assoc();
    $stmt->close();
    if (!$item) {
        echo json_encode(['success' => false, 'error' => '道具不存在']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        if (intval($item['quantity']) <= 1) {
            $stmt = $conn->prepare("DELETE FROM user_items WHERE id = ?");
            $stmt->bind_param("i", $item_id);
        } else {
            $stmt = $conn->prepare("UPDATE user_items SET quantity = quantity - 1 WHERE id = ?");
            $stmt->bind_param("i", $item_id);
        }
        $stmt->execute();
        $stmt->close();
        $pname = $item['product_name'];
        $fpath = $item['file_path'];
        $otime = intval($item['is_one_time']);
        $ikey = $item['item_key'];
        $stmt = $conn->prepare("INSERT INTO user_items (username, product_id, product_name, item_key, quantity, file_path, is_one_time, can_sell) VALUES (?, 0, ?, ?, 1, ?, ?, 1)");
        $stmt->bind_param("ssssi", $to, $pname, $ikey, $fpath, $otime);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        sendMessage($conn, 'system', $to, '收到礼物', $from . ' 赠送了您一个道具：' . $pname, $now);
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

// ===== END PART 4 =====


// ===== PART 5/5 =====

if ($action === 'get_lottery_list') {
    $r = $conn->query("SELECT l.*, (SELECT COUNT(*) FROM lottery_records WHERE lottery_id = l.id) as participants FROM lotteries l ORDER BY l.status DESC, (l.creator = 'wyx') DESC, l.id DESC");
    $list = [];
    while ($row = $r->fetch_assoc()) $list[] = $row;
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'get_lottery_info') {
    $id = intval($_POST['id'] ?? 0);
    $stmt = $conn->prepare("SELECT l.*, (SELECT COUNT(*) FROM lottery_records WHERE lottery_id = l.id) as participants FROM lotteries l WHERE l.id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $r = $stmt->get_result();
    $data = $r->fetch_assoc();
    $stmt->close();
    echo json_encode($data ?: ['error' => '抽奖不存在']);
    $conn->close();
    exit;
}

if ($action === 'create_lottery') {
    $name = trim($_POST['name'] ?? '');
    $desc = trim($_POST['desc'] ?? '');
    $type = $_POST['type'] ?? 'number';
    $unique = intval($_POST['unique'] ?? 1);
    $results = $_POST['results'] ?? '';
    $creator = $_POST['creator'] ?? '';
    $minNumber = intval($_POST['min_number'] ?? 1);
    $maxNumber = intval($_POST['max_number'] ?? 56);
    if (empty($name) || empty($creator)) {
        echo json_encode(['success' => false, 'error' => '参数无效']);
        $conn->close();
        exit;
    }
    if (!isAdminUser($conn, $creator)) {
        $allow = getSetting($conn, 'allow_user_lottery', '1');
        if ($allow !== '1') {
            echo json_encode(['success' => false, 'error' => '管理员已关闭用户创建抽奖']);
            $conn->close();
            exit;
        }
    }
    if ($type === 'number') {
        if ($minNumber < 1) $minNumber = 1;
        if ($maxNumber < $minNumber) $maxNumber = $minNumber;
        if ($maxNumber > 9999) $maxNumber = 9999;
    } else {
        $minNumber = 1;
        $maxNumber = 56;
    }
    $stmt = $conn->prepare("INSERT INTO lotteries (name, description, type, is_unique, results, creator, min_number, max_number, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssissiis", $name, $desc, $type, $unique, $results, $creator, $minNumber, $maxNumber, $now);
    $ok = $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => $ok]);
    $conn->close();
    exit;
}

if ($action === 'draw_lottery') {
    $id = intval($_POST['id'] ?? 0);
    $username = $_POST['username'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("SELECT * FROM lotteries WHERE id = ? FOR UPDATE");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $r = $stmt->get_result();
        $lottery = $r->fetch_assoc();
        $stmt->close();
        if (!$lottery) throw new Exception('抽奖不存在');
        if (intval($lottery['status']) === 0) throw new Exception('该抽奖已结束');
        if (intval($lottery['is_unique']) === 1) {
            $stmt = $conn->prepare("SELECT id FROM lottery_records WHERE lottery_id = ? AND username = ?");
            $stmt->bind_param("is", $id, $username);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) {
                $stmt->close();
                throw new Exception('您已经抽过此奖');
            }
            $stmt->close();
        }
        $result = '';
        if ($lottery['type'] === 'number') {
            $used = [];
            $res = $conn->query("SELECT result FROM lottery_records WHERE lottery_id = $id");
            while ($row = $res->fetch_assoc()) $used[] = intval($row['result']);
            $minN = intval($lottery['min_number']);
            $maxN = intval($lottery['max_number']);
            $available = [];
            for ($i = $minN; $i <= $maxN; $i++) {
                if (!in_array($i, $used)) $available[] = $i;
            }
            if (count($available) === 0) throw new Exception('号码已抽完');
            $result = $available[array_rand($available)];
        } else {
            $results = array_filter(explode("\n", $lottery['results']));
            $results = array_map('trim', $results);
            if (intval($lottery['is_unique']) === 1) {
                $used = [];
                $res = $conn->query("SELECT result FROM lottery_records WHERE lottery_id = $id");
                while ($row = $res->fetch_assoc()) $used[] = $row['result'];
                $results = array_values(array_diff($results, $used));
            } else {
                $results = array_values($results);
            }
            if (count($results) === 0) throw new Exception('结果已抽完');
            $result = $results[array_rand($results)];
        }
        $stmt = $conn->prepare("SELECT unique_id, realname FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $r = $stmt->get_result();
        $u = $r->fetch_assoc();
        $stmt->close();
        if (!$u) throw new Exception('用户不存在');
        $order_id = genOrderId('LOT');
        $lotteryName = $lottery['name'];
        $uniqueId = $u['unique_id'];
        $realname = $u['realname'];
        $stmt = $conn->prepare("INSERT INTO lottery_records (order_id, lottery_id, lottery_name, username, realname, unique_id, result, time) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sissssss", $order_id, $id, $lotteryName, $username, $realname, $uniqueId, $result, $now);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        echo json_encode([
            'success' => true,
            'data' => [
                'order_id' => $order_id,
                'unique_id' => $uniqueId,
                'username' => $username,
                'realname' => $realname,
                'result' => $result,
                'time' => $now
            ]
        ]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'end_lottery') {
    $id = intval($_POST['id'] ?? 0);
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM lotteries WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $r = $stmt->get_result();
    $lottery = $r->fetch_assoc();
    $stmt->close();
    if (!$lottery) {
        echo json_encode(['success' => false, 'error' => '抽奖不存在']);
        $conn->close();
        exit;
    }
    $isAdmin = isAdminUser($conn, $username);
    $isCreator = ($lottery['creator'] === $username);
    if (!$isAdmin && !$isCreator) {
        echo json_encode(['success' => false, 'error' => '无权结束此抽奖']);
        $conn->close();
        exit;
    }
    if (intval($lottery['status']) === 0) {
        echo json_encode(['success' => false, 'error' => '已结束']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE lotteries SET status = 0 WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        $r = $conn->query("SELECT DISTINCT username FROM lottery_records WHERE lottery_id = $id");
        $lname = $lottery['name'];
        while ($row = $r->fetch_assoc()) {
            sendMessage($conn, $username, $row['username'], '抽奖活动已结束', '您参与的抽奖「' . $lname . '」已结束，感谢参与！', $now);
        }
        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'delete_lottery') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_lottery')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $id = intval($_POST['id'] ?? 0);
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("DELETE FROM lottery_records WHERE lottery_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        $stmt = $conn->prepare("DELETE FROM lotteries WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        addLog($conn, $admin, 'del_lottery', '删除抽奖 #' . $id, $now);
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'query_lottery_records') {
    $keyword = $_POST['keyword'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM lottery_records WHERE username = ? OR order_id = ? OR realname = ? OR unique_id = ? ORDER BY id DESC LIMIT 50");
    $stmt->bind_param("ssss", $keyword, $keyword, $keyword, $keyword);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
        $list[] = $row;
    }
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'get_lottery_records') {
    $r = $conn->query("SELECT * FROM lottery_records ORDER BY id DESC LIMIT 100");
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
        $list[] = $row;
    }
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'get_my_lotteries') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT l.*, (SELECT COUNT(*) FROM lottery_records WHERE lottery_id = l.id) as participants FROM lotteries l WHERE l.creator = ? ORDER BY l.id DESC");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) $list[] = $row;
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'buy_lottery_ticket') {
    $username = $_POST['username'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $number = intval($_POST['number'] ?? 0);
    $count = intval($_POST['count'] ?? 1);
    if ($number < 1 || $number > 100) {
        echo json_encode(['success' => false, 'error' => '号码必须在1-100之间']);
        $conn->close();
        exit;
    }
    if ($count < 1 || $count > 100) {
        echo json_encode(['success' => false, 'error' => '注数必须1-100']);
        $conn->close();
        exit;
    }
    $price = intval(getSetting($conn, 'lottery_ticket_price', 30));
    $total = $price * $count;
    $stmt = $conn->prepare("SELECT points FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $user = $r->fetch_assoc();
    $stmt->close();
    if (!$user || floatval($user['points']) < $total) {
        echo json_encode(['success' => false, 'error' => '积分不足']);
        $conn->close();
        exit;
    }
    $drawTime = getSetting($conn, 'lottery_draw_time', '20:00');
    $drawDate = date('Y-m-d');
    if (strtotime($drawDate . ' ' . $drawTime) < time()) {
        $drawDate = date('Y-m-d', strtotime('+1 day'));
    }
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE users SET points = points - ? WHERE username = ? AND points >= ?");
        $stmt->bind_param("dsd", $total, $username, $total);
        $stmt->execute();
        $aff = $stmt->affected_rows;
        $stmt->close();
        if ($aff <= 0) throw new Exception('扣款失败');
        $orderIds = [];
        for ($i = 0; $i < $count; $i++) {
            $order_id = genOrderId('LB');
            $stmt = $conn->prepare("INSERT INTO lottery_tickets (order_id, username, number, price, draw_date, created_at) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssidss", $order_id, $username, $number, $price, $drawDate, $now);
            $stmt->execute();
            $stmt->close();
            $orderIds[] = $order_id;
        }
        $conn->commit();
        addPointsLog($conn, $username, -$total, 'lottery_bet', '购买 ' . $count . ' 注号码 ' . $number, $orderIds[0], $now);
        echo json_encode(['success' => true, 'order_ids' => $orderIds, 'draw_date' => $drawDate]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'get_my_tickets') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM lottery_tickets WHERE username = ? ORDER BY id DESC LIMIT 100");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['created_at'] = date('Y-m-d H:i', strtotime($row['created_at']));
        $list[] = $row;
    }
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'get_lottery_draws') {
    $r = $conn->query("SELECT * FROM lottery_draws ORDER BY draw_date DESC LIMIT 30");
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['drawn_at'] = date('Y-m-d H:i', strtotime($row['drawn_at']));
        $list[] = $row;
    }
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'draw_lottery_bet') {
    $admin = $_POST['admin'] ?? '';
    $isCron = ($_POST['cron'] ?? '') === '1';
    if (!$isCron && !isAdminUser($conn, $admin)) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $drawTime = getSetting($conn, 'lottery_draw_time', '20:00');
    $today = date('Y-m-d');
    $stmt = $conn->prepare("SELECT id FROM lottery_draws WHERE draw_date = ?");
    $stmt->bind_param("s", $today);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0 && !isAdminUser($conn, $admin)) {
        $stmt->close();
        echo json_encode(['success' => true, 'note' => '今日已开奖']);
        $conn->close();
        exit;
    }
    $stmt->close();
    $stmt = $conn->prepare("SELECT * FROM lottery_tickets WHERE draw_date = ? AND status = 0");
    $stmt->bind_param("s", $today);
    $stmt->execute();
    $r = $stmt->get_result();
    $tickets = [];
    $totalPool = 0;
    while ($row = $r->fetch_assoc()) {
        $tickets[] = $row;
        $totalPool += floatval($row['price']);
    }
    $stmt->close();
    if (count($tickets) === 0) {
        echo json_encode(['success' => false, 'error' => '今日无投注']);
        $conn->close();
        exit;
    }
    $poolRatio = intval(getSetting($conn, 'lottery_pool_ratio', 80)) / 100;
    $prizePool = $totalPool * $poolRatio;
    $winningNumber = rand(1, 100);
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("INSERT INTO lottery_draws (draw_date, winning_number, total_tickets, total_pool, prize_pool, drawn_at) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE winning_number = ?, total_tickets = ?, total_pool = ?, prize_pool = ?, drawn_at = ?");
        $totalTickets = count($tickets);
        $stmt->bind_param("siiddsidds", $today, $winningNumber, $totalTickets, $totalPool, $prizePool, $now, $winningNumber, $totalTickets, $totalPool, $prizePool, $now);
        $stmt->execute();
        $stmt->close();
        $winners = [];
        foreach ($tickets as $t) {
            if (intval($t['number']) === $winningNumber) {
                $winners[] = $t;
            }
        }
        if (count($winners) > 0) {
            $prizePerTicket = round($prizePool / count($winners), 2);
            foreach ($winners as $w) {
                $stmt = $conn->prepare("UPDATE lottery_tickets SET status = 1, prize = ? WHERE id = ?");
                $stmt->bind_param("di", $prizePerTicket, $w['id']);
                $stmt->execute();
                $stmt->close();
                $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE username = ?");
                $stmt->bind_param("ds", $prizePerTicket, $w['username']);
                $stmt->execute();
                $stmt->close();
                addPointsLog($conn, $w['username'], $prizePerTicket, 'lottery_win', '彩票中奖 号码' . $winningNumber, $w['order_id'], $now);
                sendMessage($conn, 'system', $w['username'], '彩票中奖', '恭喜！您号码 ' . $winningNumber . ' 中奖，获得 ' . $prizePerTicket . ' 积分', $now);
            }
        }
        $conn->query("UPDATE lottery_tickets SET status = 2 WHERE draw_date = '$today' AND status = 0");
        $conn->commit();
        addLog($conn, $admin ?: 'system', 'draw_lottery_bet', '开奖号码 ' . $winningNumber, $now);
        echo json_encode(['success' => true, 'winning_number' => $winningNumber, 'total_tickets' => count($tickets), 'prize_pool' => $prizePool, 'winners' => count($winners)]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'get_chips') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT chips FROM user_chips WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $uc = $r->fetch_assoc();
    $stmt->close();
    echo json_encode(['chips' => $uc ? intval($uc['chips']) : 0]);
    $conn->close();
    exit;
}

if ($action === 'buy_chips') {
    $username = $_POST['username'] ?? '';
    $chips = intval($_POST['chips'] ?? 0);
    if ($chips <= 0) {
        echo json_encode(['success' => false, 'error' => '数量无效']);
        $conn->close();
        exit;
    }
    $ratio = floatval(getSetting($conn, 'chip_ratio_buy', 1));
    $cost = round($chips * $ratio, 2);
    $stmt = $conn->prepare("SELECT points FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $user = $r->fetch_assoc();
    $stmt->close();
    if (!$user || floatval($user['points']) < $cost) {
        echo json_encode(['success' => false, 'error' => '积分不足']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE users SET points = points - ? WHERE username = ? AND points >= ?");
        $stmt->bind_param("dsd", $cost, $username, $cost);
        $stmt->execute();
        $aff = $stmt->affected_rows;
        $stmt->close();
        if ($aff <= 0) throw new Exception('扣款失败');
        $stmt = $conn->prepare("INSERT INTO user_chips (username, chips) VALUES (?, ?) ON DUPLICATE KEY UPDATE chips = chips + ?");
        $stmt->bind_param("sii", $username, $chips, $chips);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        addPointsLog($conn, $username, -$cost, 'chip_buy', '购买 ' . $chips . ' 筹码', '', $now);
        echo json_encode(['success' => true, 'chips' => $chips, 'cost' => $cost]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'sell_chips') {
    $username = $_POST['username'] ?? '';
    $chips = intval($_POST['chips'] ?? 0);
    if ($chips <= 0) {
        echo json_encode(['success' => false, 'error' => '数量无效']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT chips FROM user_chips WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $uc = $r->fetch_assoc();
    $stmt->close();
    if (!$uc || intval($uc['chips']) < $chips) {
        echo json_encode(['success' => false, 'error' => '筹码不足']);
        $conn->close();
        exit;
    }
    $ratio = floatval(getSetting($conn, 'chip_ratio_sell', 0.9));
    $gain = round($chips * $ratio, 2);
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE user_chips SET chips = chips - ? WHERE username = ?");
        $stmt->bind_param("is", $chips, $username);
        $stmt->execute();
        $stmt->close();
        $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE username = ?");
        $stmt->bind_param("ds", $gain, $username);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        addPointsLog($conn, $username, $gain, 'chip_sell', '卖出 ' . $chips . ' 筹码', '', $now);
        echo json_encode(['success' => true, 'points' => $gain]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

function getCardsDeck() {
    $suits = ['H', 'D', 'S', 'C'];
    $ranks = ['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
    $deck = [];
    foreach ($suits as $s) {
        foreach ($ranks as $r) $deck[] = $s . $r;
    }
    shuffle($deck);
    return $deck;
}

function rankValue($rank) {
    $map = ['2'=>2,'3'=>3,'4'=>4,'5'=>5,'6'=>6,'7'=>7,'8'=>8,'9'=>9,'10'=>10,'J'=>11,'Q'=>12,'K'=>13,'A'=>14];
    return $map[$rank] ?? 0;
}

function calcHandType($cards) {
    $suits = [];
    $ranks = [];
    foreach ($cards as $c) {
        $suits[] = $c[0];
        $ranks[] = rankValue(substr($c, 1));
    }
    rsort($ranks);
    $isFlush = (count(array_unique($suits)) === 1);
    $isStraight = false;
    if ($ranks[0] - $ranks[1] === 1 && $ranks[1] - $ranks[2] === 1) $isStraight = true;
    if ($ranks[0] === 14 && $ranks[1] === 3 && $ranks[2] === 2) $isStraight = true;
    $isTriple = ($ranks[0] === $ranks[1] && $ranks[1] === $ranks[2]);
    $isPair = ($ranks[0] === $ranks[1] || $ranks[1] === $ranks[2]);
    $type = 1;
    $tb = 0;
    if ($isTriple) { $type = 6; $tb = $ranks[0]; }
    elseif ($isFlush && $isStraight) { $type = 5; $tb = ($ranks[0] === 14 && $ranks[1] === 3) ? 3 : $ranks[0]; }
    elseif ($isFlush) { $type = 4; $tb = $ranks[0] * 10000 + $ranks[1] * 100 + $ranks[2]; }
    elseif ($isStraight) { $type = 3; $tb = ($ranks[0] === 14 && $ranks[1] === 3) ? 3 : $ranks[0]; }
    elseif ($isPair) {
        $type = 2;
        $pairRank = ($ranks[0] === $ranks[1]) ? $ranks[0] : $ranks[1];
        $single = ($ranks[0] === $ranks[1]) ? $ranks[2] : $ranks[0];
        $tb = $pairRank * 100 + $single;
    } else { $type = 1; $tb = $ranks[0] * 10000 + $ranks[1] * 100 + $ranks[2]; }
    return ['type' => $type, 'tiebreaker' => $tb];
}

function compareHands($h1, $h2) {
    $a = calcHandType($h1);
    $b = calcHandType($h2);
    if ($a['type'] !== $b['type']) return $a['type'] > $b['type'] ? 1 : -1;
    if ($a['tiebreaker'] !== $b['tiebreaker']) return $a['tiebreaker'] > $b['tiebreaker'] ? 1 : -1;
    return 0;
}

function handTypeName($t) {
    $names = [1 => '单张', 2 => '对子', 3 => '顺子', 4 => '金花', 5 => '顺金', 6 => '豹子'];
    return $names[$t] ?? '未知';
}

if ($action === 'create_room') {
    $owner = $_POST['owner'] ?? '';
    $roomName = trim($_POST['room_name'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $minBet = intval($_POST['min_bet'] ?? 10);
    if (!$owner || !$roomName) {
        echo json_encode(['success' => false, 'error' => '参数无效']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("INSERT INTO game_rooms (room_name, room_password, owner, min_bet, base_bet, status, game_state, created_at) VALUES (?, ?, ?, ?, ?, 0, 'waiting', ?)");
    $stmt->bind_param("sssiis", $roomName, $password, $owner, $minBet, $minBet, $now);
    $stmt->execute();
    $roomId = $conn->insert_id;
    $stmt->close();
    echo json_encode(['success' => true, 'room_id' => $roomId]);
    $conn->close();
    exit;
}

if ($action === 'get_rooms') {
    $r = $conn->query("SELECT r.*, (SELECT COUNT(*) FROM game_players WHERE room_id = r.id) as players FROM game_rooms r WHERE r.status < 2 ORDER BY r.id DESC LIMIT 50");
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['has_password'] = !empty($row['room_password']);
        unset($row['room_password']);
        $list[] = $row;
    }
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'join_room') {
    $username = $_POST['username'] ?? '';
    $roomId = intval($_POST['room_id'] ?? 0);
    $password = $_POST['password'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT * FROM game_rooms WHERE id = ?");
    $stmt->bind_param("i", $roomId);
    $stmt->execute();
    $r = $stmt->get_result();
    $room = $r->fetch_assoc();
    $stmt->close();
    if (!$room) {
        echo json_encode(['success' => false, 'error' => '房间不存在']);
        $conn->close();
        exit;
    }
    if ($room['room_password'] && $room['room_password'] !== $password) {
        echo json_encode(['success' => false, 'error' => '房间密码错误']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT COUNT(*) as c FROM game_players WHERE room_id = ?");
    $stmt->bind_param("i", $roomId);
    $stmt->execute();
    $r = $stmt->get_result();
    $count = $r->fetch_assoc();
    $stmt->close();
    if (intval($count['c']) >= intval($room['max_players'])) {
        echo json_encode(['success' => false, 'error' => '房间已满']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT id FROM game_players WHERE room_id = ? AND username = ?");
    $stmt->bind_param("is", $roomId, $username);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows === 0) {
        $stmt->close();
        $stmt = $conn->prepare("SELECT COALESCE(MAX(seat_num), -1) as m FROM game_players WHERE room_id = ?");
        $stmt->bind_param("i", $roomId);
        $stmt->execute();
        $r = $stmt->get_result();
        $maxSeat = $r->fetch_assoc();
        $stmt->close();
        $seat = intval($maxSeat['m']) + 1;
        $stmt = $conn->prepare("INSERT INTO game_players (room_id, username, seat_num, joined_at) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isis", $roomId, $username, $seat, $now);
        $stmt->execute();
        $stmt->close();
    } else {
        $stmt->close();
    }
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'start_game') {
    $username = $_POST['username'] ?? '';
    $roomId = intval($_POST['room_id'] ?? 0);
    $stmt = $conn->prepare("SELECT * FROM game_rooms WHERE id = ?");
    $stmt->bind_param("i", $roomId);
    $stmt->execute();
    $r = $stmt->get_result();
    $room = $r->fetch_assoc();
    $stmt->close();
    if (!$room) {
        echo json_encode(['success' => false, 'error' => '房间不存在']);
        $conn->close();
        exit;
    }
    if ($room['owner'] !== $username) {
        echo json_encode(['success' => false, 'error' => '只有房主能开始']);
        $conn->close();
        exit;
    }
    if ($room['game_state'] === 'playing') {
        echo json_encode(['success' => false, 'error' => '游戏已开始']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT p.*, c.chips FROM game_players p LEFT JOIN user_chips c ON p.username = c.username WHERE p.room_id = ? ORDER BY p.seat_num");
    $stmt->bind_param("i", $roomId);
    $stmt->execute();
    $r = $stmt->get_result();
    $players = [];
    while ($row = $r->fetch_assoc()) $players[] = $row;
    $stmt->close();
    if (count($players) < 2) {
        echo json_encode(['success' => false, 'error' => '至少需要2人']);
        $conn->close();
        exit;
    }
    $baseBet = intval($room['base_bet']);
    foreach ($players as $p) {
        if (intval($p['chips']) < $baseBet) {
            echo json_encode(['success' => false, 'error' => $p['username'] . ' 筹码不足']);
            $conn->close();
            exit;
        }
    }
    $deck = getCardsDeck();
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE game_rooms SET game_state = 'playing', pot = 0, current_turn = '', round_num = 1, max_bet = ? WHERE id = ?");
        $stmt->bind_param("ii", $baseBet, $roomId);
        $stmt->execute();
        $stmt->close();
        $idx = 0;
        foreach ($players as $p) {
            $cards = [$deck[$idx], $deck[$idx+1], $deck[$idx+2]];
            $idx += 3;
            $cardsJson = json_encode($cards);
            $uname = $p['username'];
            $stmt = $conn->prepare("UPDATE game_players SET cards = ?, bet = ?, round_bet = ?, play_status = 1 WHERE room_id = ? AND username = ?");
            $stmt->bind_param("siiss", $cardsJson, $baseBet, $baseBet, $roomId, $uname);
            $stmt->execute();
            $stmt->close();
            $stmt = $conn->prepare("UPDATE user_chips SET chips = chips - ? WHERE username = ?");
            $stmt->bind_param("is", $baseBet, $uname);
            $stmt->execute();
            $stmt->close();
        }
        $stmt = $conn->prepare("UPDATE game_rooms SET pot = ? WHERE id = ?");
        $totalPot = $baseBet * count($players);
        $stmt->bind_param("ii", $totalPot, $roomId);
        $stmt->execute();
        $stmt->close();
        $firstPlayer = $players[0]['username'];
        $stmt = $conn->prepare("UPDATE game_rooms SET current_turn = ? WHERE id = ?");
        $stmt->bind_param("si", $firstPlayer, $roomId);
        $stmt->execute();
        $stmt->close();
        $stmt = $conn->prepare("INSERT INTO game_actions (room_id, username, action, detail, time) VALUES (?, 'system', 'start', '游戏开始', ?)");
        $stmt->bind_param("is", $roomId, $now);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'get_room_state') {
    $roomId = intval($_POST['room_id'] ?? 0);
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM game_rooms WHERE id = ?");
    $stmt->bind_param("i", $roomId);
    $stmt->execute();
    $r = $stmt->get_result();
    $room = $r->fetch_assoc();
    $stmt->close();
    if (!$room) {
        echo json_encode(['success' => false, 'error' => '房间不存在']);
        $conn->close();
        exit;
    }
    unset($room['room_password']);
    $stmt = $conn->prepare("SELECT p.username, p.seat_num, p.bet, p.round_bet, p.play_status, p.cards, c.chips FROM game_players p LEFT JOIN user_chips c ON p.username = c.username WHERE p.room_id = ? ORDER BY p.seat_num");
    $stmt->bind_param("i", $roomId);
    $stmt->execute();
    $r = $stmt->get_result();
    $players = [];
    while ($row = $r->fetch_assoc()) {
        $cards = json_decode($row['cards'], true);
        $isMe = ($row['username'] === $username);
        $cardCount = $cards ? count($cards) : 0;
        $cardDisplay = [];
        $handType = '';
        if ($isMe && $cards && $room['game_state'] === 'playing') {
            foreach ($cards as $c) $cardDisplay[] = $c;
            $ht = calcHandType($cards);
            $handType = handTypeName($ht['type']);
        }
        $players[] = [
            'username' => $row['username'],
            'seat_num' => intval($row['seat_num']),
            'bet' => intval($row['bet']),
            'round_bet' => intval($row['round_bet']),
            'play_status' => intval($row['play_status']),
            'chips' => intval($row['chips'] ?? 0),
            'card_count' => $cardCount,
            'cards' => $cardDisplay,
            'hand_type' => $handType,
            'is_me' => $isMe
        ];
    }
    $stmt->close();
    $stmt = $conn->prepare("SELECT * FROM game_actions WHERE room_id = ? ORDER BY id DESC LIMIT 30");
    $stmt->bind_param("i", $roomId);
    $stmt->execute();
    $r = $stmt->get_result();
    $actions = [];
    while ($row = $r->fetch_assoc()) {
        $row['time'] = date('H:i:s', strtotime($row['time']));
        $actions[] = $row;
    }
    $stmt->close();
    echo json_encode(['room' => $room, 'players' => $players, 'actions' => $actions]);
    $conn->close();
    exit;
}

if ($action === 'game_action') {
    $username = $_POST['username'] ?? '';
    $roomId = intval($_POST['room_id'] ?? 0);
    $type = $_POST['type'] ?? '';
    $amount = intval($_POST['amount'] ?? 0);
    $stmt = $conn->prepare("SELECT * FROM game_rooms WHERE id = ?");
    $stmt->bind_param("i", $roomId);
    $stmt->execute();
    $r = $stmt->get_result();
    $room = $r->fetch_assoc();
    $stmt->close();
    if (!$room) {
        echo json_encode(['success' => false, 'error' => '房间不存在']);
        $conn->close();
        exit;
    }
    if ($room['game_state'] !== 'playing') {
        echo json_encode(['success' => false, 'error' => '游戏未开始']);
        $conn->close();
        exit;
    }
    if ($room['current_turn'] !== $username) {
        echo json_encode(['success' => false, 'error' => '还没轮到你']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT * FROM game_players WHERE room_id = ? AND username = ?");
    $stmt->bind_param("is", $roomId, $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $me = $r->fetch_assoc();
    $stmt->close();
    if (!$me || intval($me['play_status']) !== 1) {
        echo json_encode(['success' => false, 'error' => '你已弃牌']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT chips FROM user_chips WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $chips = $r->fetch_assoc();
    $stmt->close();
    $myChips = intval($chips['chips'] ?? 0);
    $maxBet = intval($room['max_bet']);
    $conn->begin_transaction();
    try {
        if ($type === 'fold') {
            $stmt = $conn->prepare("UPDATE game_players SET play_status = 0 WHERE room_id = ? AND username = ?");
            $stmt->bind_param("is", $roomId, $username);
            $stmt->execute();
            $stmt->close();
            $stmt = $conn->prepare("INSERT INTO game_actions (room_id, username, action, time) VALUES (?, ?, '弃牌', ?)");
            $stmt->bind_param("iss", $roomId, $username, $now);
            $stmt->execute();
            $stmt->close();
        } elseif ($type === 'call') {
            $need = $maxBet - intval($me['round_bet']);
            if ($need < 0) $need = 0;
            if ($myChips < $need) throw new Exception('筹码不足');
            $stmt = $conn->prepare("UPDATE user_chips SET chips = chips - ? WHERE username = ?");
            $stmt->bind_param("is", $need, $username);
            $stmt->execute();
            $stmt->close();
            $stmt = $conn->prepare("UPDATE game_players SET bet = bet + ?, round_bet = round_bet + ? WHERE room_id = ? AND username = ?");
            $stmt->bind_param("iiis", $need, $need, $roomId, $username);
            $stmt->execute();
            $stmt->close();
            $stmt = $conn->prepare("UPDATE game_rooms SET pot = pot + ? WHERE id = ?");
            $stmt->bind_param("ii", $need, $roomId);
            $stmt->execute();
            $stmt->close();
            $stmt = $conn->prepare("INSERT INTO game_actions (room_id, username, action, amount, time) VALUES (?, ?, '跟注', ?, ?)");
            $stmt->bind_param("isis", $roomId, $username, $need, $now);
            $stmt->execute();
            $stmt->close();
        } elseif ($type === 'raise') {
            if ($amount <= $maxBet) throw new Exception('加注必须大于当前注');
            $need = $amount - intval($me['round_bet']);
            if ($myChips < $need) throw new Exception('筹码不足');
            $stmt = $conn->prepare("UPDATE user_chips SET chips = chips - ? WHERE username = ?");
            $stmt->bind_param("is", $need, $username);
            $stmt->execute();
            $stmt->close();
            $stmt = $conn->prepare("UPDATE game_players SET bet = bet + ?, round_bet = round_bet + ? WHERE room_id = ? AND username = ?");
            $stmt->bind_param("iiis", $need, $need, $roomId, $username);
            $stmt->execute();
            $stmt->close();
            $stmt = $conn->prepare("UPDATE game_rooms SET pot = pot + ?, max_bet = ? WHERE id = ?");
            $stmt->bind_param("iii", $need, $amount, $roomId);
            $stmt->execute();
            $stmt->close();
            $stmt = $conn->prepare("INSERT INTO game_actions (room_id, username, action, amount, time) VALUES (?, ?, '加注', ?, ?)");
            $stmt->bind_param("isis", $roomId, $username, $amount, $now);
            $stmt->execute();
            $stmt->close();
        } elseif ($type === 'compare') {
            $stmt = $conn->prepare("SELECT * FROM game_players WHERE room_id = ? AND play_status = 1 AND username != ? ORDER BY seat_num");
            $stmt->bind_param("is", $roomId, $username);
            $stmt->execute();
            $r = $stmt->get_result();
            $opponents = [];
            while ($row = $r->fetch_assoc()) $opponents[] = $row;
            $stmt->close();
            if (count($opponents) === 0) throw new Exception('没有可比的玩家');
            $opponent = $opponents[0];
            $myCards = json_decode($me['cards'], true);
            $oppCards = json_decode($opponent['cards'], true);
            $result = compareHands($myCards, $oppCards);
            $compareCost = $maxBet * 2;
            if ($myChips < $compareCost) throw new Exception('筹码不足（比牌需双倍注）');
            $stmt = $conn->prepare("UPDATE user_chips SET chips = chips - ? WHERE username = ?");
            $stmt->bind_param("is", $compareCost, $username);
            $stmt->execute();
            $stmt->close();
            $stmt = $conn->prepare("UPDATE game_players SET bet = bet + ?, round_bet = round_bet + ? WHERE room_id = ? AND username = ?");
            $stmt->bind_param("iiis", $compareCost, $compareCost, $roomId, $username);
            $stmt->execute();
            $stmt->close();
            $stmt = $conn->prepare("UPDATE game_rooms SET pot = pot + ? WHERE id = ?");
            $stmt->bind_param("ii", $compareCost, $roomId);
            $stmt->execute();
            $stmt->close();
            if ($result > 0) {
                $stmt = $conn->prepare("UPDATE game_players SET play_status = 0 WHERE room_id = ? AND username = ?");
                $stmt->bind_param("is", $roomId, $opponent['username']);
                $stmt->execute();
                $stmt->close();
                $detail = '战胜 ' . $opponent['username'];
            } elseif ($result < 0) {
                $stmt = $conn->prepare("UPDATE game_players SET play_status = 0 WHERE room_id = ? AND username = ?");
                $stmt->bind_param("is", $roomId, $username);
                $stmt->execute();
                $stmt->close();
                $detail = '败于 ' . $opponent['username'];
            } else {
                $stmt = $conn->prepare("UPDATE game_players SET play_status = 0 WHERE room_id = ? AND username = ?");
                $stmt->bind_param("is", $roomId, $username);
                $stmt->execute();
                $stmt->close();
                $detail = '平局，发起方输';
            }
            $stmt = $conn->prepare("INSERT INTO game_actions (room_id, username, action, detail, time) VALUES (?, ?, '比牌', ?, ?)");
            $stmt->bind_param("isss", $roomId, $username, $detail, $now);
            $stmt->execute();
            $stmt->close();
        }
        $stmt = $conn->prepare("SELECT COUNT(*) as c FROM game_players WHERE room_id = ? AND play_status = 1");
        $stmt->bind_param("i", $roomId);
        $stmt->execute();
        $r = $stmt->get_result();
        $activeCount = $r->fetch_assoc();
        $stmt->close();
        $cnt = intval($activeCount['c']);
        if ($cnt <= 1) {
            $stmt = $conn->prepare("SELECT username FROM game_players WHERE room_id = ? AND play_status = 1 LIMIT 1");
            $stmt->bind_param("i", $roomId);
            $stmt->execute();
            $r = $stmt->get_result();
            $winner = $r->fetch_assoc();
            $stmt->close();
            if ($winner) {
                $stmt = $conn->prepare("SELECT pot FROM game_rooms WHERE id = ?");
                $stmt->bind_param("i", $roomId);
                $stmt->execute();
                $r = $stmt->get_result();
                $potNow = $r->fetch_assoc();
                $stmt->close();
                $finalPot = intval($potNow['pot']);
                $stmt = $conn->prepare("UPDATE user_chips SET chips = chips + ? WHERE username = ?");
                $stmt->bind_param("is", $finalPot, $winner['username']);
                $stmt->execute();
                $stmt->close();
                $stmt = $conn->prepare("UPDATE game_rooms SET game_state = 'ended', pot = 0 WHERE id = ?");
                $stmt->bind_param("i", $roomId);
                $stmt->execute();
                $stmt->close();
                $detail = $winner['username'] . ' 获胜 +' . $finalPot;
                $stmt = $conn->prepare("INSERT INTO game_actions (room_id, username, action, detail, time) VALUES (?, 'system', 'end', ?, ?)");
                $stmt->bind_param("iss", $roomId, $detail, $now);
                $stmt->execute();
                $stmt->close();
            }
        } else {
            $stmt = $conn->prepare("SELECT username FROM game_players WHERE room_id = ? AND play_status = 1 AND seat_num > ? ORDER BY seat_num LIMIT 1");
            $stmt->bind_param("ii", $roomId, $me['seat_num']);
            $stmt->execute();
            $r = $stmt->get_result();
            $next = $r->fetch_assoc();
            $stmt->close();
            if (!$next) {
                $stmt = $conn->prepare("SELECT username FROM game_players WHERE room_id = ? AND play_status = 1 ORDER BY seat_num LIMIT 1");
                $stmt->bind_param("i", $roomId);
                $stmt->execute();
                $r = $stmt->get_result();
                $next = $r->fetch_assoc();
                $stmt->close();
            }
            if ($next) {
                $stmt = $conn->prepare("UPDATE game_rooms SET current_turn = ? WHERE id = ?");
                $stmt->bind_param("si", $next['username'], $roomId);
                $stmt->execute();
                $stmt->close();
            }
            $stmt = $conn->prepare("SELECT COUNT(*) as c FROM game_players WHERE room_id = ? AND play_status = 1 AND round_bet = ?");
            $stmt->bind_param("ii", $roomId, $maxBet);
            $stmt->execute();
            $r = $stmt->get_result();
            $sameBet = $r->fetch_assoc();
            $stmt->close();
            if (intval($sameBet['c']) === $cnt) {
                $stmt = $conn->prepare("UPDATE game_players SET round_bet = 0 WHERE room_id = ?");
                $stmt->bind_param("i", $roomId);
                $stmt->execute();
                $stmt->close();
                $stmt = $conn->prepare("UPDATE game_rooms SET round_num = round_num + 1 WHERE id = ?");
                $stmt->bind_param("i", $roomId);
                $stmt->execute();
                $stmt->close();
            }
        }
        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}


if ($action === 'leave_room') {
    $username = $_POST['username'] ?? '';
    $roomId = intval($_POST['room_id'] ?? 0);
    $stmt = $conn->prepare("SELECT * FROM game_rooms WHERE id = ?");
    $stmt->bind_param("i", $roomId);
    $stmt->execute();
    $r = $stmt->get_result();
    $room = $r->fetch_assoc();
    $stmt->close();
    if ($room && $room['game_state'] === 'playing') {
        echo json_encode(['success' => false, 'error' => '游戏中不能离开']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("DELETE FROM game_players WHERE room_id = ? AND username = ?");
    $stmt->bind_param("is", $roomId, $username);
    $stmt->execute();
    $stmt->close();
    if ($room && $room['owner'] === $username) {
        $stmt = $conn->prepare("SELECT username FROM game_players WHERE room_id = ? ORDER BY seat_num LIMIT 1");
        $stmt->bind_param("i", $roomId);
        $stmt->execute();
        $r = $stmt->get_result();
        $remaining = $r->fetch_assoc();
        $stmt->close();
        if ($remaining) {
            $stmt = $conn->prepare("UPDATE game_rooms SET owner = ? WHERE id = ?");
            $stmt->bind_param("si", $remaining['username'], $roomId);
            $stmt->execute();
            $stmt->close();
        } else {
            $stmt = $conn->prepare("DELETE FROM game_rooms WHERE id = ?");
            $stmt->bind_param("i", $roomId);
            $stmt->execute();
            $stmt->close();
        }
    }
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'get_wheel') {
    $r = $conn->query("SELECT * FROM wheels WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
    $wheel = $r->fetch_assoc();
    if (!$wheel) {
        echo json_encode(['success' => false, 'error' => '暂无转盘']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT * FROM wheel_prizes WHERE wheel_id = ? ORDER BY id");
    $stmt->bind_param("i", $wheel['id']);
    $stmt->execute();
    $r = $stmt->get_result();
    $prizes = [];
    while ($row = $r->fetch_assoc()) $prizes[] = $row;
    $stmt->close();
    $wheel['prizes'] = $prizes;
    echo json_encode($wheel);
    $conn->close();
    exit;
}

if ($action === 'spin_wheel') {
    $username = $_POST['username'] ?? '';
    $wheelId = intval($_POST['wheel_id'] ?? 0);
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT * FROM wheels WHERE id = ?");
    $stmt->bind_param("i", $wheelId);
    $stmt->execute();
    $r = $stmt->get_result();
    $wheel = $r->fetch_assoc();
    $stmt->close();
    if (!$wheel) {
        echo json_encode(['success' => false, 'error' => '转盘不存在']);
        $conn->close();
        exit;
    }
    $today = date('Y-m-d');
    $stmt = $conn->prepare("SELECT * FROM user_wheel_quota WHERE username = ? AND wheel_id = ?");
    $stmt->bind_param("si", $username, $wheelId);
    $stmt->execute();
    $r = $stmt->get_result();
    $quota = $r->fetch_assoc();
    $stmt->close();
    $used = 0;
    if ($quota) {
        if ($quota['last_reset'] !== $today) {
            $stmt = $conn->prepare("UPDATE user_wheel_quota SET used_today = 0, last_reset = ? WHERE id = ?");
            $stmt->bind_param("si", $today, $quota['id']);
            $stmt->execute();
            $stmt->close();
            $used = 0;
        } else {
            $used = intval($quota['used_today']);
        }
    } else {
        $stmt = $conn->prepare("INSERT INTO user_wheel_quota (username, wheel_id, used_today, last_reset) VALUES (?, ?, 0, ?)");
        $stmt->bind_param("sis", $username, $wheelId, $today);
        $stmt->execute();
        $stmt->close();
    }
    $free = intval($wheel['free_per_day']);
    $cost = intval($wheel['cost']);
    $extraCost = 0;
    if ($used >= $free) {
        $extraCost = $cost > 0 ? $cost : 50;
        $stmt = $conn->prepare("SELECT points FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $r = $stmt->get_result();
        $user = $r->fetch_assoc();
        $stmt->close();
        if (!$user || floatval($user['points']) < $extraCost) {
            echo json_encode(['success' => false, 'error' => '积分不足，需 ' . $extraCost . ' 积分']);
            $conn->close();
            exit;
        }
    }
    $conn->begin_transaction();
    try {
        if ($extraCost > 0) {
            $stmt = $conn->prepare("UPDATE users SET points = points - ? WHERE username = ? AND points >= ?");
            $stmt->bind_param("dsd", $extraCost, $username, $extraCost);
            $stmt->execute();
            $aff = $stmt->affected_rows;
            $stmt->close();
            if ($aff <= 0) throw new Exception('扣款失败');
        }
        $stmt = $conn->prepare("SELECT * FROM wheel_prizes WHERE wheel_id = ?");
        $stmt->bind_param("i", $wheelId);
        $stmt->execute();
        $r = $stmt->get_result();
        $prizes = [];
        $totalWeight = 0;
        while ($row = $r->fetch_assoc()) {
            $prizes[] = $row;
            $totalWeight += intval($row['weight']);
        }
        $stmt->close();
        if ($totalWeight <= 0) throw new Exception('转盘配置错误');
        $rand = rand(1, $totalWeight);
        $cum = 0;
        $selected = null;
        foreach ($prizes as $p) {
            $cum += intval($p['weight']);
            if ($rand <= $cum) {
                $selected = $p;
                break;
            }
        }
        if (!$selected) $selected = $prizes[count($prizes) - 1];
        $order_id = genOrderId('WH');
        $pid = intval($selected['id']);
        $plabel = $selected['label'];
        $stmt = $conn->prepare("INSERT INTO wheel_records (order_id, wheel_id, username, prize_id, prize_label, time) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sisiss", $order_id, $wheelId, $username, $pid, $plabel, $now);
        $stmt->execute();
        $stmt->close();
        $stmt = $conn->prepare("UPDATE user_wheel_quota SET used_today = used_today + 1 WHERE username = ? AND wheel_id = ?");
        $stmt->bind_param("si", $username, $wheelId);
        $stmt->execute();
        $stmt->close();
        if ($selected['type'] === 'points' && intval($selected['value']) > 0) {
            $val = intval($selected['value']);
            $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE username = ?");
            $stmt->bind_param("ds", $val, $username);
            $stmt->execute();
            $stmt->close();
            addPointsLog($conn, $username, $val, 'wheel', '转盘奖励 ' . $plabel, $order_id, $now);
        } elseif ($selected['type'] === 'item' && !empty($selected['item_key'])) {
            $ikey = $selected['item_key'];
            $stmt = $conn->prepare("INSERT INTO user_items (username, product_id, product_name, item_key, quantity, can_sell) VALUES (?, 0, ?, ?, 1, 1)");
            $stmt->bind_param("sss", $username, $plabel, $ikey);
            $stmt->execute();
            $stmt->close();
        }
        $conn->commit();
        sendMessage($conn, 'system', $username, '转盘中奖', '恭喜！您在转盘抽中「' . $plabel . '」', $now);
        echo json_encode(['success' => true, 'prize' => $selected, 'order_id' => $order_id]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'get_wheel_records') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM wheel_records WHERE username = ? ORDER BY id DESC LIMIT 30");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
        $list[] = $row;
    }
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'admin_save_wheel') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_wheel')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $id = intval($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '幸运转盘');
    $cost = intval($_POST['cost'] ?? 50);
    $free = intval($_POST['free_per_day'] ?? 1);
    $prizesJson = $_POST['prizes'] ?? '[]';
    $prizes = json_decode($prizesJson, true);
    if (!is_array($prizes) || count($prizes) < 2) {
        echo json_encode(['success' => false, 'error' => '至少2个奖品']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        if ($id > 0) {
            $stmt = $conn->prepare("UPDATE wheels SET name = ?, cost = ?, free_per_day = ? WHERE id = ?");
            $stmt->bind_param("siii", $name, $cost, $free, $id);
            $stmt->execute();
            $stmt->close();
            $stmt = $conn->prepare("DELETE FROM wheel_prizes WHERE wheel_id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
        } else {
            $stmt = $conn->prepare("INSERT INTO wheels (name, cost, free_per_day, is_active) VALUES (?, ?, ?, 1)");
            $stmt->bind_param("sii", $name, $cost, $free);
            $stmt->execute();
            $id = $conn->insert_id;
            $stmt->close();
        }
        foreach ($prizes as $p) {
            $label = $p['label'] ?? '';
            $type = $p['type'] ?? 'points';
            $value = intval($p['value'] ?? 0);
            $weight = max(1, intval($p['weight'] ?? 1));
            $itemKey = $p['item_key'] ?? null;
            $stmt = $conn->prepare("INSERT INTO wheel_prizes (wheel_id, label, type, value, item_key, weight) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("issisi", $id, $label, $type, $value, $itemKey, $weight);
            $stmt->execute();
            $stmt->close();
        }
        $conn->commit();
        echo json_encode(['success' => true, 'id' => $id]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'buy_scratch') {
    $username = $_POST['username'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $price = intval(getSetting($conn, 'scratch_price', 20));
    $stmt = $conn->prepare("SELECT points FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $user = $r->fetch_assoc();
    $stmt->close();
    if (!$user || floatval($user['points']) < $price) {
        echo json_encode(['success' => false, 'error' => '积分不足']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE users SET points = points - ? WHERE username = ? AND points >= ?");
        $stmt->bind_param("dsd", $price, $username, $price);
        $stmt->execute();
        $aff = $stmt->affected_rows;
        $stmt->close();
        if ($aff <= 0) throw new Exception('扣款失败');
        $rand = rand(1, 10000);
        $p1 = intval(getSetting($conn, 'scratch_p1', 1));
        $p2 = intval(getSetting($conn, 'scratch_p2', 5));
        $p3 = intval(getSetting($conn, 'scratch_p3', 50));
        $prizeType = 'none';
        $prizeValue = 0;
        $prizeLabel = '谢谢参与';
        if ($rand <= $p1) {
            $prizeType = 'points';
            $prizeValue = intval(getSetting($conn, 'scratch_big', 500));
            $prizeLabel = '大奖 ' . $prizeValue . ' 积分';
        } elseif ($rand <= $p1 + $p2) {
            $prizeType = 'points';
            $prizeValue = intval(getSetting($conn, 'scratch_mid', 100));
            $prizeLabel = '中奖 ' . $prizeValue . ' 积分';
        } elseif ($rand <= $p1 + $p2 + $p3) {
            $prizeType = 'points';
            $prizeValue = intval(getSetting($conn, 'scratch_small', 30));
            $prizeLabel = '小奖 ' . $prizeValue . ' 积分';
        }
        $order_id = genOrderId('SC');
        $stmt = $conn->prepare("INSERT INTO scratch_cards (order_id, username, cost, prize_type, prize_value, prize_label, revealed, created_at) VALUES (?, ?, ?, ?, ?, ?, 0, ?)");
        $stmt->bind_param("ssisiss", $order_id, $username, $price, $prizeType, $prizeValue, $prizeLabel, $now);
        $stmt->execute();
        $stmt->close();
        if ($prizeType === 'points' && $prizeValue > 0) {
            $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE username = ?");
            $stmt->bind_param("ds", $prizeValue, $username);
            $stmt->execute();
            $stmt->close();
            addPointsLog($conn, $username, $prizeValue, 'scratch', '刮刮乐 ' . $prizeLabel, $order_id, $now);
        }
        $conn->commit();
        echo json_encode(['success' => true, 'order_id' => $order_id]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'reveal_scratch') {
    $username = $_POST['username'] ?? '';
    $order_id = $_POST['order_id'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM scratch_cards WHERE order_id = ? AND username = ?");
    $stmt->bind_param("ss", $order_id, $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $card = $r->fetch_assoc();
    $stmt->close();
    if (!$card) {
        echo json_encode(['success' => false, 'error' => '刮刮卡不存在']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("UPDATE scratch_cards SET revealed = 1 WHERE id = ?");
    $stmt->bind_param("i", $card['id']);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true, 'prize_type' => $card['prize_type'], 'prize_value' => $card['prize_value'], 'prize_label' => $card['prize_label']]);
    $conn->close();
    exit;
}

if ($action === 'get_scratch_records') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM scratch_cards WHERE username = ? ORDER BY id DESC LIMIT 30");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['created_at'] = date('Y-m-d H:i', strtotime($row['created_at']));
        $list[] = $row;
    }
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'send_ephemeral') {
    $from = $_POST['from_user'] ?? '';
    $to = $_POST['to_user'] ?? '';
    $content = trim($_POST['content'] ?? '');
    if (!$from || !$to || !$content) {
        echo json_encode(['success' => false, 'error' => '参数无效']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT username FROM users WHERE username = ?");
    $stmt->bind_param("s", $to);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows === 0) {
        $stmt->close();
        echo json_encode(['success' => false, 'error' => '收信人不存在']);
        $conn->close();
        exit;
    }
    $stmt->close();
    $price = intval(getSetting($conn, 'ephemeral_price', 10));
    $stmt = $conn->prepare("SELECT points FROM users WHERE username = ?");
    $stmt->bind_param("s", $from);
    $stmt->execute();
    $r = $stmt->get_result();
    $user = $r->fetch_assoc();
    $stmt->close();
    if (!$user || floatval($user['points']) < $price) {
        echo json_encode(['success' => false, 'error' => '积分不足']);
        $conn->close();
        exit;
    }
    $expires = date('Y-m-d H:i:s', strtotime('+24 hours'));
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("UPDATE users SET points = points - ? WHERE username = ? AND points >= ?");
        $stmt->bind_param("dsd", $price, $from, $price);
        $stmt->execute();
        $aff = $stmt->affected_rows;
        $stmt->close();
        if ($aff <= 0) throw new Exception('扣款失败');
        $order_id = genOrderId('EP');
        $stmt = $conn->prepare("INSERT INTO ephemeral_messages (order_id, from_user, to_user, content, expires_at, created_at) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $order_id, $from, $to, $content, $expires, $now);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        addPointsLog($conn, $from, -$price, 'ephemeral', '发送传信给 ' . $to, $order_id, $now);
        sendMessage($conn, 'system', $to, '收到传信', $from . ' 给您发送了一条阅后即焚消息', $now);
        echo json_encode(['success' => true, 'order_id' => $order_id]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'get_ephemeral') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM ephemeral_messages WHERE to_user = ? AND is_read = 0 AND (expires_at IS NULL OR expires_at > ?) ORDER BY id DESC");
    $stmt->bind_param("ss", $username, $now);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['created_at'] = date('Y-m-d H:i', strtotime($row['created_at']));
        $list[] = $row;
    }
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'read_ephemeral') {
    $username = $_POST['username'] ?? '';
    $id = intval($_POST['id'] ?? 0);
    $stmt = $conn->prepare("SELECT * FROM ephemeral_messages WHERE id = ? AND to_user = ?");
    $stmt->bind_param("is", $id, $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $msg = $r->fetch_assoc();
    $stmt->close();
    if (!$msg) {
        echo json_encode(['success' => false, 'error' => '消息不存在']);
        $conn->close();
        exit;
    }
    echo json_encode(['success' => true, 'content' => $msg['content'], 'from_user' => $msg['from_user']]);
    $stmt = $conn->prepare("DELETE FROM ephemeral_messages WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    $conn->close();
    exit;
}

if ($action === 'send_friend_request') {
    $from = $_POST['from_user'] ?? '';
    $toId = trim($_POST['to_unique_id'] ?? '');
    $msg = trim($_POST['message'] ?? '');
    if (!$from || !$toId) {
        echo json_encode(['success' => false, 'error' => '参数无效']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT username FROM users WHERE unique_id = ?");
    $stmt->bind_param("s", $toId);
    $stmt->execute();
    $r = $stmt->get_result();
    $toRow = $r->fetch_assoc();
    $stmt->close();
    if (!$toRow) {
        echo json_encode(['success' => false, 'error' => '用户不存在']);
        $conn->close();
        exit;
    }
    $to = $toRow['username'];
    if ($from === $to) {
        echo json_encode(['success' => false, 'error' => '不能加自己为好友']);
        $conn->close();
        exit;
    }
    $u1 = min($from, $to);
    $u2 = max($from, $to);
    $stmt = $conn->prepare("SELECT id FROM friends WHERE user1 = ? AND user2 = ?");
    $stmt->bind_param("ss", $u1, $u2);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $stmt->close();
        echo json_encode(['success' => false, 'error' => '已经是好友']);
        $conn->close();
        exit;
    }
    $stmt->close();
    $stmt = $conn->prepare("SELECT id FROM friend_requests WHERE from_user = ? AND to_user = ? AND status = 0");
    $stmt->bind_param("ss", $from, $to);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        $stmt->close();
        echo json_encode(['success' => false, 'error' => '已发送过申请']);
        $conn->close();
        exit;
    }
    $stmt->close();
    $stmt = $conn->prepare("INSERT INTO friend_requests (from_user, to_user, message, created_at) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $from, $to, $msg, $now);
    $stmt->execute();
    $stmt->close();
    sendMessage($conn, 'system', $to, '好友申请', $from . ' 请求加您为好友', $now, 'request', 'friend', json_encode(['from' => $from]));
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'handle_friend_request') {
    $username = $_POST['username'] ?? '';
    $requestId = intval($_POST['request_id'] ?? 0);
    $actionType = $_POST['action_type'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM friend_requests WHERE id = ? AND to_user = ?");
    $stmt->bind_param("is", $requestId, $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $req = $r->fetch_assoc();
    $stmt->close();
    if (!$req || intval($req['status']) !== 0) {
        echo json_encode(['success' => false, 'error' => '申请不存在或已处理']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        if ($actionType === 'accept') {
            $from = $req['from_user'];
            $u1 = min($from, $username);
            $u2 = max($from, $username);
            $stmt = $conn->prepare("INSERT IGNORE INTO friends (user1, user2, created_at) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $u1, $u2, $now);
            $stmt->execute();
            $stmt->close();
            $stmt = $conn->prepare("UPDATE friend_requests SET status = 1, handled_at = ? WHERE id = ?");
            $stmt->bind_param("si", $now, $requestId);
            $stmt->execute();
            $stmt->close();
            sendMessage($conn, 'system', $from, '好友申请通过', $username . ' 已同意您的好友申请', $now);
        } else {
            $stmt = $conn->prepare("UPDATE friend_requests SET status = 2, handled_at = ? WHERE id = ?");
            $stmt->bind_param("si", $now, $requestId);
            $stmt->execute();
            $stmt->close();
        }
        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'get_friends') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT CASE WHEN user1 = ? THEN user2 ELSE user1 END as friend_username FROM friends WHERE user1 = ? OR user2 = ?");
    $stmt->bind_param("sss", $username, $username, $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $f = $row['friend_username'];
        $stmt2 = $conn->prepare("SELECT unique_id, username, realname, points, avatar, bio FROM users WHERE username = ?");
        $stmt2->bind_param("s", $f);
        $stmt2->execute();
        $r2 = $stmt2->get_result();
        $info = $r2->fetch_assoc();
        $stmt2->close();
        if ($info) $list[] = $info;
    }
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'get_friend_requests') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT fr.*, u.realname, u.unique_id, u.avatar FROM friend_requests fr LEFT JOIN users u ON fr.from_user = u.username WHERE fr.to_user = ? AND fr.status = 0 ORDER BY fr.id DESC");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['created_at'] = date('Y-m-d H:i', strtotime($row['created_at']));
        $list[] = $row;
    }
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'remove_friend') {
    $username = $_POST['username'] ?? '';
    $friend = $_POST['friend'] ?? '';
    $u1 = min($username, $friend);
    $u2 = max($username, $friend);
    $stmt = $conn->prepare("DELETE FROM friends WHERE user1 = ? AND user2 = ?");
    $stmt->bind_param("ss", $u1, $u2);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'get_achievements') {
    $username = $_POST['username'] ?? '';
    $list = [];
    if (is_dir($ACHIEVEMENTS_DIR)) {
        $dirs = scandir($ACHIEVEMENTS_DIR);
        foreach ($dirs as $dir) {
            if ($dir === '.' || $dir === '..') continue;
            $path = $ACHIEVEMENTS_DIR . $dir;
            if (is_dir($path)) {
                $cfgFile = $path . '/config.json';
                if (file_exists($cfgFile)) {
                    $cfg = json_decode(file_get_contents($cfgFile), true);
                    if ($cfg) {
                        $cfg['key'] = $dir;
                        $cfg['icon_url'] = '/Runfiles/achievements/' . $dir . '/' . ($cfg['icon'] ?? 'icon.png');
                        $stmt = $conn->prepare("SELECT id, unlocked_at FROM user_achievements WHERE username = ? AND achievement_key = ?");
                        $stmt->bind_param("ss", $username, $dir);
                        $stmt->execute();
                        $r = $stmt->get_result();
                        $ua = $r->fetch_assoc();
                        $stmt->close();
                        if ($ua) {
                            $cfg['unlocked'] = 1;
                            $cfg['unlocked_at'] = date('Y-m-d H:i', strtotime($ua['unlocked_at']));
                        } else {
                            $cfg['unlocked'] = 0;
                        }
                        if (intval($cfg['is_hidden'] ?? 0) === 1 && $cfg['unlocked'] == 0) continue;
                        $list[] = $cfg;
                    }
                }
            }
        }
    }
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'check_achievements') {
    $username = $_POST['username'] ?? '';
    $unlocked = [];
    if (is_dir($ACHIEVEMENTS_DIR)) {
        $dirs = scandir($ACHIEVEMENTS_DIR);
        foreach ($dirs as $dir) {
            if ($dir === '.' || $dir === '..') continue;
            $path = $ACHIEVEMENTS_DIR . $dir;
            if (is_dir($path)) {
                $cfgFile = $path . '/config.json';
                $condFile = $path . '/condition.php';
                if (file_exists($cfgFile) && file_exists($condFile)) {
                    $cfg = json_decode(file_get_contents($cfgFile), true);
                    if (!$cfg) continue;
                    $stmt = $conn->prepare("SELECT id FROM user_achievements WHERE username = ? AND achievement_key = ?");
                    $stmt->bind_param("ss", $username, $dir);
                    $stmt->execute();
                    $stmt->store_result();
                    if ($stmt->num_rows > 0) {
                        $stmt->close();
                        continue;
                    }
                    $stmt->close();
                    try {
                        $met = include $condFile;
                    } catch (Exception $e) {
                        $met = false;
                    }
                    if ($met) {
                        $stmt = $conn->prepare("INSERT IGNORE INTO user_achievements (username, achievement_key, unlocked_at) VALUES (?, ?, ?)");
                        $stmt->bind_param("sss", $username, $dir, $now);
                        $stmt->execute();
                        $stmt->close();
                        $reward = intval($cfg['points_reward'] ?? 0);
                        if ($reward > 0) {
                            $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE username = ?");
                            $stmt->bind_param("ds", $reward, $username);
                            $stmt->execute();
                            $stmt->close();
                            addPointsLog($conn, $username, $reward, 'achievement', '解锁成就：' . $cfg['name'], '', $now);
                        }
                        sendMessage($conn, 'system', $username, '解锁成就', '恭喜您解锁成就「' . $cfg['name'] . '」', $now);
                        $unlocked[] = $cfg['name'];
                    }
                }
            }
        }
    }
    echo json_encode(['success' => true, 'unlocked' => $unlocked]);
    $conn->close();
    exit;
}

if ($action === 'get_user_badges') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT badge_key, obtained_at FROM user_badges WHERE username = ? ORDER BY id DESC");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $key = $row['badge_key'];
        $cfgFile = $BADGES_DIR . $key . '/config.json';
        $cfg = file_exists($cfgFile) ? json_decode(file_get_contents($cfgFile), true) : null;
        if ($cfg) {
            $cfg['key'] = $key;
            $cfg['icon_url'] = '/Runfiles/badges/' . $key . '/' . ($cfg['icon'] ?? 'icon.png');
            $cfg['obtained_at'] = date('Y-m-d H:i', strtotime($row['obtained_at']));
            $list[] = $cfg;
        }
    }
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'claim_badge') {
    $username = $_POST['username'] ?? '';
    $code = strtoupper(trim($_POST['code'] ?? ''));
    $stmt = $conn->prepare("SELECT * FROM badge_codes WHERE code = ?");
    $stmt->bind_param("s", $code);
    $stmt->execute();
    $r = $stmt->get_result();
    $bc = $r->fetch_assoc();
    $stmt->close();
    if (!$bc) {
        echo json_encode(['success' => false, 'error' => '勋章码不存在']);
        $conn->close();
        exit;
    }
    if ($bc['used_by']) {
        echo json_encode(['success' => false, 'error' => '已被使用']);
        $conn->close();
        exit;
    }
    if ($bc['expires_at'] && strtotime($bc['expires_at']) < time()) {
        echo json_encode(['success' => false, 'error' => '勋章码已过期']);
        $conn->close();
        exit;
    }
    $badgeKey = $bc['badge_key'];
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("INSERT IGNORE INTO user_badges (username, badge_key, obtained_at) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $badgeKey, $now);
        $stmt->execute();
        $stmt->close();
        $stmt = $conn->prepare("UPDATE badge_codes SET used_by = ?, used_at = ? WHERE id = ?");
        $stmt->bind_param("ssi", $username, $now, $bc['id']);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'admin_gen_badge_code') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_badges')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $badgeKey = $_POST['badge_key'] ?? '';
    $days = intval($_POST['expire_days'] ?? 30);
    $count = max(1, min(100, intval($_POST['count'] ?? 1)));
    if (empty($badgeKey)) {
        echo json_encode(['success' => false, 'error' => '请选择勋章']);
        $conn->close();
        exit;
    }
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $expiresAt = date('Y-m-d H:i:s', strtotime("+$days days"));
    $codes = [];
    for ($i = 0; $i < $count; $i++) {
        $code = 'BG';
        for ($j = 0; $j < 10; $j++) $code .= $chars[rand(0, 35)];
        $stmt = $conn->prepare("INSERT INTO badge_codes (code, badge_key, expires_at, created_at) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $code, $badgeKey, $expiresAt, $now);
        $stmt->execute();
        $stmt->close();
        $codes[] = $code;
    }
    echo json_encode(['success' => true, 'codes' => $codes]);
    $conn->close();
    exit;
}

if ($action === 'get_countdowns') {
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM countdowns WHERE username = ? ORDER BY target_date ASC");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) $list[] = $row;
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'add_countdown') {
    $username = $_POST['username'] ?? '';
    $title = trim($_POST['title'] ?? '');
    $targetDate = $_POST['target_date'] ?? '';
    $remindDays = intval($_POST['remind_days'] ?? 1);
    if (!$title || !$targetDate) {
        echo json_encode(['success' => false, 'error' => '参数无效']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("INSERT INTO countdowns (username, title, target_date, remind_days, enabled, created_at) VALUES (?, ?, ?, ?, 1, ?)");
    $stmt->bind_param("sssis", $username, $title, $targetDate, $remindDays, $now);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'delete_countdown') {
    $username = $_POST['username'] ?? '';
    $id = intval($_POST['id'] ?? 0);
    $stmt = $conn->prepare("DELETE FROM countdowns WHERE id = ? AND username = ?");
    $stmt->bind_param("is", $id, $username);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'global_search') {
    $keyword = trim($_POST['keyword'] ?? '');
    $username = $_POST['username'] ?? '';
    if (empty($keyword)) {
        echo json_encode(['success' => false, 'error' => '请输入关键字']);
        $conn->close();
        exit;
    }
    $kw = '%' . $conn->real_escape_string($keyword) . '%';
    $results = [];
    $stmt = $conn->prepare("SELECT order_id, product_name as name, cost as amount, time, 'purchase' as type FROM user_purchases WHERE username = ? AND (order_id LIKE ? OR product_name LIKE ?) LIMIT 10");
    $stmt->bind_param("sss", $username, $kw, $kw);
    $stmt->execute();
    $r = $stmt->get_result();
    while ($row = $r->fetch_assoc()) {
        $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
        $results[] = $row;
    }
    $stmt->close();
    $stmt = $conn->prepare("SELECT order_id, item_name as name, price as amount, time, 'market' as type FROM market_trades WHERE (seller = ? OR buyer = ?) AND (order_id LIKE ? OR item_name LIKE ?) LIMIT 10");
    $stmt->bind_param("ssss", $username, $username, $kw, $kw);
    $stmt->execute();
    $r = $stmt->get_result();
    while ($row = $r->fetch_assoc()) {
        $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
        $results[] = $row;
    }
    $stmt->close();
    $stmt = $conn->prepare("SELECT order_id, CONCAT('转账给 ', to_user) as name, amount, time, 'transfer' as type FROM transfers WHERE from_user = ? AND (order_id LIKE ? OR to_user LIKE ?) LIMIT 10");
    $stmt->bind_param("sss", $username, $kw, $kw);
    $stmt->execute();
    $r = $stmt->get_result();
    while ($row = $r->fetch_assoc()) {
        $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
        $results[] = $row;
    }
    $stmt->close();
    echo json_encode($results);
    $conn->close();
    exit;
}

if ($action === 'search_order') {
    $admin = $_POST['admin'] ?? '';
    if (!isAdminUser($conn, $admin)) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $orderId = trim($_POST['order_id'] ?? '');
    if (empty($orderId)) {
        echo json_encode(['success' => false, 'error' => '请输入订单号']);
        $conn->close();
        exit;
    }
    $result = null;
    $tables = [
        ['transfers', '转账'],
        ['user_purchases', '购买'],
        ['market_trades', '市场交易'],
        ['stock_trades', '股票交易'],
        ['bank_records', '银行'],
        ['redeem_records', '兑换码'],
        ['lottery_records', '抽奖'],
        ['market_listings', '市场挂单'],
        ['feedback', '反馈'],
        ['messages', '消息'],
        ['sign_log', '签到']
    ];
    foreach ($tables as $t) {
        $stmt = $conn->prepare("SELECT *, ? as order_type FROM `{$t[0]}` WHERE order_id = ? LIMIT 1");
        $stmt->bind_param("ss", $t[1], $orderId);
        $stmt->execute();
        $r = $stmt->get_result();
        $row = $r->fetch_assoc();
        $stmt->close();
        if ($row) {
            $result = $row;
            break;
        }
    }
    if ($result) {
        if (isset($result['time'])) $result['time'] = date('Y-m-d H:i:s', strtotime($result['time']));
        if (isset($result['created_at'])) $result['created_at'] = date('Y-m-d H:i:s', strtotime($result['created_at']));
        echo json_encode(['success' => true, 'data' => $result]);
    } else {
        echo json_encode(['success' => false, 'error' => '订单不存在']);
    }
    $conn->close();
    exit;
}

if ($action === 'get_user_orders') {
    $username = $_POST['username'] ?? '';
    $type = $_POST['type'] ?? 'all';
    $orders = [];
    if ($type === 'all' || $type === 'purchase') {
        $stmt = $conn->prepare("SELECT order_id, product_name as name, cost as amount, time, 'purchase' as type, '商城购买' as order_type FROM user_purchases WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $r = $stmt->get_result();
        while ($row = $r->fetch_assoc()) {
            $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
            $orders[] = $row;
        }
        $stmt->close();
    }
    if ($type === 'all' || $type === 'transfer') {
        $stmt = $conn->prepare("SELECT order_id, CONCAT('转出给 ', to_user) as name, amount, time, 'transfer_out' as type, '转账' as order_type FROM transfers WHERE from_user = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $r = $stmt->get_result();
        while ($row = $r->fetch_assoc()) {
            $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
            $orders[] = $row;
        }
        $stmt->close();
        $stmt = $conn->prepare("SELECT order_id, CONCAT('转入自 ', from_user) as name, amount, time, 'transfer_in' as type, '转账' as order_type FROM transfers WHERE to_user = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $r = $stmt->get_result();
        while ($row = $r->fetch_assoc()) {
            $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
            $orders[] = $row;
        }
        $stmt->close();
    }
    if ($type === 'all' || $type === 'stock') {
        $stmt = $conn->prepare("SELECT order_id, CONCAT(symbol, ' ', type) as name, price as amount, time, CONCAT('stock_', type) as type, '股票交易' as order_type FROM stock_trades WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $r = $stmt->get_result();
        while ($row = $r->fetch_assoc()) {
            $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
            $orders[] = $row;
        }
        $stmt->close();
    }
    if ($type === 'all' || $type === 'market') {
        $stmt = $conn->prepare("SELECT order_id, CONCAT('购买 ', item_name) as name, price as amount, time, 'market_buy' as type, '市场交易' as order_type FROM market_trades WHERE buyer = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $r = $stmt->get_result();
        while ($row = $r->fetch_assoc()) {
            $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
            $orders[] = $row;
        }
        $stmt->close();
        $stmt = $conn->prepare("SELECT order_id, CONCAT('卖出 ', item_name) as name, price as amount, time, 'market_sell' as type, '市场交易' as order_type FROM market_trades WHERE seller = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $r = $stmt->get_result();
        while ($row = $r->fetch_assoc()) {
            $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
            $orders[] = $row;
        }
        $stmt->close();
    }
    usort($orders, function($a, $b) { return strtotime($b['time']) - strtotime($a['time']); });
    echo json_encode(array_slice($orders, 0, 50));
    $conn->close();
    exit;
}



if ($action === 'get_points_log') {
    $username = $_POST['username'] ?? '';
    $limit = intval($_POST['limit'] ?? 100);
    if ($limit < 1 || $limit > 200) $limit = 100;
    $stmt = $conn->prepare("SELECT * FROM points_log WHERE username = ? ORDER BY id DESC LIMIT ?");
    $stmt->bind_param("si", $username, $limit);
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
        $row['change_amount'] = floatval($row['change_amount']);
        $row['balance_after'] = floatval($row['balance_after']);
        $list[] = $row;
    }
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'backup_now') {
    $admin = $_POST['admin'] ?? '';
    if (!isMMU($conn, $admin)) {
        echo json_encode(['success' => false, 'error' => '只有 MMU 能备份']);
        $conn->close();
        exit;
    }
    $filename = execBackup($conn, $DATA_DIR);
    if ($filename) {
        setSetting($conn, 'backup_last_run', $now);
        addLog($conn, $admin, 'backup', '备份 ' . $filename, $now);
        echo json_encode(['success' => true, 'filename' => $filename]);
    } else {
        echo json_encode(['success' => false, 'error' => '备份失败']);
    }
    $conn->close();
    exit;
}

if ($action === 'list_backups') {
    $admin = $_POST['admin'] ?? '';
    if (!isMMU($conn, $admin)) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $files = glob($DATA_DIR . 'backup_*.sql');
    usort($files, function($a, $b) { return filemtime($b) - filemtime($a); });
    $list = [];
    foreach ($files as $f) {
        $list[] = [
            'filename' => basename($f),
            'size' => filesize($f),
            'time' => date('Y-m-d H:i:s', filemtime($f))
        ];
    }
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'download_backup') {
    $admin = $_POST['admin'] ?? '';
    if (!isMMU($conn, $admin)) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $filename = basename($_POST['filename'] ?? '');
    $path = $DATA_DIR . $filename;
    if (!file_exists($path) || strpos($filename, 'backup_') !== 0) {
        echo json_encode(['success' => false, 'error' => '文件不存在']);
        $conn->close();
        exit;
    }
    header('Content-Type: application/sql');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . filesize($path));
    readfile($path);
    exit;
}

if ($action === 'delete_backup') {
    $admin = $_POST['admin'] ?? '';
    if (!isMMU($conn, $admin)) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $filename = basename($_POST['filename'] ?? '');
    $path = $DATA_DIR . $filename;
    if (file_exists($path) && strpos($filename, 'backup_') === 0) {
        @unlink($path);
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => '文件不存在']);
    }
    $conn->close();
    exit;
}

if ($action === 'selfcheck_run') {
    $admin = $_POST['admin'] ?? '';
    if (!isMMU($conn, $admin)) {
        echo json_encode(['success' => false, 'error' => '只有 MMU 能执行自检']);
        $conn->close();
        exit;
    }
    $results = [];
    $passed = 0;
    $failed = 0;

    function addResult(&$results, &$passed, &$failed, $name, $ok, $detail) {
        $results[] = ['name' => $name, 'status' => $ok ? 'ok' : 'fail', 'detail' => $detail];
        if ($ok) $passed++; else $failed++;
    }

    function callApi($action, $data = []) {
        $url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/api.php?action=' . $action;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $resp = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code !== 200 || !$resp) return null;
        $json = json_decode($resp, true);
        return $json;
    }

    addResult($results, $passed, $failed, '数据库连接', true, '已连接');

    $requiredTables = [
        'users','admin_permissions','points_log','sign_log','transfers','user_bankcards',
        'bank_accounts','bank_records','bank_rates','rate_history','stocks','stock_holdings',
        'stock_trades','stock_history','products','market_listings','market_trades','cart_items',
        'user_purchases','product_bundles','bundle_items','coupons','user_coupons','redeem_codes',
        'redeem_records','item_codes','user_items','item_use_codes','lotteries','lottery_records',
        'lottery_tickets','lottery_draws','game_rooms','game_players','game_actions','user_chips',
        'wheels','wheel_prizes','wheel_records','user_wheel_quota','scratch_cards','friends',
        'friend_requests','messages','ephemeral_messages','user_achievements','user_badges',
        'badge_codes','countdowns','feedback','notices','system_settings','operation_logs','favorites'
    ];
    $missing = [];
    foreach ($requiredTables as $t) {
        $r = $conn->query("SHOW TABLES LIKE '$t'");
        if ($r->num_rows === 0) $missing[] = $t;
    }
    addResult($results, $passed, $failed, '数据表完整性', count($missing) === 0, count($missing) === 0 ? count($requiredTables) . ' 张表全部存在' : '缺少：' . implode(', ', $missing));

    $imgDir = __DIR__ . '/Runfiles/feature-photo/';
    if (is_dir($imgDir)) {
        $imgs = glob($imgDir . '*.png');
        $broken = [];
        foreach ($imgs as $img) {
            if (filesize($img) < 100) $broken[] = basename($img);
        }
        addResult($results, $passed, $failed, '界面图片资源', count($broken) === 0, count($imgs) . ' 张图片，异常 ' . count($broken) . ' 张');
    } else {
        addResult($results, $passed, $failed, '界面图片资源', false, 'feature-photo 目录不存在');
    }

    $dirs = ['covers', 'bundles', 'items', 'achievements', 'badges', 'avatars', 'Puke'];
    foreach ($dirs as $d) {
        $p = __DIR__ . '/Runfiles/' . $d . '/';
        addResult($results, $passed, $failed, '目录 /Runfiles/' . $d, is_dir($p), is_dir($p) ? '存在' : '不存在');
    }
    addResult($results, $passed, $failed, '目录 /data', is_dir(__DIR__ . '/data/'), is_dir(__DIR__ . '/data/') ? '存在' : '不存在');
    addResult($results, $passed, $failed, '目录 /files', is_dir(__DIR__ . '/files/'), is_dir(__DIR__ . '/files/') ? '存在' : '不存在');

    $testUser = '_selfcheck_' . time();
    $testPass = '123456';
    $testReal = '_自检_' . time();
    $hashed = password_hash($testPass, PASSWORD_DEFAULT);
    $uid = 'UID' . strtoupper(substr(uniqid(), -6)) . rand(100, 999);
    $ip = getClientIP();
    $stmt = $conn->prepare("INSERT INTO users (unique_id, username, password, realname, reg_ip, reg_ua, created_at) VALUES (?, ?, ?, ?, ?, 'selfcheck', ?)");
    $stmt->bind_param("ssssss", $uid, $testUser, $hashed, $testReal, $ip, $now);
    $ok = $stmt->execute();
    $aff = $stmt->affected_rows;
    $stmt->close();
    if ($ok && $aff > 0) {
        addResult($results, $passed, $failed, '注册流程', true, '测试用户创建成功');
        $conn->query("INSERT IGNORE INTO bank_accounts (username, savings, loan, last_interest_date) VALUES ('$testUser', 0, 0, '$today')");
        $conn->query("INSERT IGNORE INTO user_chips (username, chips) VALUES ('$testUser', 0)");
        $loginResp = callApi('login', ['username' => $testUser, 'password' => $testPass]);
        if ($loginResp && isset($loginResp['success']) && $loginResp['success']) {
            addResult($results, $passed, $failed, '登录流程', true, '测试用户登录成功');
        } else {
            addResult($results, $passed, $failed, '登录流程', false, '登录失败');
        }
    } else {
        addResult($results, $passed, $failed, '注册流程', false, '测试用户创建失败');
    }

    $userTests = [
        ['获取用户信息', 'get_user', ['username' => $testUser], 'object'],
        ['获取排行榜', 'get_rank', ['username' => $testUser], 'object'],
        ['获取签到日历', 'get_sign_calendar', ['username' => $testUser], 'object'],
        ['签到', 'sign_in', ['username' => $testUser], 'any'],
        ['获取未读消息', 'get_unread_messages', ['username' => $testUser], 'object'],
        ['获取消息列表', 'get_messages', ['username' => $testUser], 'array'],
        ['获取反馈列表', 'get_feedbacks', ['username' => $testUser], 'array'],
        ['获取积分流水', 'get_points_log', ['username' => $testUser], 'array'],
        ['获取银行账户', 'get_bank', ['username' => $testUser], 'object'],
        ['获取银行记录', 'get_bank_records', ['username' => $testUser], 'array'],
        ['获取银行卡', 'get_my_bankcards', ['username' => $testUser], 'array'],
        ['获取转账记录', 'get_transfers', ['username' => $testUser], 'array'],
        ['获取股票列表', 'get_stocks', [], 'array'],
        ['获取持仓', 'get_holdings', ['username' => $testUser], 'array'],
        ['获取股票交易记录', 'get_stock_trades', ['username' => $testUser], 'array'],
        ['获取商品列表', 'get_products', [], 'array'],
        ['获取市场挂单', 'get_market_listings', [], 'array'],
        ['获取我挂出的', 'get_my_listings', ['username' => $testUser], 'array'],
        ['获取购物车', 'get_cart', ['username' => $testUser], 'array'],
        ['获取优惠券', 'get_user_coupons', ['username' => $testUser], 'array'],
        ['获取道具列表', 'get_user_items', ['username' => $testUser], 'array'],
        ['获取道具码', 'get_my_codes', ['username' => $testUser], 'array'],
        ['获取抽奖列表', 'get_lottery_list', [], 'array'],
        ['获取我创建的抽奖', 'get_my_lotteries', ['username' => $testUser], 'array'],
        ['获取抽奖记录', 'get_lottery_records', [], 'array'],
        ['获取我的彩票', 'get_my_tickets', ['username' => $testUser], 'array'],
        ['获取开奖记录', 'get_lottery_draws', [], 'array'],
        ['获取筹码', 'get_chips', ['username' => $testUser], 'object'],
        ['获取房间列表', 'get_rooms', [], 'array'],
        ['获取好友列表', 'get_friends', ['username' => $testUser], 'array'],
        ['获取好友申请', 'get_friend_requests', ['username' => $testUser], 'array'],
        ['获取成就列表', 'get_achievements', ['username' => $testUser], 'array'],
        ['获取勋章列表', 'get_user_badges', ['username' => $testUser], 'array'],
        ['获取倒计日', 'get_countdowns', ['username' => $testUser], 'array'],
        ['获取传信', 'get_ephemeral', ['username' => $testUser], 'array'],
        ['获取公告', 'get_notices', [], 'array'],
        ['获取系统设置', 'get_settings', [], 'object'],
        ['获取收藏', 'get_favorites', ['username' => $testUser], 'array'],
        ['获取用户订单', 'get_user_orders', ['username' => $testUser, 'type' => 'all'], 'array'],
        ['获取转盘记录', 'get_wheel_records', ['username' => $testUser], 'array'],
        ['获取刮刮乐记录', 'get_scratch_records', ['username' => $testUser], 'array'],
        ['扫描套装', 'scan_bundle_folders', [], 'array'],
        ['获取转盘配置', 'get_wheel', [], 'any'],
        ['获取银行利率', 'get_bank_rates', [], 'object'],
        ['获取利率历史', 'get_rate_history', [], 'array'],
        ['全局搜索', 'global_search', ['username' => $testUser, 'keyword' => 'a'], 'array'],
        ['获取自检状态', 'selfcheck_status', [], 'object'],
        ['获取维护状态', 'get_maintenance', [], 'object']
    ];

    foreach ($userTests as $t) {
        $name = $t[0];
        $action = $t[1];
        $data = $t[2];
        $type = $t[3];
        $resp = callApi($action, $data);
        if ($resp === null) {
            addResult($results, $passed, $failed, $name, false, '无法请求');
            continue;
        }
        if ($type === 'array') {
            addResult($results, $passed, $failed, $name, is_array($resp), is_array($resp) ? '返回数组，共 ' . count($resp) . ' 条' : '返回异常');
        } else if ($type === 'object') {
            addResult($results, $passed, $failed, $name, is_array($resp), is_array($resp) ? '返回对象' : '返回异常');
        } else {
            addResult($results, $passed, $failed, $name, is_array($resp), is_array($resp) ? '返回正常' : '返回异常');
        }
    }

    $adminTests = [
        ['管理员-获取用户列表', 'get_users', [], 'array'],
        ['管理员-获取兑换码', 'get_redeem_codes', [], 'array'],
        ['管理员-获取道具码', 'get_item_codes', [], 'array'],
        ['管理员-获取反馈', 'admin_get_feedbacks', [], 'array'],
        ['管理员-获取道具核销', 'admin_get_codes', ['filter' => 'all', 'keyword' => ''], 'array'],
        ['管理员-获取操作日志', 'get_logs', ['filter' => '', 'keyword' => ''], 'array'],
        ['管理员-获取权限列表', 'admin_get_permissions', [], 'array'],
        ['管理员-获取备份列表', 'list_backups', [], 'array']
    ];

    foreach ($adminTests as $t) {
        $name = $t[0];
        $action = $t[1];
        $data = $t[2];
        $data['admin'] = $admin;
        $type = $t[3];
        $resp = callApi($action, $data);
        if ($resp === null) {
            addResult($results, $passed, $failed, $name, false, '无法请求');
            continue;
        }
        if ($type === 'array') {
            addResult($results, $passed, $failed, $name, is_array($resp), is_array($resp) ? '返回数组，共 ' . count($resp) . ' 条' : '返回异常');
        } else {
            addResult($results, $passed, $failed, $name, is_array($resp), is_array($resp) ? '返回正常' : '返回异常');
        }
    }

    if (isset($loginResp) && $loginResp) {
        $conn->query("DELETE FROM users WHERE username = '$testUser'");
        $conn->query("DELETE FROM bank_accounts WHERE username = '$testUser'");
        $conn->query("DELETE FROM user_chips WHERE username = '$testUser'");
        $conn->query("DELETE FROM sign_log WHERE username = '$testUser'");
        $conn->query("DELETE FROM points_log WHERE username = '$testUser'");
        addResult($results, $passed, $failed, '测试用户清理', true, '已清理');
    } else {
        $conn->query("DELETE FROM users WHERE username = '$testUser'");
        addResult($results, $passed, $failed, '测试用户清理', true, '已尝试清理');
    }

    setSetting($conn, 'selfcheck_last_run', $now);
    addLog($conn, $admin, 'selfcheck', "通过 $passed / 失败 $failed", $now);
    echo json_encode([
        'success' => true,
        'total' => count($results),
        'passed' => $passed,
        'failed' => $failed,
        'results' => $results
    ]);
    $conn->close();
    exit;
}

if ($action === 'selfcheck_status') {
    $last = getSetting($conn, 'selfcheck_last_run', '');
    $backupLast = getSetting($conn, 'backup_last_run', '');
    echo json_encode(['selfcheck_last' => $last, 'backup_last' => $backupLast, 'now' => $now]);
    $conn->close();
    exit;
}

if ($action === 'get_users') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_users')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $keyword = trim($_POST['keyword'] ?? '');
    if ($keyword !== '') {
        $kw = '%' . $conn->real_escape_string($keyword) . '%';
        $stmt = $conn->prepare("SELECT unique_id, username, realname, points, level, is_mmu, status, show_in_rank, reg_ip, last_ip, created_at, last_login FROM users WHERE username LIKE ? OR realname LIKE ? OR unique_id LIKE ? ORDER BY id DESC");
        $stmt->bind_param("sss", $kw, $kw, $kw);
        $stmt->execute();
        $r = $stmt->get_result();
    } else {
        $r = $conn->query("SELECT unique_id, username, realname, points, level, is_mmu, status, show_in_rank, reg_ip, last_ip, created_at, last_login FROM users ORDER BY id DESC");
    }
    $list = [];
    while ($row = $r->fetch_assoc()) $list[] = $row;
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'freeze_user') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_users')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT level, is_mmu FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $target = $r->fetch_assoc();
    $stmt->close();
    if ($target && intval($target['is_mmu']) === 1) {
        echo json_encode(['success' => false, 'error' => '不能冻结 MMU']);
        $conn->close();
        exit;
    }
    if ($username === $admin) {
        echo json_encode(['success' => false, 'error' => '不能冻结自己']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("UPDATE users SET status = 0 WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->close();
    addLog($conn, $admin, 'freeze_user', '冻结 ' . $username, $now);
    sendMessage($conn, 'system', $username, '账号已被冻结', '您的账号已被管理员冻结，如有疑问请联系管理员。', $now);
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'unfreeze_user') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_users')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("UPDATE users SET status = 1 WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->close();
    addLog($conn, $admin, 'unfreeze_user', '解冻 ' . $username, $now);
    sendMessage($conn, 'system', $username, '账号已解冻', '您的账号已恢复正常。', $now);
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'delete_user') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_users')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT level, is_mmu FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $target = $r->fetch_assoc();
    $stmt->close();
    if ($target && intval($target['is_mmu']) === 1) {
        echo json_encode(['success' => false, 'error' => '不能删除 MMU']);
        $conn->close();
        exit;
    }
    if ($username === $admin) {
        echo json_encode(['success' => false, 'error' => '不能删除自己']);
        $conn->close();
        exit;
    }
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("DELETE FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->close();
        $tables = ['bank_accounts','bank_records','user_bankcards','user_items','cart_items','user_chips','user_coupons','user_achievements','user_badges','countdowns','ephemeral_messages','user_wheel_quota','scratch_cards','friends','friend_requests','admin_permissions','user_purchases','wheel_records'];
        foreach ($tables as $t) {
            $conn->query("DELETE FROM `$t` WHERE username = '$username'");
        }
        $conn->query("DELETE FROM friends WHERE user1 = '$username' OR user2 = '$username'");
        $conn->query("DELETE FROM friend_requests WHERE from_user = '$username' OR to_user = '$username'");
        $conn->commit();
        addLog($conn, $admin, 'delete_user', '删除 ' . $username, $now);
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'adjust_points') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_adjust_points')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $username = $_POST['username'] ?? '';
    $points = floatval($_POST['points'] ?? 0);
    if ($points <= 0 || $points > 1000000) {
        echo json_encode(['success' => false, 'error' => '积分必须为1-100万之间']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT points FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $u = $r->fetch_assoc();
    $stmt->close();
    if (!$u) {
        echo json_encode(['success' => false, 'error' => '用户不存在']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE username = ?");
    $stmt->bind_param("ds", $points, $username);
    $stmt->execute();
    $stmt->close();
    $order_id = genOrderId('ADJ');
    addPointsLog($conn, $username, $points, 'admin_add', '管理员加分 by ' . $admin, $order_id, $now);
    addLog($conn, $admin, 'adjust_points', '给 ' . $username . ' 加 ' . $points, $now);
    sendMessage($conn, 'system', $username, '积分变动', '管理员为您增加了 ' . $points . ' 积分', $now);
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'deduct_points') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_adjust_points')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $username = $_POST['username'] ?? '';
    $points = abs(floatval($_POST['points'] ?? 0));
    if ($points <= 0) {
        echo json_encode(['success' => false, 'error' => '积分必须大于0']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT points FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $u = $r->fetch_assoc();
    $stmt->close();
    if (!$u) {
        echo json_encode(['success' => false, 'error' => '用户不存在']);
        $conn->close();
        exit;
    }
    $actual = min($points, floatval($u['points']));
    $stmt = $conn->prepare("UPDATE users SET points = GREATEST(0, points - ?) WHERE username = ?");
    $stmt->bind_param("ds", $points, $username);
    $stmt->execute();
    $stmt->close();
    $order_id = genOrderId('ADJ');
    addPointsLog($conn, $username, -$actual, 'admin_deduct', '管理员扣分 by ' . $admin, $order_id, $now);
    addLog($conn, $admin, 'deduct_points', '扣 ' . $username . ' ' . $points, $now);
    sendMessage($conn, 'system', $username, '积分变动', '管理员为您扣除了 ' . $actual . ' 积分', $now);
    echo json_encode(['success' => true, 'actual' => $actual]);
    $conn->close();
    exit;
}

if ($action === 'clear_points') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_adjust_points')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $username = $_POST['username'] ?? '';
    $stmt = $conn->prepare("SELECT points FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $u = $r->fetch_assoc();
    $stmt->close();
    if (!$u) {
        echo json_encode(['success' => false, 'error' => '用户不存在']);
        $conn->close();
        exit;
    }
    $old = floatval($u['points']);
    $stmt = $conn->prepare("UPDATE users SET points = 0 WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->close();
    $order_id = genOrderId('ADJ');
    addPointsLog($conn, $username, -$old, 'admin_clear', '管理员清空积分 by ' . $admin, $order_id, $now);
    addLog($conn, $admin, 'clear_points', '清空 ' . $username, $now);
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'admin_add_all_points') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_adjust_points')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $points = floatval($_POST['points'] ?? 0);
    if ($points <= 0 || $points > 1000000) {
        echo json_encode(['success' => false, 'error' => '积分必须为1-100万之间']);
        $conn->close();
        exit;
    }
    $r = $conn->query("SELECT username FROM users WHERE status = 1");
    $count = 0;
    while ($row = $r->fetch_assoc()) {
        $u = $row['username'];
        $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE username = ?");
        $stmt->bind_param("ds", $points, $u);
        $stmt->execute();
        $stmt->close();
        $order_id = genOrderId('ADJ');
        addPointsLog($conn, $u, $points, 'admin_add', '全服加分', $order_id, $now);
        $count++;
    }
    addLog($conn, $admin, 'all_add_points', '全服加 ' . $points . '，共 ' . $count . ' 人', $now);
    echo json_encode(['success' => true, 'count' => $count]);
    $conn->close();
    exit;
}

if ($action === 'admin_deduct_all_points') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_adjust_points')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $points = floatval($_POST['points'] ?? 0);
    if ($points <= 0 || $points > 1000000) {
        echo json_encode(['success' => false, 'error' => '积分必须为1-100万之间']);
        $conn->close();
        exit;
    }
    $r = $conn->query("SELECT username, points FROM users WHERE status = 1");
    $count = 0;
    while ($row = $r->fetch_assoc()) {
        $u = $row['username'];
        $old = floatval($row['points']);
        $actual = min($points, $old);
        $stmt = $conn->prepare("UPDATE users SET points = GREATEST(0, points - ?) WHERE username = ?");
        $stmt->bind_param("ds", $points, $u);
        $stmt->execute();
        $stmt->close();
        $order_id = genOrderId('ADJ');
        addPointsLog($conn, $u, -$actual, 'admin_deduct', '全服扣分', $order_id, $now);
        $count++;
    }
    addLog($conn, $admin, 'all_deduct_points', '全服扣 ' . $points . '，共 ' . $count . ' 人', $now);
    echo json_encode(['success' => true, 'count' => $count]);
    $conn->close();
    exit;
}

if ($action === 'reset_password') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_users')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $username = $_POST['username'] ?? '';
    $new = $_POST['new_password'] ?? '';
    if (strlen($new) < 4) {
        echo json_encode(['success' => false, 'error' => '密码至少4位']);
        $conn->close();
        exit;
    }
    $hashed = password_hash($new, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
    $stmt->bind_param("ss", $hashed, $username);
    $stmt->execute();
    $stmt->close();
    addLog($conn, $admin, 'reset_password', '重置 ' . $username . ' 密码', $now);
    sendMessage($conn, 'system', $username, '密码已被重置', '您的密码已被管理员重置，如非本人操作请联系管理员。', $now);
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'update_level') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_users')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $username = $_POST['username'] ?? '';
    $level = intval($_POST['level'] ?? 1);
    if ($level < 1 || $level > 5) {
        echo json_encode(['success' => false, 'error' => '等级无效']);
        $conn->close();
        exit;
    }
    if ($level == 5 && !isMMU($conn, $admin)) {
        echo json_encode(['success' => false, 'error' => '只有 MMU 能设置 MMU']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("UPDATE users SET level = ? WHERE username = ?");
    $stmt->bind_param("is", $level, $username);
    $stmt->execute();
    $stmt->close();
    addLog($conn, $admin, 'update_level', $username . ' 等级改为 ' . $level, $now);
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'change_realname') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_users')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $username = $_POST['username'] ?? '';
    $realname = trim($_POST['realname'] ?? '');
    $stmt = $conn->prepare("UPDATE users SET realname = ? WHERE username = ?");
    $stmt->bind_param("ss", $realname, $username);
    $stmt->execute();
    $stmt->close();
    addLog($conn, $admin, 'change_realname', $username . ' 改名为 ' . $realname, $now);
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'admin_get_permissions') {
    $admin = $_POST['admin'] ?? '';
    if (!isMMU($conn, $admin)) {
        echo json_encode(['success' => false, 'error' => '只有 MMU 可访问']);
        $conn->close();
        exit;
    }
    $r = $conn->query("SELECT * FROM admin_permissions");
    $list = [];
    while ($row = $r->fetch_assoc()) $list[] = $row;
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'admin_set_permission') {
    $admin = $_POST['admin'] ?? '';
    if (!isMMU($conn, $admin)) {
        echo json_encode(['success' => false, 'error' => '只有 MMU 可访问']);
        $conn->close();
        exit;
    }
    $target = $_POST['target'] ?? '';
    $perm = $_POST['perm'] ?? '';
    $value = intval($_POST['value'] ?? 0);
    $allowed = ['can_manage_users','can_manage_products','can_manage_stocks','can_manage_lottery','can_manage_betting','can_manage_bank','can_manage_codes','can_manage_feedback','can_send_messages','can_manage_notices','can_view_logs','can_adjust_points','can_manage_wheel','can_manage_lottery_bet','can_manage_scratch','can_manage_achievements','can_manage_badges','can_manage_coupons','can_manage_bgm'];
    if (!in_array($perm, $allowed)) {
        echo json_encode(['success' => false, 'error' => '无效权限']);
        $conn->close();
        exit;
    }
    $conn->query("INSERT IGNORE INTO admin_permissions (username) VALUES ('$target')");
    $conn->query("UPDATE admin_permissions SET $perm = $value WHERE username = '$target'");
    addLog($conn, $admin, 'set_permission', $target . ' ' . $perm . ' = ' . $value, $now);
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'update_setting') {
    $admin = $_POST['admin'] ?? '';
    $key = $_POST['key'] ?? '';
    $value = $_POST['value'] ?? '';
    if (strpos($key, 'msg_popup_') === 0) {
        $owner = substr($key, 10);
        if ($owner !== $admin) {
            echo json_encode(['success' => false, 'error' => '权限不足']);
            $conn->close();
            exit;
        }
    } else if (!isAdminUser($conn, $admin)) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    setSetting($conn, $key, $value);
    addLog($conn, $admin, 'update_setting', $key . ' = ' . $value, $now);
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'get_logs') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_view_logs')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $filter = trim($_POST['filter'] ?? '');
    $kw = trim($_POST['keyword'] ?? '');
    $sql = "SELECT * FROM operation_logs WHERE 1=1";
    $params = [];
    $types = "";
    if ($filter !== '') {
        $sql .= " AND action = ?";
        $params[] = $filter;
        $types .= "s";
    }
    if ($kw !== '') {
        $sql .= " AND (username LIKE ? OR detail LIKE ?)";
        $kwLike = '%' . $kw . '%';
        $params[] = $kwLike;
        $params[] = $kwLike;
        $types .= "ss";
    }
    $sql .= " ORDER BY id DESC LIMIT 200";
    if ($params) {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $r = $stmt->get_result();
    } else {
        $r = $conn->query($sql);
    }
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
        $list[] = $row;
    }
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'exec_sql') {
    $admin = $_POST['admin'] ?? '';
    if (!isMMU($conn, $admin)) {
        echo json_encode(['success' => false, 'error' => '只有 MMU 可执行']);
        $conn->close();
        exit;
    }
    $password = $_POST['password'] ?? '';
    $sqlText = $_POST['sql'] ?? '';
    if ($password !== 'wyx_sql_2026') {
        echo json_encode(['success' => false, 'error' => '密码错误']);
        $conn->close();
        exit;
    }
    if (empty($sqlText)) {
        echo json_encode(['success' => false, 'error' => 'SQL 为空']);
        $conn->close();
        exit;
    }
    addLog($conn, $admin, 'exec_sql', substr($sqlText, 0, 200), $now);
    $result = $conn->query($sqlText);
    if ($result === false) {
        echo json_encode(['success' => false, 'error' => $conn->error]);
        $conn->close();
        exit;
    }
    if ($result === true) {
        echo json_encode(['success' => true, 'type' => 'affected', 'affected' => $conn->affected_rows]);
    } else {
        $rows = [];
        while ($row = $result->fetch_assoc()) $rows[] = $row;
        echo json_encode(['success' => true, 'type' => 'result', 'rows' => $rows]);
    }
    $conn->close();
    exit;
}

if ($action === 'admin_send_message') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_send_messages')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $to = $_POST['to_user'] ?? '';
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    if (!$to || !$title || !$content) {
        echo json_encode(['success' => false, 'error' => '参数不完整']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT username FROM users WHERE username = ?");
    $stmt->bind_param("s", $to);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows === 0) {
        $stmt->close();
        echo json_encode(['success' => false, 'error' => '用户不存在']);
        $conn->close();
        exit;
    }
    $stmt->close();
    $order_id = sendMessage($conn, $admin, $to, $title, $content, $now);
    addLog($conn, $admin, 'send_message', '发消息给 ' . $to, $now);
    echo json_encode(['success' => true, 'order_id' => $order_id]);
    $conn->close();
    exit;
}

if ($action === 'admin_send_all_message') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_send_messages')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    if (!$title || !$content) {
        echo json_encode(['success' => false, 'error' => '参数不完整']);
        $conn->close();
        exit;
    }
    $r = $conn->query("SELECT username FROM users WHERE status = 1");
    $count = 0;
    while ($row = $r->fetch_assoc()) {
        sendMessage($conn, $admin, $row['username'], $title, $content, $now);
        $count++;
    }
    addLog($conn, $admin, 'send_all_message', '全服消息：' . $title, $now);
    echo json_encode(['success' => true, 'count' => $count]);
    $conn->close();
    exit;
}

if ($action === 'admin_get_feedbacks') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_feedback')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $r = $conn->query("SELECT * FROM feedback ORDER BY id DESC LIMIT 200");
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['time'] = date('Y-m-d H:i', strtotime($row['time']));
        $list[] = $row;
    }
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'admin_reply_feedback') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_feedback')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $id = intval($_POST['id'] ?? 0);
    $reply = trim($_POST['reply'] ?? '');
    if (!$id || !$reply) {
        echo json_encode(['success' => false, 'error' => '参数不完整']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT * FROM feedback WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $r = $stmt->get_result();
    $fb = $r->fetch_assoc();
    $stmt->close();
    if (!$fb) {
        echo json_encode(['success' => false, 'error' => '反馈不存在']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("UPDATE feedback SET reply = ?, status = 1 WHERE id = ?");
    $stmt->bind_param("si", $reply, $id);
    $stmt->execute();
    $stmt->close();
    sendMessage($conn, $admin, $fb['username'], '您的反馈已回复', '关于您的反馈：' . $fb['content'] . "\n\n管理员回复：\n" . $reply, $now);
    addLog($conn, $admin, 'reply_feedback', '回复反馈 #' . $id, $now);
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'publish_notice') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_notices')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    if (!$title || !$content) {
        echo json_encode(['success' => false, 'error' => '参数无效']);
        $conn->close();
        exit;
    }
    $order_id = genOrderId('NT');
    $stmt = $conn->prepare("INSERT INTO notices (order_id, title, content, time) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $order_id, $title, $content, $now);
    $stmt->execute();
    $stmt->close();
    addLog($conn, $admin, 'publish_notice', $title, $now);
    echo json_encode(['success' => true, 'order_id' => $order_id]);
    $conn->close();
    exit;
}

if ($action === 'delete_notice') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_notices')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $id = intval($_POST['id'] ?? 0);
    $stmt = $conn->prepare("DELETE FROM notices WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'generate_redeem_code') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_codes')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $points = intval($_POST['points'] ?? 0);
    $expireDays = intval($_POST['expire_days'] ?? 30);
    $maxUses = intval($_POST['max_uses'] ?? 1);
    $perUser = intval($_POST['per_user'] ?? 1);
    $count = intval($_POST['count'] ?? 1);
    if ($points <= 0 || $maxUses <= 0) {
        echo json_encode(['success' => false, 'error' => '参数无效']);
        $conn->close();
        exit;
    }
    if ($count < 1 || $count > 100) $count = 1;
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $expiresAt = date('Y-m-d H:i:s', strtotime("+$expireDays days"));
    $codes = [];
    for ($c = 0; $c < $count; $c++) {
        $code = '';
        for ($i = 0; $i < 8; $i++) $code .= $chars[rand(0, 35)];
        $stmt = $conn->prepare("INSERT INTO redeem_codes (code, points, max_uses, per_user_limit, expires_at, created_at) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("siiiss", $code, $points, $maxUses, $perUser, $expiresAt, $now);
        $stmt->execute();
        $stmt->close();
        $codes[] = $code;
    }
    addLog($conn, $admin, 'gen_redeem', '生成 ' . count($codes) . ' 个兑换码', $now);
    echo json_encode(['success' => true, 'codes' => $codes]);
    $conn->close();
    exit;
}

if ($action === 'get_redeem_codes') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_codes')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $r = $conn->query("SELECT * FROM redeem_codes ORDER BY id DESC LIMIT 100");
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['expires_at'] = $row['expires_at'] ? date('Y-m-d', strtotime($row['expires_at'])) : '永久';
        $row['created_at'] = date('Y-m-d H:i', strtotime($row['created_at']));
        $row['status'] = ($row['used_count'] >= $row['max_uses']) ? '已用完' : '有效';
        $list[] = $row;
    }
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'delete_redeem_code') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_codes')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $id = intval($_POST['id'] ?? 0);
    $stmt = $conn->prepare("DELETE FROM redeem_codes WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'generate_item_code') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_codes')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $productName = trim($_POST['product_name'] ?? '');
    $expireDays = intval($_POST['expire_days'] ?? 30);
    $count = max(1, min(100, intval($_POST['count'] ?? 1)));
    if (empty($productName)) {
        echo json_encode(['success' => false, 'error' => '请输入道具名称']);
        $conn->close();
        exit;
    }
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $expiresAt = date('Y-m-d H:i:s', strtotime("+$expireDays days"));
    $codes = [];
    for ($c = 0; $c < $count; $c++) {
        $code = 'IC';
        for ($i = 0; $i < 10; $i++) $code .= $chars[rand(0, 35)];
        $stmt = $conn->prepare("INSERT INTO item_codes (code, product_name, expires_at, created_at) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $code, $productName, $expiresAt, $now);
        $stmt->execute();
        $stmt->close();
        $codes[] = $code;
    }
    echo json_encode(['success' => true, 'codes' => $codes]);
    $conn->close();
    exit;
}

if ($action === 'get_item_codes') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_codes')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $r = $conn->query("SELECT * FROM item_codes ORDER BY id DESC LIMIT 100");
    $list = [];
    while ($row = $r->fetch_assoc()) {
        $row['expires_at'] = $row['expires_at'] ? date('Y-m-d', strtotime($row['expires_at'])) : '永久';
        $row['created_at'] = date('Y-m-d H:i', strtotime($row['created_at']));
        $list[] = $row;
    }
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'delete_item_code') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_codes')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $id = intval($_POST['id'] ?? 0);
    $stmt = $conn->prepare("DELETE FROM item_codes WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'redeem') {
    $username = $_POST['username'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $code = strtoupper(trim($_POST['code'] ?? ''));
    if (empty($code)) {
        echo json_encode(['success' => false, 'error' => '请输入兑换码']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT * FROM item_codes WHERE code = ? AND used_by IS NULL");
    $stmt->bind_param("s", $code);
    $stmt->execute();
    $r = $stmt->get_result();
    $ic = $r->fetch_assoc();
    $stmt->close();
    if ($ic) {
        if ($ic['expires_at'] && strtotime($ic['expires_at']) < time()) {
            echo json_encode(['success' => false, 'error' => '兑换码已过期']);
            $conn->close();
            exit;
        }
        $pname = $ic['product_name'];
        if (strpos($pname, 'BUNDLE:') === 0) {
            $bundleKey = substr($pname, 7);
            $bundlesDir = __DIR__ . '/Runfiles/bundles/' . $bundleKey;
            if (!is_dir($bundlesDir)) {
                echo json_encode(['success' => false, 'error' => '套装不存在']);
                $conn->close();
                exit;
            }
            $files = scandir($bundlesDir);
            $addedCount = 0;
            $conn->begin_transaction();
            try {
                foreach ($files as $f) {
                    if ($f === '.' || $f === '..' || $f === 'config.json') continue;
                    if (!is_file($bundlesDir . '/' . $f)) continue;
                    $lower = strtolower($f);
                    if (strpos($lower, 'cover.') === 0) continue;
                    $relPath = 'Runfiles/bundles/' . $bundleKey . '/' . $f;
                    $stmt = $conn->prepare("INSERT INTO user_items (username, product_id, product_name, quantity, file_path, is_one_time, can_sell) VALUES (?, 0, ?, 1, ?, 0, 1)");
                    $stmt->bind_param("sss", $username, $f, $relPath);
                    $stmt->execute();
                    $stmt->close();
                    $addedCount++;
                }
                $stmt = $conn->prepare("UPDATE item_codes SET used_by = ?, used_at = ? WHERE id = ?");
                $stmt->bind_param("ssi", $username, $now, $ic['id']);
                $stmt->execute();
                $stmt->close();
                $conn->commit();
                echo json_encode(['success' => true, 'type' => 'bundle', 'bundle_key' => $bundleKey, 'count' => $addedCount]);
                $conn->close();
                exit;
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
                $conn->close();
                exit;
            }
        } else {
            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare("UPDATE item_codes SET used_by = ?, used_at = ? WHERE id = ?");
                $stmt->bind_param("ssi", $username, $now, $ic['id']);
                $stmt->execute();
                $stmt->close();
                $stmt = $conn->prepare("INSERT INTO user_items (username, product_id, product_name, quantity, can_sell) VALUES (?, 0, ?, 1, 1)");
                $stmt->bind_param("ss", $username, $pname);
                $stmt->execute();
                $stmt->close();
                $conn->commit();
                echo json_encode(['success' => true, 'type' => 'item', 'product_name' => $pname]);
                $conn->close();
                exit;
            } catch (Exception $e) {
                $conn->rollback();
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
                $conn->close();
                exit;
            }
        }
    }
    $stmt = $conn->prepare("SELECT * FROM redeem_codes WHERE code = ?");
    $stmt->bind_param("s", $code);
    $stmt->execute();
    $r = $stmt->get_result();
    $redeem = $r->fetch_assoc();
    $stmt->close();
    if (!$redeem) {
        echo json_encode(['success' => false, 'error' => '兑换码不存在']);
        $conn->close();
        exit;
    }
    if ($redeem['used_count'] >= $redeem['max_uses']) {
        echo json_encode(['success' => false, 'error' => '兑换码已用完']);
        $conn->close();
        exit;
    }
    if ($redeem['expires_at'] && strtotime($redeem['expires_at']) < time()) {
        echo json_encode(['success' => false, 'error' => '兑换码已过期']);
        $conn->close();
        exit;
    }
    $perLimit = intval($redeem['per_user_limit']);
    $stmt = $conn->prepare("SELECT id FROM redeem_records WHERE code = ? AND username = ?");
    $stmt->bind_param("ss", $code, $username);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows >= $perLimit) {
        $stmt->close();
        echo json_encode(['success' => false, 'error' => '您已兑换过此码']);
        $conn->close();
        exit;
    }
    $stmt->close();
    $conn->begin_transaction();
    try {
        $points = floatval($redeem['points']);
        $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE username = ?");
        $stmt->bind_param("ds", $points, $username);
        $stmt->execute();
        $stmt->close();
        $newCount = intval($redeem['used_count']) + 1;
        $stmt = $conn->prepare("UPDATE redeem_codes SET used_count = ? WHERE code = ?");
        $stmt->bind_param("is", $newCount, $code);
        $stmt->execute();
        $stmt->close();
        $order_id = genOrderId('RD');
        $stmt = $conn->prepare("INSERT INTO redeem_records (order_id, code, username, points, time) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssds", $order_id, $code, $username, $points, $now);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        addPointsLog($conn, $username, $points, 'redeem', '兑换码 ' . $code, $order_id, $now);
        echo json_encode(['success' => true, 'type' => 'points', 'points' => $points, 'order_id' => $order_id]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    $conn->close();
    exit;
}

if ($action === 'get_maintenance') {
    echo json_encode([
        'mode' => getSetting($conn, 'maintenance_mode', '0'),
        'time' => getSetting($conn, 'maintenance_time', ''),
        'operator' => getSetting($conn, 'maintenance_operator', '')
    ]);
    $conn->close();
    exit;
}

if ($action === 'upload_file') {
    $username = $_POST['username'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['success' => false, 'error' => '上传失败']);
        $conn->close();
        exit;
    }
    if ($_FILES['file']['size'] > 50 * 1024 * 1024) {
        echo json_encode(['success' => false, 'error' => '文件不能超过 50MB']);
        $conn->close();
        exit;
    }
    $originalName = $_FILES['file']['name'];
    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    $allowed = ['jpg','jpeg','png','gif','webp','bmp','svg','pdf','txt','md','json','csv','log','xml','html','js','css','php','mp3','wav','ogg','m4a','mp4','webm','zip','rar','7z'];
    if (!in_array($ext, $allowed)) {
        echo json_encode(['success' => false, 'error' => '不支持的文件类型']);
        $conn->close();
        exit;
    }
    $filesDir = __DIR__ . '/files/';
    if (!is_dir($filesDir)) mkdir($filesDir, 0755, true);
    $safeName = preg_replace('/[^\w\x{4e00}-\x{9fa5}\.\-]/u', '_', $originalName);
    $filename = time() . '_' . rand(1000, 9999) . '_' . $safeName;
    $filepath = $filesDir . $filename;
    if (!move_uploaded_file($_FILES['file']['tmp_name'], $filepath)) {
        echo json_encode(['success' => false, 'error' => '保存失败']);
        $conn->close();
        exit;
    }
    echo json_encode(['success' => true, 'path' => 'files/' . $filename, 'name' => $originalName]);
    $conn->close();
    exit;
}

if ($action === 'upload_cover') {
    $username = $_POST['username'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $dataUrl = $_POST['image'] ?? '';
    if (empty($dataUrl)) {
        echo json_encode(['success' => false, 'error' => '无图片数据']);
        $conn->close();
        exit;
    }
    if (!preg_match('/^data:image\/(png|jpeg|jpg|webp);base64,/', $dataUrl)) {
        echo json_encode(['success' => false, 'error' => '图片格式错误']);
        $conn->close();
        exit;
    }
    $dataUrl = preg_replace('/^data:image\/\w+;base64,/', '', $dataUrl);
    $binary = base64_decode($dataUrl);
    if ($binary === false) {
        echo json_encode(['success' => false, 'error' => '解码失败']);
        $conn->close();
        exit;
    }
    if (strlen($binary) > 2 * 1024 * 1024) {
        echo json_encode(['success' => false, 'error' => '封面不能超过 2MB']);
        $conn->close();
        exit;
    }
    $coversDir = __DIR__ . '/Runfiles/covers/';
    if (!is_dir($coversDir)) mkdir($coversDir, 0755, true);
    $filename = 'cover_' . time() . '_' . rand(1000, 9999) . '.png';
    $filepath = $coversDir . $filename;
    file_put_contents($filepath, $binary);
    echo json_encode(['success' => true, 'url' => '/Runfiles/covers/' . $filename]);
    $conn->close();
    exit;
}

if ($action === 'add_view') {
    $itemType = $_POST['item_type'] ?? '';
    $itemId = intval($_POST['item_id'] ?? 0);
    if ($itemType === 'product') {
        $conn->query("UPDATE products SET views = views + 1 WHERE id = $itemId");
    } else if ($itemType === 'listing') {
        $conn->query("UPDATE market_listings SET views = views + 1 WHERE id = $itemId");
    }
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'toggle_favorite') {
    $username = $_POST['username'] ?? '';
    if (!checkUserStatus($conn, $username)) {
        echo json_encode(['success' => false, 'error' => '账号状态异常']);
        $conn->close();
        exit;
    }
    $itemType = $_POST['item_type'] ?? '';
    $itemId = intval($_POST['item_id'] ?? 0);
    if (!in_array($itemType, ['product', 'listing']) || $itemId <= 0) {
        echo json_encode(['success' => false, 'error' => '参数无效']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("SELECT id FROM favorites WHERE username = ? AND item_type = ? AND item_id = ?");
    $stmt->bind_param("ssi", $username, $itemType, $itemId);
    $stmt->execute();
    $r = $stmt->get_result();
    $exist = $r->fetch_assoc();
    $stmt->close();
    if ($exist) {
        $stmt = $conn->prepare("DELETE FROM favorites WHERE id = ?");
        $stmt->bind_param("i", $exist['id']);
        $stmt->execute();
        $stmt->close();
        if ($itemType === 'listing') {
            $conn->query("UPDATE market_listings SET favorite_count = GREATEST(0, favorite_count - 1) WHERE id = $itemId");
        }
        echo json_encode(['success' => true, 'favorited' => false]);
    } else {
        $stmt = $conn->prepare("INSERT INTO favorites (username, item_type, item_id, created_at) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssis", $username, $itemType, $itemId, $now);
        $stmt->execute();
        $stmt->close();
        if ($itemType === 'listing') {
            $conn->query("UPDATE market_listings SET favorite_count = favorite_count + 1 WHERE id = $itemId");
        }
        echo json_encode(['success' => true, 'favorited' => true]);
    }
    $conn->close();
    exit;
}

if ($action === 'get_favorites') {
    $username = $_POST['username'] ?? '';
    $itemType = $_POST['item_type'] ?? 'all';
    if ($itemType === 'all') {
        $stmt = $conn->prepare("SELECT * FROM favorites WHERE username = ? ORDER BY id DESC");
        $stmt->bind_param("s", $username);
    } else {
        $stmt = $conn->prepare("SELECT * FROM favorites WHERE username = ? AND item_type = ? ORDER BY id DESC");
        $stmt->bind_param("ss", $username, $itemType);
    }
    $stmt->execute();
    $r = $stmt->get_result();
    $list = [];
    while ($row = $r->fetch_assoc()) {
        if ($row['item_type'] === 'product') {
            $stmt2 = $conn->prepare("SELECT id, name, price, icon, description FROM products WHERE id = ? AND status = 1");
            $stmt2->bind_param("i", $row['item_id']);
            $stmt2->execute();
            $r2 = $stmt2->get_result();
            $item = $r2->fetch_assoc();
            $stmt2->close();
            if ($item) {
                $item['type'] = 'product';
                $item['favorite_id'] = $row['id'];
                $list[] = $item;
            }
        } else if ($row['item_type'] === 'listing') {
            $stmt2 = $conn->prepare("SELECT id, item_name as name, price, icon, description FROM market_listings WHERE id = ? AND status = 1");
            $stmt2->bind_param("i", $row['item_id']);
            $stmt2->execute();
            $r2 = $stmt2->get_result();
            $item = $r2->fetch_assoc();
            $stmt2->close();
            if ($item) {
                $item['type'] = 'listing';
                $item['favorite_id'] = $row['id'];
                $list[] = $item;
            }
        }
    }
    $stmt->close();
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'relist') {
    $username = $_POST['username'] ?? '';
    $listingId = intval($_POST['listing_id'] ?? 0);
    $price = floatval($_POST['price'] ?? 0);
    $stmt = $conn->prepare("SELECT * FROM market_listings WHERE id = ? AND seller = ? AND status = 0");
    $stmt->bind_param("is", $listingId, $username);
    $stmt->execute();
    $r = $stmt->get_result();
    $listing = $r->fetch_assoc();
    $stmt->close();
    if (!$listing) {
        echo json_encode(['success' => false, 'error' => '商品不存在或状态错误']);
        $conn->close();
        exit;
    }
    if ($price <= 0) {
        echo json_encode(['success' => false, 'error' => '价格必须大于0']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("UPDATE market_listings SET status = 1, price = ?, created_at = ? WHERE id = ?");
    $stmt->bind_param("dsi", $price, $now, $listingId);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true]);
    $conn->close();
    exit;
}

if ($action === 'scan_bundle_folders') {
    $bundlesDir = __DIR__ . '/Runfiles/bundles/';
    $list = [];
    if (is_dir($bundlesDir)) {
        $dirs = scandir($bundlesDir);
        foreach ($dirs as $dir) {
            if ($dir === '.' || $dir === '..') continue;
            $path = $bundlesDir . $dir;
            if (is_dir($path)) {
                $cfgFile = $path . '/config.json';
                $cfg = [];
                if (file_exists($cfgFile)) {
                    $parsed = json_decode(file_get_contents($cfgFile), true);
                    if ($parsed) $cfg = $parsed;
                }
                $cfg['key'] = $dir;
                if (empty($cfg['name'])) $cfg['name'] = $dir;
                $coverFile = $cfg['cover'] ?? 'cover.png';
                if (!file_exists($path . '/' . $coverFile)) {
                    $imgs = glob($path . '/*.{png,jpg,jpeg,gif,webp}', GLOB_BRACE);
                    if (!empty($imgs)) {
                        $coverFile = basename($imgs[0]);
                    } else {
                        $coverFile = '';
                    }
                }
                $cfg['cover_url'] = $coverFile ? '/Runfiles/bundles/' . $dir . '/' . $coverFile : '/Runfiles/feature-photo/item_default.png';
                $cfg['files'] = [];
                $itemsMap = [];
                if (!empty($cfg['items']) && is_array($cfg['items'])) {
                    foreach ($cfg['items'] as $it) {
                        $itemsMap[$it['name']] = $it['desc'] ?? '';
                    }
                }
                $files = scandir($path);
                foreach ($files as $f) {
                    if ($f === '.' || $f === '..' || $f === 'config.json') continue;
                    if ($f === $coverFile) continue;
                    if (is_file($path . '/' . $f)) {
                        $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
                        $cfg['files'][] = [
                            'name' => $f,
                            'path' => '/Runfiles/bundles/' . $dir . '/' . $f,
                            'size' => filesize($path . '/' . $f),
                            'ext' => $ext,
                            'desc' => $itemsMap[$f] ?? ''
                        ];
                    }
                }
                $list[] = $cfg;
            }
        }
    }
    echo json_encode($list);
    $conn->close();
    exit;
}

if ($action === 'generate_bundle_codes') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_products')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $bundleKey = $_POST['bundle_key'] ?? '';
    $count = max(1, min(100, intval($_POST['count'] ?? 1)));
    $expireDays = intval($_POST['expire_days'] ?? 30);
    if (empty($bundleKey)) {
        echo json_encode(['success' => false, 'error' => '请选择套装']);
        $conn->close();
        exit;
    }
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $expiresAt = date('Y-m-d H:i:s', strtotime("+$expireDays days"));
    $codes = [];
    for ($i = 0; $i < $count; $i++) {
        $code = 'BN';
        for ($j = 0; $j < 10; $j++) $code .= $chars[rand(0, 35)];
        $stmt = $conn->prepare("INSERT INTO item_codes (code, product_name, expires_at, created_at) VALUES (?, ?, ?, ?)");
        $pname = 'BUNDLE:' . $bundleKey;
        $stmt->bind_param("ssss", $code, $pname, $expiresAt, $now);
        $stmt->execute();
        $stmt->close();
        $codes[] = $code;
    }
    echo json_encode(['success' => true, 'codes' => $codes]);
    $conn->close();
    exit;
}

if ($action === 'create_coupon') {
    $admin = $_POST['admin'] ?? '';
    if (!hasPermission($conn, $admin, 'can_manage_coupons')) {
        echo json_encode(['success' => false, 'error' => '权限不足']);
        $conn->close();
        exit;
    }
    $name = trim($_POST['name'] ?? '');
    $type = $_POST['type'] ?? 'fixed';
    $value = floatval($_POST['value'] ?? 0);
    $minSpend = floatval($_POST['min_spend'] ?? 0);
    $maxUses = intval($_POST['max_uses'] ?? 1);
    $expireDays = intval($_POST['expire_days'] ?? 30);
    if (empty($name) || $value <= 0) {
        echo json_encode(['success' => false, 'error' => '参数无效']);
        $conn->close();
        exit;
    }
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $code = '';
    for ($i = 0; $i < 10; $i++) $code .= $chars[rand(0, 35)];
    $expiresAt = date('Y-m-d H:i:s', strtotime("+$expireDays days"));
    $stmt = $conn->prepare("INSERT INTO coupons (code, name, type, value, min_spend, max_uses, expires_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssddiss", $code, $name, $type, $value, $minSpend, $maxUses, $expiresAt, $now);
    $stmt->execute();
    $stmt->close();
    echo json_encode(['success' => true, 'code' => $code]);
    $conn->close();
    exit;
}

if ($action === 'get_bundle_detail') {
    $key = $_POST['bundle_key'] ?? '';
    if (empty($key)) {
        echo json_encode(['success' => false, 'error' => '参数无效']);
        $conn->close();
        exit;
    }
    $path = __DIR__ . '/Runfiles/bundles/' . $key;
    if (!is_dir($path)) {
        echo json_encode(['success' => false, 'error' => '套装不存在']);
        $conn->close();
        exit;
    }
    $cfgFile = $path . '/config.json';
    $cfg = [];
    if (file_exists($cfgFile)) {
        $parsed = json_decode(file_get_contents($cfgFile), true);
        if ($parsed) $cfg = $parsed;
    }
    $cfg['key'] = $key;
    if (empty($cfg['name'])) $cfg['name'] = $key;
    $coverFile = $cfg['cover'] ?? 'cover.png';
    if (!file_exists($path . '/' . $coverFile)) {
        $imgs = glob($path . '/*.{png,jpg,jpeg,gif,webp}', GLOB_BRACE);
        $coverFile = !empty($imgs) ? basename($imgs[0]) : '';
    }
    $cfg['cover_url'] = $coverFile ? '/Runfiles/bundles/' . $key . '/' . $coverFile : '/Runfiles/feature-photo/item_default.png';
    $cfg['files'] = [];
    $itemsMap = [];
    if (!empty($cfg['items']) && is_array($cfg['items'])) {
        foreach ($cfg['items'] as $it) $itemsMap[$it['name']] = $it['desc'] ?? '';
    }
    $files = scandir($path);
    foreach ($files as $f) {
        if ($f === '.' || $f === '..' || $f === 'config.json') continue;
        if ($f === $coverFile) continue;
        if (is_file($path . '/' . $f)) {
            $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
            $cfg['files'][] = [
                'name' => $f,
                'path' => '/Runfiles/bundles/' . $key . '/' . $f,
                'size' => filesize($path . '/' . $f),
                'ext' => $ext,
                'desc' => $itemsMap[$f] ?? ''
            ];
        }
    }
    echo json_encode($cfg);
    $conn->close();
    exit;
}

echo json_encode(['success' => false, 'error' => '未知操作']);
$conn->close();
exit;
?>


