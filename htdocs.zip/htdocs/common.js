// ===== common.js 完整版 V0.4.1 =====
// ===== 版本自检 =====
(function () {
    if (window._vcheck) return;
    window._vcheck = 1;
    var LOADED_VERSION = '041';
    fetch('version.txt?t=' + Date.now(), { cache: 'no-store' })
        .then(function (r) { return r.text(); })
        .then(function (v) {
            v = (v || '').trim();
            if (v && v !== LOADED_VERSION) {
                var reloadedVersion = sessionStorage.getItem('_v_reloaded');
                if (reloadedVersion === v) return;
                sessionStorage.setItem('_v_reloaded', v);
                var url = new URL(location.href);
                url.searchParams.set('_v', v);
                location.replace(url.toString());
            } else {
                sessionStorage.removeItem('_v_reloaded');
            }
        })
        .catch(function () {});
})();
// ===== 版本自检结束 =====

const APP_VERSION = 'V0.4.1';

let user = null;

function fmt(num, digits) {
    num = parseFloat(num) || 0;
    digits = digits === undefined ? 2 : digits;
    var parts = num.toFixed(digits).split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return parts.join('.');
}

function genOrderId(prefix) {
    var d = new Date();
    var s = d.getFullYear() +
        String(d.getMonth() + 1).padStart(2, '0') +
        String(d.getDate()).padStart(2, '0') +
        String(d.getHours()).padStart(2, '0') +
        String(d.getMinutes()).padStart(2, '0') +
        String(d.getSeconds()).padStart(2, '0');
    return prefix + s + Math.floor(Math.random() * 900 + 100);
}

function injectCommonCSS() {
    if (document.getElementById('commonCSS')) return;
    var css = '.tip-box{position:fixed;top:24px;right:-420px;min-width:280px;max-width:360px;background:var(--card,#fff);color:var(--text,#1a1a2e);border-radius:14px;box-shadow:0 12px 40px rgba(0,0,0,0.12);z-index:99999;overflow:hidden;display:flex;align-items:flex-start;padding:14px 16px;gap:12px;opacity:0;transition:right 0.5s cubic-bezier(0.16,1,0.3,1),opacity 0.4s ease;pointer-events:none}'
        + '.tip-box.show{right:24px;opacity:1;pointer-events:auto}'
        + '.tip-box.hide{right:-420px;opacity:0}'
        + '.tip-icon{width:24px;height:24px;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:2px}'
        + '.tip-info .tip-icon{color:#3b82f6}'
        + '.tip-error .tip-icon{color:#ef4444}'
        + '.tip-success .tip-icon{color:#10b981}'
        + '.tip-icon svg{width:22px;height:22px;display:block}'
        + '.tip-content{flex:1;min-width:0}'
        + '.tip-title{font-size:14px;font-weight:600;margin-bottom:4px}'
        + '.tip-body{font-size:13px;color:var(--muted,#888);line-height:1.5;word-break:break-word}'
        + '.tip-progress{position:absolute;bottom:0;left:0;right:0;height:3px;background:rgba(0,0,0,0.05)}'
        + '.tip-progress-bar{height:100%;width:100%;transform-origin:left;transition:transform linear}'
        + '.tip-info .tip-progress-bar{background:linear-gradient(90deg,#3b82f6,#2563eb)}'
        + '.tip-error .tip-progress-bar{background:linear-gradient(90deg,#ef4444,#dc2626)}'
        + '.tip-success .tip-progress-bar{background:linear-gradient(90deg,#10b981,#059669)}'
        + '.loading-box{position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(255,255,255,0.9);backdrop-filter:blur(2px);display:flex;align-items:center;justify-content:center;z-index:100001}'
        + '[data-dark="1"] .loading-box{background:rgba(15,23,42,0.9)}'
        + '.loading-spinner{width:48px;height:48px;border:3px solid rgba(102,126,234,0.15);border-top-color:var(--primary,#667eea);border-radius:50%;animation:spin 0.9s cubic-bezier(0.5,0.1,0.5,0.9) infinite;margin:0 auto 14px}'
        + '@keyframes spin{to{transform:rotate(360deg)}}'
        + '@keyframes inlineSpin{to{transform:rotate(360deg)}}'
        + '.loading-inner{text-align:center;width:180px}'
        + '.loading-text{font-size:14px;color:var(--muted,#888)}'
        + '.swal2-popup{font-size:13px !important;padding:16px !important;border-radius:14px !important}'
        + '.swal2-title{font-size:16px !important;padding:0 0 10px !important}'
        + '.swal2-html-container{font-size:13px !important;margin:8px 0 !important}'
        + '.swal2-input,.swal2-textarea,.swal2-select{font-size:14px !important;padding:8px 10px !important;height:auto !important;margin:6px auto !important;border-radius:8px !important}'
        + '.swal2-actions{margin-top:12px !important;gap:8px !important}'
        + '.swal2-confirm,.swal2-cancel{font-size:14px !important;padding:8px 20px !important;border-radius:8px !important}'
        + '.menu-icon{width:32px;height:32px;object-fit:contain;flex-shrink:0}'
        + '.feature-photo{width:48px;height:48px;object-fit:contain}'
        + '.nav-icon{width:24px;height:24px;object-fit:contain}'
        + '@media(max-width:480px){.menu-icon{width:28px;height:28px}.feature-photo{width:40px;height:40px}}';
    var style = document.createElement('style');
    style.id = 'commonCSS';
    style.textContent = css;
    document.head.appendChild(style);
}

function showTip(type, msg, duration) {
    injectCommonCSS();
    duration = duration || 3000;
    var old = document.getElementById('tipBox');
    if (old) old.remove();
    var icons = {
        info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>',
        error: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>',
        success: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>'
    };
    var titles = { info: '提示', error: '错误', success: '成功' };
    var box = document.createElement('div');
    box.id = 'tipBox';
    box.className = 'tip-box tip-' + type;
    box.innerHTML = '<div class="tip-icon">' + (icons[type] || icons.info) + '</div><div class="tip-content"><div class="tip-title">' + (titles[type] || '提示') + '</div><div class="tip-body">' + msg + '</div></div><div class="tip-progress"><div class="tip-progress-bar"></div></div>';
    document.body.appendChild(box);
    requestAnimationFrame(function () {
        requestAnimationFrame(function () { box.classList.add('show'); });
    });
    var bar = box.querySelector('.tip-progress-bar');
    bar.style.transform = 'scaleX(0)';
    bar.style.transitionDuration = duration + 'ms';
    requestAnimationFrame(function () {
        requestAnimationFrame(function () { bar.style.transform = 'scaleX(1)'; });
    });
    setTimeout(function () {
        box.classList.remove('show');
        box.classList.add('hide');
        setTimeout(function () { if (box.parentElement) box.remove(); }, 500);
    }, duration);
}

function showModal(opt) {
    opt = opt || {};
    var type = opt.type || 'info';
    var iconMap = { info: 'info', error: 'error', success: 'success', warning: 'warning' };
    var config = {
        icon: iconMap[type] || 'info',
        title: opt.title || '提示',
        html: opt.content || '',
        confirmButtonText: '确定',
        confirmButtonColor: '#667eea',
        borderRadius: '14px'
    };
    var buttons = opt.buttons || [];
    if (buttons.length >= 2) {
        config.showCancelButton = true;
        config.cancelButtonText = buttons[0].text;
        config.cancelButtonColor = buttons[0].color || '#e8ecf1';
        config.confirmButtonText = buttons[1].text;
        config.confirmButtonColor = buttons[1].color || '#667eea';
    } else if (buttons.length === 1) {
        config.confirmButtonText = buttons[0].text;
        config.confirmButtonColor = buttons[0].color || '#667eea';
    }
    Swal.fire(config).then(function (result) {
        if (result.isConfirmed) {
            if (buttons.length >= 2 && buttons[1].callback) buttons[1].callback();
            else if (buttons.length === 1 && buttons[0].callback) buttons[0].callback();
        } else if (result.dismiss === Swal.DismissReason.cancel) {
            if (buttons.length >= 2 && buttons[0].callback) buttons[0].callback();
        }
    });
}

function showLoading(text) {
    injectCommonCSS();
    var old = document.getElementById('loadingBox');
    if (old) old.remove();
    var loading = document.createElement('div');
    loading.id = 'loadingBox';
    loading.className = 'loading-box';
    loading.innerHTML = '<div class="loading-inner"><div class="loading-spinner"></div><div class="loading-text">' + (text || '加载中') + '</div></div>';
    document.body.appendChild(loading);
}

function hideLoading() {
    var el = document.getElementById('loadingBox');
    if (el) el.remove();
}

function showInlineLoading(container, text) {
    if (typeof container === 'string') container = document.getElementById(container);
    if (!container) return;
    container.innerHTML = '<div style="text-align:center;padding:30px 0;">'
        + '<div style="width:36px;height:36px;border:3px solid rgba(102,126,234,0.2);border-top-color:var(--primary,#667eea);border-radius:50%;animation:inlineSpin 0.9s linear infinite;margin:0 auto 12px;"></div>'
        + '<div style="font-size:13px;color:var(--muted,#888);">' + (text || '加载中') + '</div>'
        + '</div>';
}

function request(action, data, callback) {
    var f = new FormData();
    for (var k in data) f.append(k, data[k]);
    if (user) f.append('admin', user.username);
    var rawText = '';
    fetch('api.php?action=' + action, { method: 'POST', body: f })
        .then(function (r) {
            return r.text().then(function (text) {
                rawText = text;
                if (!r.ok) {
                    throw new Error('HTTP ' + r.status + ' | 响应：' + text.substring(0, 300));
                }
                return text;
            });
        })
        .then(function (text) {
            var d;
            try {
                d = JSON.parse(text);
            } catch (e) {
                throw new Error('返回的不是 JSON | 内容：' + text.substring(0, 300));
            }
            if (callback) callback(d);
        })
        .catch(function (e) {
            var errMsg = '';
            if (e && e.message) {
                errMsg = e.message;
            } else {
                errMsg = '未知错误';
            }
            var fullMsg = '操作：' + action + '<br>错误：' + errMsg;
            showModal({
                type: 'error',
                title: '系统错误',
                content: fullMsg,
                buttons: [{ text: '确定', color: '#ef4444' }]
            });
            reportError('[' + action + '] ' + errMsg);
            if (callback) callback({ success: false, error: errMsg });
        });
}

function reportError(errMsg) {
    try {
        var f = new FormData();
        f.append('username', user ? user.username : '');
        f.append('error', errMsg);
        fetch('api.php?action=report_error', { method: 'POST', body: f });
    } catch (e) {}
}

function saveLogin(userData) {
    var data = { user: userData, login_time: Date.now() };
    try {
        localStorage.setItem('user', JSON.stringify(data));
        sessionStorage.setItem('user', JSON.stringify(userData));
    } catch (e) {}
}

function updateUser(newUser) {
    if (!newUser) return;
    user = newUser;
    try { sessionStorage.setItem('user', JSON.stringify(user)); } catch (e) {}
    try {
        var l = localStorage.getItem('user');
        if (l) {
            var data = JSON.parse(l);
            data.user = user;
            data.login_time = Date.now();
            localStorage.setItem('user', JSON.stringify(data));
        }
    } catch (e) {}
}

function checkLogin() {
    var s = sessionStorage.getItem('user');
    if (s) {
        try {
            var parsed = JSON.parse(s);
            if (parsed && parsed.username) {
                user = parsed;
                afterLogin();
                return user;
            }
        } catch (e) {
            sessionStorage.removeItem('user');
        }
    }
    var l = localStorage.getItem('user');
    if (l) {
        try {
            var data = JSON.parse(l);
            var now = Date.now();
            var expire = 365 * 24 * 60 * 60 * 1000;
            if (data.login_time && (now - data.login_time) < expire && data.user && data.user.username) {
                user = data.user;
                try { sessionStorage.setItem('user', JSON.stringify(user)); } catch (e) {}
                afterLogin();
                return user;
            } else {
                localStorage.removeItem('user');
            }
        } catch (e) {
            localStorage.removeItem('user');
        }
    }
    window.location.href = 'index.html';
    return null;
}

function afterLogin() {
    if (user.level >= 4) {
        var el = document.getElementById('adminLink');
        if (el) el.style.display = 'block';
    }
    applyTheme();
    if (user.need_rename == 1 && window.location.pathname.indexOf('rename.html') === -1) {
        window.location.href = 'rename.html';
    }
}

function logout() {
    showModal({
        type: 'warning',
        title: '确认退出',
        content: '确定要退出登录吗？',
        buttons: [
            { text: '取消', color: '#e8ecf1' },
            { text: '退出', color: '#ef4444', callback: function () {
                sessionStorage.clear();
                localStorage.removeItem('user');
                window.location.href = 'index.html';
            }}
        ]
    });
}

function copyText(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(function () { showTip('success', '已复制'); });
    } else {
        var input = document.createElement('input');
        input.value = text;
        document.body.appendChild(input);
        input.select();
        document.execCommand('copy');
        document.body.removeChild(input);
        showTip('success', '已复制');
    }
}

function getBeijingTime() {
    var now = new Date();
    var utc = now.getTime() + now.getTimezoneOffset() * 60000;
    var bj = new Date(utc + 8 * 3600000);
    return bj.getFullYear() + '年' +
        String(bj.getMonth() + 1).padStart(2, '0') + '月' +
        String(bj.getDate()).padStart(2, '0') + '日 ' +
        String(bj.getHours()).padStart(2, '0') + ':' +
        String(bj.getMinutes()).padStart(2, '0') + ':' +
        String(bj.getSeconds()).padStart(2, '0');
}

function getGreeting() {
    var hour = new Date().getHours();
    if (hour >= 5 && hour < 12) return '早上好';
    if (hour >= 12 && hour < 14) return '中午好';
    if (hour >= 14 && hour < 18) return '下午好';
    return '晚上好';
}

function shadeColor(color, percent) {
    if (!color || color.indexOf('#') !== 0) return color;
    var R = parseInt(color.substring(1, 3), 16);
    var G = parseInt(color.substring(3, 5), 16);
    var B = parseInt(color.substring(5, 7), 16);
    R = parseInt(R * (100 + percent) / 100);
    G = parseInt(G * (100 + percent) / 100);
    B = parseInt(B * (100 + percent) / 100);
    R = (R < 255) ? R : 255;
    G = (G < 255) ? G : 255;
    B = (B < 255) ? B : 255;
    return '#' + R.toString(16).padStart(2, '0') + G.toString(16).padStart(2, '0') + B.toString(16).padStart(2, '0');
}

function applyTheme() {
    if (!user) return;
    var theme = user.theme || '#667eea';
    if (theme && theme.indexOf('#') === 0) {
        document.documentElement.style.setProperty('--primary', theme);
        document.documentElement.style.setProperty('--primary-2', shadeColor(theme, -20));
    } else {
        var themeMap = {
            purple: '#667eea', blue: '#3b82f6', green: '#10b981',
            orange: '#f59e0b', pink: '#ec4899', teal: '#14b8a6'
        };
        var c = themeMap[theme] || '#667eea';
        document.documentElement.style.setProperty('--primary', c);
        document.documentElement.style.setProperty('--primary-2', shadeColor(c, -20));
    }
    if (user.dark_mode == 1) document.documentElement.setAttribute('data-dark', '1');
    else document.documentElement.removeAttribute('data-dark');
}

function requestNotificationPermission() {
    if (!('Notification' in window)) return;
    if (Notification.permission === 'default') {
        Notification.requestPermission();
    }
}

function sendNotification(title, body) {
    if (!('Notification' in window)) return;
    if (Notification.permission !== 'granted') return;
    if (!user || user.notify_on != 1) return;
    try { new Notification(title, { body: body }); } catch (e) {}
}

function weatherIconClass(code) {
    if (code === 0) return 'qi-100';
    if (code === 1) return 'qi-103';
    if (code === 2) return 'qi-101';
    if (code === 3) return 'qi-104';
    if (code >= 45 && code <= 48) return 'qi-501';
    if (code >= 51 && code <= 57) return 'qi-305';
    if (code >= 61 && code <= 65) return 'qi-306';
    if (code >= 66 && code <= 67) return 'qi-313';
    if (code >= 71 && code <= 75) return 'qi-400';
    if (code === 77) return 'qi-499';
    if (code >= 80 && code <= 82) return 'qi-307';
    if (code >= 85 && code <= 86) return 'qi-407';
    if (code >= 95 && code <= 99) return 'qi-302';
    return 'qi-999';
}

function weatherDesc(code) {
    if (code === 0) return '晴';
    if (code === 1) return '晴间多云';
    if (code === 2) return '多云';
    if (code === 3) return '阴';
    if (code >= 45 && code <= 48) return '雾';
    if (code >= 51 && code <= 57) return '毛毛雨';
    if (code >= 61 && code <= 65) return '雨';
    if (code >= 66 && code <= 67) return '冻雨';
    if (code >= 71 && code <= 75) return '雪';
    if (code === 77) return '雪粒';
    if (code >= 80 && code <= 82) return '阵雨';
    if (code >= 85 && code <= 86) return '阵雪';
    if (code >= 95 && code <= 99) return '雷雨';
    return '未知';
}

var APP_DATA = null;
function loadAppData(callback) {
    if (APP_DATA) { if (callback) callback(APP_DATA); return; }
    fetch('data.json')
        .then(function (r) { return r.json(); })
        .then(function (d) {
            APP_DATA = d;
            if (callback) callback(d);
        })
        .catch(function () { if (callback) callback(null); });
}

function registerPWA() {
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', function () {
            navigator.serviceWorker.register('/sw.js').catch(function () {});
        });
    }
}

function checkMaintenanceAndSelfcheck() {
    if (!user) return;
    if (user.is_mmu != 1) return;
    request('selfcheck_status', {}, function (d) {
        if (!d) return;
        var needCheck = false;
        var needBackup = false;
        var now = Date.now();
        var week = 7 * 24 * 60 * 60 * 1000;
        if (!d.selfcheck_last || (now - new Date(d.selfcheck_last).getTime()) > week) needCheck = true;
        if (!d.backup_last || (now - new Date(d.backup_last).getTime()) > week) needBackup = true;
        if (needCheck) {
            setTimeout(function () {
                var f = new FormData();
                f.append('admin', user.username);
                fetch('api.php?action=selfcheck_run', { method: 'POST', body: f });
            }, 5000);
        }
        if (needBackup) {
            setTimeout(function () {
                var f = new FormData();
                f.append('admin', user.username);
                fetch('api.php?action=backup_now', { method: 'POST', body: f });
            }, 10000);
        }
    });
}

function loadExtLibs() {
    if (!window.pdfjsLib) {
        var pdf = document.createElement('script');
        pdf.src = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.min.js';
        pdf.onload = function () {
            if (window.pdfjsLib) {
                window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.worker.min.js';
            }
        };
        document.head.appendChild(pdf);
    }
    if (!window.jsmediatags) {
        var tags = document.createElement('script');
        tags.src = 'https://cdn.jsdelivr.net/npm/jsmediatags@3.9.7/dist/jsmediatags.min.js';
        document.head.appendChild(tags);
    }
}

function generateCoverFromFile(file, callback) {
    var ext = (file.name.split('.').pop() || '').toLowerCase();
    var imgExts = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
    var audioExts = ['mp3', 'm4a'];
    var videoExts = ['mp4', 'webm', 'ogg'];
    if (imgExts.indexOf(ext) >= 0) {
        var reader = new FileReader();
        reader.onload = function (e) { callback(e.target.result); };
        reader.readAsDataURL(file);
    } else if (ext === 'pdf') {
        generatePDFCover(file, callback);
    } else if (audioExts.indexOf(ext) >= 0) {
        generateAudioCover(file, callback);
    } else if (videoExts.indexOf(ext) >= 0) {
        generateVideoCover(file, callback);
    } else {
        callback(null);
    }
}

function generatePDFCover(file, callback) {
    if (!window.pdfjsLib) {
        setTimeout(function () { generatePDFCover(file, callback); }, 500);
        return;
    }
    var reader = new FileReader();
    reader.onload = function (e) {
        var typedArray = new Uint8Array(e.target.result);
        pdfjsLib.getDocument(typedArray).promise.then(function (pdf) {
            pdf.getPage(1).then(function (page) {
                var viewport = page.getViewport({ scale: 1 });
                var scale = 300 / viewport.width;
                var scaled = page.getViewport({ scale: scale });
                var canvas = document.createElement('canvas');
                canvas.width = scaled.width;
                canvas.height = scaled.height;
                var ctx = canvas.getContext('2d');
                page.render({ canvasContext: ctx, viewport: scaled }).promise.then(function () {
                    callback(canvas.toDataURL('image/png'));
                });
            }).catch(function () { callback(null); });
        }).catch(function () { callback(null); });
    };
    reader.readAsArrayBuffer(file);
}

function generateAudioCover(file, callback) {
    if (typeof jsmediatags === 'undefined') {
        setTimeout(function () { generateAudioCover(file, callback); }, 500);
        return;
    }
    jsmediatags.read(file, {
        onSuccess: function (tag) {
            var pic = tag.tags.picture;
            if (!pic) { callback(null); return; }
            var base64 = '';
            for (var i = 0; i < pic.data.length; i++) base64 += String.fromCharCode(pic.data[i]);
            callback('data:' + pic.format + ';base64,' + btoa(base64));
        },
        onError: function () { callback(null); }
    });
}

function generateVideoCover(file, callback) {
    var video = document.createElement('video');
    video.preload = 'metadata';
    video.muted = true;
    video.src = URL.createObjectURL(file);
    var done = false;
    video.onloadeddata = function () {
        if (done) return;
        video.currentTime = 0.1;
    };
    video.onseeked = function () {
        if (done) return;
        done = true;
        try {
            var canvas = document.createElement('canvas');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            canvas.getContext('2d').drawImage(video, 0, 0);
            callback(canvas.toDataURL('image/png'));
        } catch (e) {
            callback(null);
        }
        URL.revokeObjectURL(video.src);
    };
    video.onerror = function () { callback(null); };
    setTimeout(function () {
        if (!done) {
            done = true;
            callback(null);
            try { URL.revokeObjectURL(video.src); } catch (e) {}
        }
    }, 10000);
}

function uploadCover(dataUrl, callback) {
    if (!dataUrl) { callback({ success: false, error: '无封面数据' }); return; }
    var f = new FormData();
    f.append('username', user.username);
    f.append('image', dataUrl);
    fetch('api.php?action=upload_cover', { method: 'POST', body: f })
        .then(function (r) { return r.json(); })
        .then(function (d) { callback(d); })
        .catch(function () { callback({ success: false, error: '网络错误' }); });
}

function uploadFile(file, callback) {
    if (!file) { callback({ success: false, error: '无文件' }); return; }
    var f = new FormData();
    f.append('username', user.username);
    f.append('file', file);
    fetch('api.php?action=upload_file', { method: 'POST', body: f })
        .then(function (r) { return r.json(); })
        .then(function (d) { callback(d); })
        .catch(function () { callback({ success: false, error: '网络错误' }); });
}

(function () {
    injectCommonCSS();
    registerPWA();
    loadExtLibs();
    try {
        var s = sessionStorage.getItem('user');
        if (s) {
            var u = JSON.parse(s);
            if (u) {
                var theme = u.theme || '#667eea';
                if (theme && theme.indexOf('#') === 0) {
                    document.documentElement.style.setProperty('--primary', theme);
                    document.documentElement.style.setProperty('--primary-2', shadeColor(theme, -20));
                }
                if (u.dark_mode == 1) document.documentElement.setAttribute('data-dark', '1');
            }
        }
    } catch (e) {}
})();