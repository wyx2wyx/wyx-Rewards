<?php
header('Content-Type: application/json; charset=utf-8');

$filesDir = 'files/';
$list = [];

if (is_dir($filesDir)) {
    $files = scandir($filesDir);
    foreach ($files as $file) {
        if ($file === '.' || $file === '..') continue;
        $path = $filesDir . $file;
        if (is_file($path)) {
            $list[] = [
                'name' => $file,
                'path' => $path,
                'size' => filesize($path),
                'time' => date('Y-m-d H:i', filemtime($path))
            ];
        }
    }
}

echo json_encode($list);
?>