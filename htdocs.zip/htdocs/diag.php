<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: text/html; charset=utf-8');
date_default_timezone_set('Asia/Shanghai');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>系统诊断</title>
<style>
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:#f5f7fa;padding:16px;color:#1a1a2e;line-height:1.7}
h1{font-size:22px;margin-bottom:16px}
h2{font-size:16px;margin:20px 0 10px;color:#667eea;border-left:3px solid #667eea;padding-left:10px}
.box{background:#fff;border-radius:10px;padding:14px;margin-bottom:12px;box-shadow:0 1px 4px rgba(0,0,0,0.06)}
.ok{color:#10b981;font-weight:600}
.fail{color:#ef4444;font-weight:600}
.warn{color:#f59e0b;font-weight:600}
pre{background:#f5f7fa;padding:10px;border-radius:6px;font-size:12px;overflow-x:auto;white-space:pre-wrap;word-break:break-all;margin-top:6px}
.row{padding:6px 0;border-bottom:1px solid #e8ecf1;display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap}
.row:last-child{border-bottom:0}
.row .lbl{color:#888;flex-shrink:0}
.row .val{text-align:right;word-break:break-all}
.btn{display:inline-block;padding:10px 20px;background:#667eea;color:#fff;text-decoration:none;border-radius:8px;font-size:14px;margin-top:10px}
</style>
</head>
<body>

<h1>Rewards 系统诊断</h1>
<p style="color:#888;font-size:13px;">生成时间：<?php echo date('Y-m-d H:i:s'); ?></p>

<h2>1. PHP 环境</h2>
<div class="box">
<div class="row"><span class="lbl">PHP 版本</span><span class="val"><?php echo phpversion(); ?></span></div>
<div class="row"><span class="lbl">服务器软件</span><span class="val"><?php echo $_SERVER['SERVER_SOFTWARE'] ?? '未知'; ?></span></div>
<div class="row"><span class="lbl">时区</span><span class="val"><?php echo date_default_timezone_get(); ?></span></div>
<div class="row"><span class="lbl">当前时间</span><span class="val"><?php echo date('Y-m-d H:i:s'); ?></span></div>
<div class="row"><span class="lbl">cURL 支持</span><span class="val"><?php echo function_exists('curl_init') ? '<span class="ok">是</span>' : '<span class="fail">否</span>'; ?></span></div>
<div class="row"><span class="lbl">mysqli 支持</span><span class="val"><?php echo function_exists('mysqli_connect') ? '<span class="ok">是</span>' : '<span class="fail">否</span>'; ?></span></div>
<div class="row"><span class="lbl">GD 库</span><span class="val"><?php echo extension_loaded('gd') ? '<span class="ok">是</span>' : '<span class="warn">否</span>'; ?></span></div>
<div class="row"><span class="lbl">fileinfo 扩展</span><span class="val"><?php echo extension_loaded('fileinfo') ? '<span class="ok">是</span>' : '<span class="warn">否</span>'; ?></span></div>
<div class="row"><span class="lbl">当前脚本路径</span><span class="val"><?php echo __DIR__; ?></span></div>
<div class="row"><span class="lbl">HTTP_HOST</span><span class="val"><?php echo $_SERVER['HTTP_HOST'] ?? '无'; ?></span></div>
<div class="row"><span class="lbl">PHP_SELF</span><span class="val"><?php echo $_SERVER['PHP_SELF'] ?? '无'; ?></span></div>
<div class="row"><span class="lbl">HTTPS</span><span class="val"><?php echo (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? '是' : '否'; ?></span></div>
</div>

<h2>2. 数据库连接</h2>
<div class="box">
<?php
$host = 'sql303.infinityfree.com';
$user = 'if0_42728000';
$pass = 'LAYZ2026';
$db = 'if0_42728000_rewards';
$conn = @new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    echo '<div class="row"><span class="lbl">连接状态</span><span class="val fail">失败</span></div>';
    echo '<div class="row"><span class="lbl">错误</span><span class="val">' . htmlspecialchars($conn->connect_error) . '</span></div>';
} else {
    echo '<div class="row"><span class="lbl">连接状态</span><span class="val ok">成功</span></div>';
    $conn->set_charset("utf8mb4");
    $r = $conn->query("SELECT COUNT(*) as c FROM users");
    $row = $r->fetch_assoc();
    echo '<div class="row"><span class="lbl">用户数</span><span class="val">' . $row['c'] . '</span></div>';
    $r = $conn->query("SHOW TABLES");
    echo '<div class="row"><span class="lbl">表数量</span><span class="val">' . $r->num_rows . '</span></div>';
    $r = $conn->query("SELECT username, level, is_mmu, status, need_rename FROM users WHERE username = 'wyx'");
    $wyx = $r->fetch_assoc();
    if ($wyx) {
        echo '<div class="row"><span class="lbl">wyx 存在</span><span class="val ok">是</span></div>';
        echo '<div class="row"><span class="lbl">wyx level</span><span class="val">' . $wyx['level'] . '</span></div>';
        echo '<div class="row"><span class="lbl">wyx is_mmu</span><span class="val">' . $wyx['is_mmu'] . '</span></div>';
        echo '<div class="row"><span class="lbl">wyx status</span><span class="val">' . $wyx['status'] . '</span></div>';
        echo '<div class="row"><span class="lbl">wyx need_rename</span><span class="val">' . $wyx['need_rename'] . '</span></div>';
    } else {
        echo '<div class="row"><span class="lbl">wyx 存在</span><span class="val fail">否</span></div>';
    }
    $conn->close();
}
?>
</div>

<h2>3. 目录检查</h2>
<div class="box">
<?php
$dirs = [
    'Runfiles',
    'Runfiles/feature-photo',
    'Runfiles/covers',
    'Runfiles/bundles',
    'Runfiles/items',
    'Runfiles/achievements',
    'Runfiles/badges',
    'Runfiles/avatars',
    'Runfiles/Puke',
    'files',
    'data'
];
foreach ($dirs as $d) {
    $p = __DIR__ . '/' . $d;
    $exists = is_dir($p);
    $writable = $exists ? is_writable($p) : false;
    echo '<div class="row"><span class="lbl">' . $d . '</span><span class="val">';
    echo $exists ? '<span class="ok">存在</span>' : '<span class="fail">不存在</span>';
    if ($exists) {
        echo ' / ' . ($writable ? '<span class="ok">可写</span>' : '<span class="fail">不可写</span>');
    }
    echo '</span></div>';
}
?>
</div>

<h2>4. api.php 检查</h2>
<div class="box">
<?php
$apiFile = __DIR__ . '/api.php';
if (file_exists($apiFile)) {
    echo '<div class="row"><span class="lbl">文件存在</span><span class="val ok">是</span></div>';
    echo '<div class="row"><span class="lbl">文件大小</span><span class="val">' . number_format(filesize($apiFile)) . ' 字节</span></div>';
    echo '<div class="row"><span class="lbl">修改时间</span><span class="val">' . date('Y-m-d H:i:s', filemtime($apiFile)) . '</span></div>';
    $content = file_get_contents($apiFile);
    echo '<div class="row"><span class="lbl">包含 login</span><span class="val">' . (strpos($content, "action === 'login'") !== false ? '<span class="ok">是</span>' : '<span class="fail">否</span>') . '</span></div>';
    echo '<div class="row"><span class="lbl">包含 selfcheck_run</span><span class="val">' . (strpos($content, "action === 'selfcheck_run'") !== false ? '<span class="ok">是</span>' : '<span class="fail">否</span>') . '</span></div>';
    echo '<div class="row"><span class="lbl">包含 upload_cover</span><span class="val">' . (strpos($content, "action === 'upload_cover'") !== false ? '<span class="ok">是</span>' : '<span class="warn">否</span>') . '</span></div>';
    echo '<div class="row"><span class="lbl">包含 toggle_favorite</span><span class="val">' . (strpos($content, "action === 'toggle_favorite'") !== false ? '<span class="ok">是</span>' : '<span class="warn">否</span>') . '</span></div>';
    echo '<div class="row"><span class="lbl">包含 scan_bundle_folders</span><span class="val">' . (strpos($content, "action === 'scan_bundle_folders'") !== false ? '<span class="ok">是</span>' : '<span class="warn">否</span>') . '</span></div>';
} else {
    echo '<div class="row"><span class="lbl">文件存在</span><span class="val fail">否</span></div>';
}
?>
</div>

<h2>5. 内部请求测试</h2>
<div class="box">
<p style="font-size:13px;color:#888;">通过 cURL 从服务器内部调用 api.php 测试。</p>
<?php
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
$baseUrl = $protocol . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
echo '<div class="row"><span class="lbl">请求地址</span><span class="val">' . htmlspecialchars($baseUrl) . '</span></div>';

if (function_exists('curl_init')) {
    $tests = ['ping', 'get_settings', 'get_products', 'get_market_listings', 'get_notices'];
    foreach ($tests as $action) {
        $url = $baseUrl . '/api.php?action=' . $action;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $resp = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        echo '<div class="row"><span class="lbl">' . $action . '</span><span class="val">';
        if ($code === 200 && $resp) {
            $json = json_decode($resp, true);
            echo '<span class="ok">HTTP 200</span>';
            if ($json !== null) {
                echo ' / JSON 正常';
            } else {
                echo ' / <span class="fail">JSON 解析失败</span>';
                echo '<pre>' . htmlspecialchars(substr($resp, 0, 500)) . '</pre>';
            }
        } else {
            echo '<span class="fail">HTTP ' . $code . '</span>';
            if ($err) echo ' / cURL: ' . htmlspecialchars($err);
            if ($resp) echo '<pre>' . htmlspecialchars(substr($resp, 0, 500)) . '</pre>';
        }
        echo '</span></div>';
    }
} else {
    echo '<div class="row"><span class="lbl">cURL</span><span class="val fail">不可用</span></div>';
}
?>
</div>

<h2>6. 网络连通性测试</h2>
<div class="box">
<?php
$targets = [
    'https://api.open-meteo.com/v1/forecast?latitude=39.9&longitude=116.4&current=temperature_2m',
    'https://v1.hitokoto.cn/',
    'https://cdn.jsdelivr.net/npm/sweetalert2@11'
];
foreach ($targets as $url) {
    $host = parse_url($url, PHP_URL_HOST);
    echo '<div class="row"><span class="lbl">' . $host . '</span><span class="val">';
    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        echo $code === 200 ? '<span class="ok">HTTP 200</span>' : '<span class="warn">HTTP ' . $code . '</span>';
    } else {
        echo '<span class="warn">cURL 不可用</span>';
    }
    echo '</span></div>';
}
?>
</div>

<h2>7. 关键文件清单</h2>
<div class="box">
<?php
$files = [
    'index.html', 'dashboard.html', 'features.html', 'settings.html', 'admin.html',
    'rename.html', 'notices.html', 'stock.html', 'bank.html', 'transfer.html',
    'bankcard.html', 'items.html', 'market.html', 'cart.html', 'lottery.html',
    'wheel.html', 'scratch.html', 'lottery_bet.html', 'game.html', 'friends.html',
    'gift.html', 'messages.html', 'ephemeral.html', 'points_log.html', 'my_purchases.html',
    'order_search.html', 'feedback.html', 'achievements.html', 'countdown.html',
    'search.html', 'help.html', 'manual.html', 'about.html', 'selfcheck.html',
    'coupons.html', 'favorites.html',
    'api.php', 'common.js', 'data.json', 'manifest.json', 'sw.js', 'favicon.ico'
];
$missing = [];
$present = 0;
foreach ($files as $f) {
    if (file_exists(__DIR__ . '/' . $f)) {
        $present++;
    } else {
        $missing[] = $f;
    }
}
echo '<div class="row"><span class="lbl">已上传</span><span class="val ok">' . $present . ' / ' . count($files) . '</span></div>';
if (count($missing) > 0) {
    echo '<div class="row"><span class="lbl">缺失</span><span class="val fail">' . implode(', ', $missing) . '</span></div>';
}
?>
</div>

<h2>8. Session 与 Cookie</h2>
<div class="box">
<div class="row"><span class="lbl">Session 状态</span><span class="val"><?php echo session_status() === PHP_SESSION_ACTIVE ? '已启动' : '未启动'; ?></span></div>
<div class="row"><span class="lbl">Cookie 数量</span><span class="val"><?php echo count($_COOKIE); ?></span></div>
</div>

<h2>9. 错误日志（最近 20 条）</h2>
<div class="box">
<?php
$errLog = ini_get('error_log');
if ($errLog && file_exists($errLog)) {
    $lines = file($errLog);
    $recent = array_slice($lines, -20);
    echo '<pre>' . htmlspecialchars(implode('', $recent)) . '</pre>';
} else {
    echo '<div class="row"><span class="lbl">错误日志</span><span class="val">无法读取（路径：' . htmlspecialchars($errLog ?: '未设置') . '）</span></div>';
}
?>
</div>

<h2>10. 建议</h2>
<div class="box">
<p style="font-size:14px;">
以上信息全部检查完后：
</p>
<ul style="padding-left:20px;font-size:14px;line-height:2;">
<li>如果"内部请求测试"全部 HTTP 200，说明 API 本身没问题</li>
<li>如果有失败，把失败项的响应内容发给开发者</li>
<li>如果"目录检查"有"不存在"，需要补建目录</li>
<li>如果"关键文件清单"有缺失，需要补传文件</li>
</ul>
</div>

<p style="text-align:center;margin-top:20px;color:#888;font-size:12px;">
<a class="btn" href="diag.php">刷新诊断</a>
</p>

</body>
</html>